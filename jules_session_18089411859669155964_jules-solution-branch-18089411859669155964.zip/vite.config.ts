
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  define: {
    // Safely polyfill process.env to an empty object to prevent ReferenceErrors
    // and avoid injecting incorrect string literals for undefined variables.
    'process.env': {},
  },
});
