
export const SPOT_DATA = {
  red: {
    title: '红色之旅',
    subtitle: '分类列表页面',
    color: 'red',
    bg: 'bg-red-500',
    text: 'text-red-600',
    lightBg: 'bg-red-50',
    spots: [
        { id: 'r1', name: '辛亥革命纪念馆', promo: '革命摇篮 薪火相传', desc: '郑氏宗祠，革命摇篮，见证了东里村的觉醒年代。', x: 35, y: 40, detailImage: 'https://picsum.photos/seed/r1/600/400' },
        { id: 'r2', name: '旌义状石碑', promo: '中山亲颁 无上荣光', desc: '孙中山亲颁，表彰海外华侨的爱国义举。', x: 65, y: 25, detailImage: 'https://picsum.photos/seed/r2/600/400' },
        { id: 'r3', name: '红军古道', promo: '重走长征 忆苦思甜', desc: '蜿蜒于山林之间，重走长征路，感受红色记忆。', x: 25, y: 65, detailImage: 'https://picsum.photos/seed/r3/600/400' },
    ]
  },
  nature: {
    title: '自然风景',
    subtitle: '分类列表页面',
    color: 'emerald',
    bg: 'bg-emerald-500',
    text: 'text-emerald-600',
    lightBg: 'bg-emerald-50',
    spots: [
        { id: 'n1', name: '仙灵瀑布', promo: '飞流直下 清凉一夏', desc: '落差百米，飞流直下，是夏日清凉避暑的绝佳胜地。', x: 70, y: 45, detailImage: 'https://picsum.photos/seed/n1/600/400' },
        { id: 'n2', name: '东里水库', promo: '湖光山色 碧波荡漾', desc: '湖光山色，碧波荡漾，适合垂钓与露营。', x: 50, y: 55, detailImage: 'https://picsum.photos/seed/n2/600/400' },
        { id: 'n3', name: '油桐花海', promo: '五月飞雪 浪漫花径', desc: '每年五月，油桐花开，如雪纷飞，浪漫至极。', x: 80, y: 75, detailImage: 'https://picsum.photos/seed/n3/600/400' },
        { id: 'n4', name: '千年古榕', promo: '独木成林 岁月见证', desc: '千年古榕树，独木成林，见证了村庄的沧桑巨变。', x: 30, y: 80, detailImage: 'https://picsum.photos/seed/n4/600/400' },
    ]
  },
  people: {
    title: '东里名人',
    subtitle: '人文荟萃',
    color: 'purple',
    bg: 'bg-purple-500',
    text: 'text-purple-600',
    lightBg: 'bg-purple-50',
    spots: [
        {
            id: 'p1',
            name: '革命先辈',
            promo: '缅怀先烈 浩气长存',
            desc: '追忆为国家独立、民族解放奋斗牺牲的英雄人物，传承红色基因。',
            x: 45, y: 35,
            detailImage: 'https://picsum.photos/seed/p1/600/400',
            directory: [
                { name: '郑玉指', tag: '同盟会会员', desc: '辛亥革命华侨领袖，追随孙中山先生，倾家荡产资助革命。', imageSeed: 'zyz' },
                { name: '颜子俊', tag: '爱国侨领', desc: '著名爱国华侨领袖，抗战期间积极组织海外华侨捐资捐物。', imageSeed: 'yzj' },
                { name: '郑义', tag: '红军烈士', desc: '1930年参加红军，在反围剿战斗中英勇牺牲，年仅22岁。', imageSeed: 'zy' }
            ]
        },
        {
            id: 'p2',
            name: '乡贤名人',
            promo: '德高望重 造福桑梓',
            desc: '介绍德高望重，热心公益，造福桑梓的杰出乡贤事迹。',
            x: 75, y: 60,
            detailImage: 'https://picsum.photos/seed/p2/600/400',
            directory: [
                { name: '郑老先生', tag: '慈善家', desc: '设立"东里奖学金"，资助贫困学生数百人。', imageSeed: 'zls' },
                { name: '李教授', tag: '文化学者', desc: '编撰《东里村史》，为传承村落文化做出巨大贡献。', imageSeed: 'ljs' },
                { name: '张医师', tag: '名医', desc: '悬壶济世五十年，医术精湛，免费为村里老人义诊。', imageSeed: 'zys' }
            ]
        },
        {
            id: 'p3',
            name: '青年后生',
            promo: '朝气蓬勃 未来可期',
            desc: '展现朝气蓬勃，在各行各业崭露头角，建设家乡的新生代力量。',
            x: 20, y: 70,
            detailImage: 'https://picsum.photos/seed/p3/600/400',
            directory: [
                { name: '郑晓明', tag: '清华大学', desc: '以优异成绩考入清华大学计算机系，东里村的骄傲。', imageSeed: 'zxm' },
                { name: '创业团', tag: '返乡创业', desc: '5名返乡大学生组成的创业团队，年销售额破千万。', imageSeed: 'cyt' },
                { name: '林小红', tag: '非遗传承', desc: '90后剪纸艺术家，致力于将传统剪纸艺术与现代设计结合。', imageSeed: 'lxh' }
            ]
        },
    ]
  }
};
