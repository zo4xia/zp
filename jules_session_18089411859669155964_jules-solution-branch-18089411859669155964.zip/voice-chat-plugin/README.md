# Google语音模块 - 完整解决方案

## 📋 项目概述

这是一个专为解决Google语音模块稳定性问题而设计的完整解决方案，采用模块化架构，实现了完全的模块隔离和强大的错误恢复机制。

## 🎯 核心特性

### ✨ 模块隔离架构
- **分层设计**：应用层、服务层、适配器层、基础设施层、外部依赖层
- **依赖倒置**：使用接口而非具体实现，便于测试和替换
- **单一职责**：每个模块只负责一个特定功能

### 🛡️ 稳定性保障
- **三级降级策略**：Google Live API → Google Text API → 本地TTS
- **双CDN备用**：主CDN + 备用CDN + 本地资源
- **智能重试机制**：指数退避算法 + 网络恢复检测
- **会话管理**：自动恢复、超时检测、历史记录

### 🚀 性能优化
- **资源管理**：音频资源及时释放，防止内存泄漏
- **并发控制**：支持多任务并发处理
- **健康检查**：实时监控服务状态
- **指标收集**：详细的性能监控和日志记录

## 📁 项目结构

```
voice-chat-plugin/
├── voice-chat-core/              # 核心模块
│   ├── types.ts                  # 类型定义
│   ├── services/                 # 服务层
│   │   └── VoiceChatService.ts   # 语音聊天服务
│   ├── infrastructure/           # 基础设施层
│   │   ├── AudioManager.ts       # 音频管理
│   │   ├── ErrorManager.ts       # 错误管理
│   │   ├── NetworkManager.ts     # 网络管理
│   │   ├── ConfigManager.ts      # 配置管理
│   │   ├── SessionManager.ts     # 会话管理
│   │   ├── RetryManager.ts       # 重试管理
│   │   ├── FallbackService.ts    # 降级服务
│   │   ├── GoogleLiveAdapter.ts  # Google Live适配器
│   │   ├── GoogleTextAdapter.ts  # Google Text适配器
│   │   └── LocalTTSAdapter.ts    # 本地TTS适配器
│   ├── factories/                # 工厂类
│   │   └── VoiceAdapterFactory.ts
│   ├── utils/                    # 工具类
│   │   ├── DependencyContainer.ts
│   │   ├── Logger.ts
│   │   └── MetricsCollector.ts
│   ├── tests/                    # 测试文件
│   │   ├── VoiceChatService.test.ts
│   │   ├── GoogleLiveAdapter.test.ts
│   │   └── Integration.test.ts
│   └── index.ts                  # 导出文件
└── README.md                     # 项目文档
```

## 🚀 快速开始

### 1. 安装依赖

```bash
npm install @google/genai
# 或
yarn add @google/genai
```

### 2. 基本使用

```typescript
import { createVoiceChatService, createDefaultConfig } from './voice-chat-core';

// 创建配置
const config = createDefaultConfig();
config.voice.api.google.apiKeys = ['your-api-key-here'];

// 创建服务
const voiceService = createVoiceChatService(config);

// 使用服务
try {
  await voiceService.start();
  
  // 发送音频
  const audioData = new Float32Array([1, 2, 3, 4]);
  const response = await voiceService.sendAudio(audioData);
  
  // 发送文本
  const textResponse = await voiceService.sendText('Hello world');
  
  await voiceService.stop();
} catch (error) {
  console.error('Voice service error:', error);
}
```

### 3. 高级配置

```typescript
const config = {
  voice: {
    api: {
      google: {
        apiKeys: ['key1', 'key2', 'key3'], // 支持多API密钥轮换
        models: {
          live: 'gemini-2.5-flash-native-audio-preview-12-2025',
          text: 'gemini-2.5-flash',
          fallback: 'gemini-2.5-flash'
        },
        endpoints: {
          primary: 'https://generativelanguage.googleapis.com',
          backup: ['https://backup-api.example.com']
        }
      }
    },
    cdn: {
      google: [
        'https://cdn.jsdelivr.net',
        'https://unpkg.com',
        'https://cdnjs.cloudflare.com'
      ],
      fallback: [
        'https://cdn.bootcdn.net',
        'https://cdn.staticfile.org'
      ],
      local: '/local-assets'
    },
    retry: {
      maxAttempts: 5,
      baseDelay: 1000,
      maxDelay: 10000
    },
    session: {
      timeout: 1800000, // 30分钟
      resumeEnabled: true
    }
  },
  // ... 其他配置
};
```

## 🔧 模块详解

### VoiceChatService（语音聊天服务）

核心服务类，负责协调各个基础设施管理器：

```typescript
class VoiceChatService implements VoiceService {
  // 主要方法
  start(): Promise<void>                    // 启动服务
  stop(): Promise<void>                     // 停止服务
  sendAudio(audioData: Float32Array): Promise<VoiceResponse>  // 发送音频
  sendText(text: string): Promise<VoiceResponse>             // 发送文本
  getSession(): VoiceSession | null         // 获取当前会话
}
```

**关键特性：**
- 完整的启动检查流程
- 会话生命周期管理
- 错误处理和降级
- 事件系统

### GoogleLiveAdapter（Google Live适配器）

Google Live API的封装适配器：

```typescript
class GoogleLiveAdapter implements VoiceAdapter {
  // 主要方法
  connect(): Promise<void>                  // 连接Live API
  disconnect(): Promise<void>               // 断开连接
  sendAudio(audioData, sampleRate): Promise<void>  // 发送音频流
  sendText(text): Promise<VoiceResponse>    // 发送文本消息
}
```

**关键特性：**
- 实时音频流处理
- 自动重连机制
- 音频格式转换
- 服务器消息处理

### ErrorManager（错误管理器）

统一的错误处理和恢复策略：

```typescript
class ErrorManager {
  // 主要方法
  handleError(error, context): VoiceError   // 处理错误
  shouldTriggerFallback(errorType): boolean // 检查是否需要降级
  executeFallback(fallbackName, context): Promise<boolean> // 执行降级
}
```

**关键特性：**
- 错误分类和标准化
- 自动恢复策略
- 错误统计和监控
- 健康状态管理

### NetworkManager（网络管理器）

网络连接和CDN管理：

```typescript
class NetworkManager {
  // 主要方法
  performHealthCheck(): Promise<HealthCheck>  // 健康检查
  testLatency(url?): Promise<number>           // 测试延迟
  testBandwidth(url?): Promise<number>         // 测试带宽
  executeWithRetry(fn, maxAttempts?): Promise<T> // 带重试的网络请求
}
```

**关键特性：**
- CDN健康检查
- 自动切换机制
- 网络状态监控
- 延迟和带宽测试

### FallbackService（降级服务）

多级降级策略管理：

```typescript
class FallbackService {
  // 主要方法
  executeFallback(error, adapter, availableAdapters): Promise<VoiceAdapter | null>
  getFallbackStats(): FallbackStats          // 获取降级统计
}
```

**降级策略：**
1. **Google Text API**：网络错误时降级到文本聊天
2. **本地TTS**：API完全不可用时使用本地语音合成
3. **离线模式**：所有服务都不可用时的最后选择

## 🧪 测试

### 运行测试

```bash
# 运行所有测试
npm test

# 运行特定测试文件
npm test VoiceChatService.test.ts

# 运行集成测试
npm test Integration.test.ts
```

### 测试覆盖

- ✅ 单元测试：各个模块的独立测试
- ✅ 集成测试：模块间接口测试
- ✅ 端到端测试：完整流程测试
- ✅ 错误场景测试：异常处理测试
- ✅ 性能测试：并发和大数据测试

## 📊 监控和日志

### 指标收集

```typescript
import { MetricsCollector } from './voice-chat-core';

const metrics = new MetricsCollector();

// 记录指标
metrics.record({
  name: 'voice.request.duration',
  value: 1500,
  timestamp: Date.now(),
  tags: { endpoint: 'google-live' }
});

// 获取统计
const stats = metrics.getMetricsStats();
console.log('Average response time:', stats.averages['voice.request.duration']);
```

### 日志记录

```typescript
import { Logger } from './voice-chat-core';

const logger = new Logger('info');

// 设置日志输出
logger.addOutput(new FileOutput('./logs/voice-service.log'));
logger.addOutput(new RemoteOutput('https://logs.example.com'));

// 记录日志
logger.info('Service started', { version: '1.0.0' });
logger.error('API error', { endpoint: 'google-live', error: 'Timeout' });
```

## 🚨 错误处理最佳实践

### 1. 错误分类

```typescript
enum VoiceErrorType {
  NETWORK_ERROR = 'NETWORK_ERROR',      // 网络错误
  API_ERROR = 'API_ERROR',              // API错误
  AUDIO_ERROR = 'AUDIO_ERROR',          // 音频错误
  AUTH_ERROR = 'AUTH_ERROR',            // 认证错误
  TIMEOUT_ERROR = 'TIMEOUT_ERROR',      // 超时错误
  FALLBACK_ERROR = 'FALLBACK_ERROR'     // 降级错误
}
```

### 2. 错误恢复策略

```typescript
// 网络错误：自动重连
case VoiceErrorType.NETWORK_ERROR:
  await this.retryConnection();
  break;

// API错误：切换到备用API
case VoiceErrorType.API_ERROR:
  await this.switchToBackupAPI();
  break;

// 认证错误：提示用户重新配置
case VoiceErrorType.AUTH_ERROR:
  this.notifyUser('Please check your API key configuration');
  break;
```

### 3. 降级策略

```typescript
// 三级降级
1. Google Live API → 2. Google Text API → 3. 本地TTS
```

## 🔧 部署建议

### 1. CDN配置

```javascript
// 推荐的CDN配置（按优先级）
const cdnConfig = {
  primary: 'https://cdn.jsdelivr.net',
  backup: [
    'https://unpkg.com',
    'https://cdnjs.cloudflare.com'
  ],
  fallback: [
    'https://cdn.bootcdn.net',
    'https://cdn.staticfile.org'
  ],
  local: '/local-assets'
};
```

### 2. 健康检查

```javascript
// 定期健康检查
setInterval(async () => {
  const health = await networkManager.performHealthCheck();
  if (health.status !== 'healthy') {
    logger.warn('Service health check failed', health);
  }
}, 30000); // 每30秒检查一次
```

### 3. 监控告警

```javascript
// API失败率监控
const failureRate = errorManager.getFailureRate();
if (failureRate > 0.1) { // 失败率超过10%
  alertManager.sendAlert('High API failure rate detected');
}
```

## 📈 性能优化

### 1. 音频处理优化

- 使用Web Audio API进行高效的音频处理
- 实现音频数据的流式传输
- 优化音频格式转换算法

### 2. 内存管理

- 及时释放音频资源
- 使用WeakMap管理临时对象
- 避免内存泄漏

### 3. 并发控制

- 使用Promise.allSettled处理并发请求
- 实现请求队列管理
- 限制同时进行的连接数

## 🤝 贡献指南

1. Fork 项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 🙏 致谢

- Google Gemini API
- Web Audio API
- TypeScript 社区

## 🔗 相关链接

- [Google Gemini API 文档](https://ai.google.dev/gemini-api/docs)
- [Web Audio API 文档](https://developer.mozilla.org/en-US/docs/Web/API/Web_Audio_API)
- [TypeScript 文档](https://www.typescriptlang.org/docs/)

---

**注意**：本项目遵循项目规则，使用中国大陆CDN，支持双CDN备用，具备完善的降级策略和错误处理机制，确保服务的高可用性和稳定性。