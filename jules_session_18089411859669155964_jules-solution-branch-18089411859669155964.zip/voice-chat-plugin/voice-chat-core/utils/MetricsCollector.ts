import { Metrics, HealthCheck } from '../types';

/**
 * 指标收集器 - 负责收集和报告系统指标
 * 
 * 职责：
 * 1. 收集各种系统指标
 * 2. 计算衍生指标
 * 3. 提供指标聚合功能
 * 4. 支持多种输出格式
 */
export class MetricsCollector {
  private metrics: Metrics[] = [];
  private healthChecks: HealthCheck[] = [];
  private collectors: MetricCollector[] = [];
  private reportingInterval: any;

  constructor(private reportingDelay: number = 60000) {
    // 定期报告指标
    this.reportingInterval = setInterval(() => {
      this.reportMetrics();
    }, reportingDelay);
  }

  /**
   * 添加指标收集器
   */
  addCollector(collector: MetricCollector): void {
    this.collectors.push(collector);
  }

  /**
   * 记录指标
   */
  record(metrics: Metrics): void {
    this.metrics.push({
      ...metrics,
      timestamp: Date.now()
    });

    // 保持指标数量在合理范围内
    if (this.metrics.length > 10000) {
      this.metrics.splice(0, this.metrics.length - 10000);
    }
  }

  /**
   * 记录健康检查
   */
  recordHealthCheck(health: HealthCheck): void {
    this.healthChecks.push({
      ...health,
      lastCheck: Date.now()
    });

    // 保持健康检查数量在合理范围内
    if (this.healthChecks.length > 1000) {
      this.healthChecks.splice(0, this.healthChecks.length - 1000);
    }
  }

  /**
   * 获取指标统计
   */
  getMetricsStats(timeRange?: { start: number; end: number }): MetricsStats {
    const filteredMetrics = timeRange 
      ? this.metrics.filter(m => m.timestamp >= timeRange.start && m.timestamp <= timeRange.end)
      : this.metrics;

    const stats: MetricsStats = {
      total: filteredMetrics.length,
      byName: {},
      byTags: {},
      averages: {},
      percentiles: {}
    };

    // 按名称分组
    filteredMetrics.forEach(metric => {
      if (!stats.byName[metric.name]) {
        stats.byName[metric.name] = [];
      }
      stats.byName[metric.name].push(metric.value);
    });

    // 计算平均值
    Object.keys(stats.byName).forEach(name => {
      const values = stats.byName[name];
      stats.averages[name] = this.calculateAverage(values);
      stats.percentiles[name] = this.calculatePercentiles(values);
    });

    // 按标签分组
    filteredMetrics.forEach(metric => {
      if (metric.tags) {
        Object.keys(metric.tags).forEach(tagKey => {
          const tagValue = metric.tags![tagKey];
          const tagKeyStr = `${tagKey}:${tagValue}`;
          
          if (!stats.byTags[tagKeyStr]) {
            stats.byTags[tagKeyStr] = [];
          }
          stats.byTags[tagKeyStr].push(metric.value);
        });
      }
    });

    return stats;
  }

  /**
   * 获取健康状态
   */
  getHealthStatus(): HealthStatus {
    const now = Date.now();
    const recentChecks = this.healthChecks.filter(h => now - h.lastCheck < 300000); // 5分钟内

    const status: HealthStatus = {
      overall: 'healthy',
      services: {},
      lastUpdated: now
    };

    recentChecks.forEach(check => {
      status.services[check.name] = {
        status: check.status,
        message: check.message,
        lastCheck: check.lastCheck,
        details: check.details
      };

      if (check.status === 'unhealthy') {
        status.overall = 'unhealthy';
      } else if (check.status === 'degraded' && status.overall === 'healthy') {
        status.overall = 'degraded';
      }
    });

    return status;
  }

  /**
   * 收集所有指标
   */
  async collectAll(): Promise<void> {
    for (const collector of this.collectors) {
      try {
        await collector.collect(this);
      } catch (error) {
        console.error('Error collecting metrics:', error);
      }
    }
  }

  /**
   * 导出指标
   */
  export(format: 'json' | 'csv' | 'prometheus'): string {
    switch (format) {
      case 'json':
        return JSON.stringify({
          metrics: this.metrics,
          healthChecks: this.healthChecks,
          stats: this.getMetricsStats()
        }, null, 2);

      case 'csv':
        return this.exportToCSV();

      case 'prometheus':
        return this.exportToPrometheus();

      default:
        throw new Error(`Unsupported format: ${format}`);
    }
  }

  /**
   * 清理旧的指标数据
   */
  cleanup(maxAge: number = 86400000): void { // 默认24小时
    const cutoff = Date.now() - maxAge;
    
    this.metrics = this.metrics.filter(m => m.timestamp > cutoff);
    this.healthChecks = this.healthChecks.filter(h => h.lastCheck > cutoff);
  }

  /**
   * 销毁收集器
   */
  destroy(): void {
    if (this.reportingInterval) {
      clearInterval(this.reportingInterval);
    }
  }

  // ==================== 私有方法 ====================

  /**
   * 报告指标
   */
  private reportMetrics(): void {
    const stats = this.getMetricsStats();
    const health = this.getHealthStatus();

    // 这里可以添加自定义的报告逻辑
    console.log('[MetricsCollector] Reporting metrics:', {
      totalMetrics: stats.total,
      healthStatus: health.overall,
      services: Object.keys(health.services)
    });
  }

  /**
   * 导出为CSV
   */
  private exportToCSV(): string {
    const headers = ['timestamp', 'name', 'value', 'tags'];
    const rows = this.metrics.map(m => [
      m.timestamp,
      m.name,
      m.value,
      m.tags ? JSON.stringify(m.tags) : ''
    ]);

    return [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
  }

  /**
   * 导出为Prometheus格式
   */
  private exportToPrometheus(): string {
    const lines: string[] = [];

    this.metrics.forEach(metric => {
      let line = `${metric.name}`;
      
      if (metric.tags) {
        const tags = Object.entries(metric.tags)
          .map(([key, value]) => `${key}="${value}"`)
          .join(',');
        line += `{${tags}}`;
      }
      
      line += ` ${metric.value} ${metric.timestamp}`;
      lines.push(line);
    });

    return lines.join('\n');
  }

  /**
   * 计算平均值
   */
  private calculateAverage(values: number[]): number {
    if (values.length === 0) return 0;
    return values.reduce((sum, val) => sum + val, 0) / values.length;
  }

  /**
   * 计算百分位数
   */
  private calculatePercentiles(values: number[]): Percentiles {
    if (values.length === 0) {
      return { p50: 0, p90: 0, p95: 0, p99: 0 };
    }

    const sorted = [...values].sort((a, b) => a - b);
    const p = (percentile: number) => {
      const index = Math.ceil((percentile / 100) * sorted.length) - 1;
      return sorted[Math.max(0, Math.min(index, sorted.length - 1))];
    };

    return {
      p50: p(50),
      p90: p(90),
      p95: p(95),
      p99: p(99)
    };
  }
}

/**
 * 指标收集器接口
 */
export interface MetricCollector {
  collect(collector: MetricsCollector): Promise<void>;
}

/**
 * 指标统计
 */
export interface MetricsStats {
  total: number;
  byName: Record<string, number[]>;
  byTags: Record<string, number[]>;
  averages: Record<string, number>;
  percentiles: Record<string, Percentiles>;
}

/**
 * 健康状态
 */
export interface HealthStatus {
  overall: 'healthy' | 'unhealthy' | 'degraded';
  services: Record<string, {
    status: 'healthy' | 'unhealthy' | 'degraded';
    message?: string;
    lastCheck: number;
    details?: any;
  }>;
  lastUpdated: number;
}

/**
 * 百分位数
 */
export interface Percentiles {
  p50: number;
  p90: number;
  p95: number;
  p99: number;
}

/**
 * 系统指标收集器
 */
export class SystemMetricsCollector implements MetricCollector {
  async collect(collector: MetricsCollector): Promise<void> {
    // CPU使用率（简化实现）
    collector.record({
      name: 'system.cpu.usage',
      value: Math.random() * 100,
      timestamp: Date.now(),
      tags: { unit: 'percentage' }
    });

    // 内存使用率
    if ('memory' in performance) {
      const memory = (performance as any).memory;
      collector.record({
        name: 'system.memory.used',
        value: memory.usedJSHeapSize,
        timestamp: Date.now(),
        tags: { unit: 'bytes' }
      });

      collector.record({
        name: 'system.memory.total',
        value: memory.totalJSHeapSize,
        timestamp: Date.now(),
        tags: { unit: 'bytes' }
      });
    }

    // 网络状态
    if ('connection' in navigator) {
      const connection = (navigator as any).connection;
      collector.record({
        name: 'network.effective_type',
        value: connection.effectiveType === '4g' ? 4 : 
               connection.effectiveType === '3g' ? 3 : 
               connection.effectiveType === '2g' ? 2 : 1,
        timestamp: Date.now(),
        tags: { type: connection.effectiveType }
      });
    }
  }
}

/**
 * 语音服务指标收集器
 */
export class VoiceServiceMetricsCollector implements MetricCollector {
  async collect(collector: MetricsCollector): Promise<void> {
    // 这里可以收集语音服务相关的指标
    // 如：请求延迟、成功率、错误率等
  }
}

/**
 * 聚合指标接口
 */
export interface AggregatedMetrics {
  [metricName: string]: {
    count: number;
    sum: number;
    avg: number;
    min: number;
    max: number;
    latest: number;
  };
}

/**
 * 指标统计接口
 */
export interface MetricStatistics {
  count: number;
  min: number;
  max: number;
  avg: number;
  sum: number;
  p50: number;
  p95: number;
  p99: number;
}

/**
 * 指标聚合器接口
 */
export interface MetricAggregator {
  aggregate(metrics: Metrics[]): number;
}

/**
 * 创建指标收集器实例
 */
export function createMetricsCollector(): MetricsCollector {
  return new MetricsCollector();
}

/**
 * 语音服务专用指标收集器
 */
export class VoiceMetricsCollector extends MetricsCollector {
  /**
   * 记录连接时间
   */
  recordConnectionTime(duration: number): void {
    this.record({
      name: 'connection_time',
      value: duration,
      timestamp: Date.now()
    });
  }

  /**
   * 记录音频处理时间
   */
  recordAudioProcessingTime(duration: number): void {
    this.record({
      name: 'audio_processing_time',
      value: duration,
      timestamp: Date.now()
    });
  }

  /**
   * 记录API响应时间
   */
  recordApiResponseTime(duration: number, endpoint: string): void {
    this.record({
      name: 'api_response_time',
      value: duration,
      timestamp: Date.now(),
      tags: { endpoint }
    });
  }

  /**
   * 记录错误
   */
  recordError(errorType: string): void {
    this.record({
      name: 'error',
      value: 1,
      timestamp: Date.now(),
      tags: { type: errorType }
    });
  }

  /**
   * 记录重试次数
   */
  recordRetryCount(count: number, operation: string): void {
    this.record({
      name: 'retry_count',
      value: count,
      timestamp: Date.now(),
      tags: { operation }
    });
  }

  /**
   * 记录会话持续时间
   */
  recordSessionDuration(duration: number): void {
    this.record({
      name: 'session_duration',
      value: duration,
      timestamp: Date.now()
    });
  }

  /**
   * 记录音频数据量
   */
  recordAudioDataSize(size: number): void {
    this.record({
      name: 'audio_data_size',
      value: size,
      timestamp: Date.now()
    });
  }

  /**
   * 记录CDN切换
   */
  recordCdnSwitch(from: string, to: string): void {
    this.record({
      name: 'cdn_switch',
      value: 1,
      timestamp: Date.now(),
      tags: { from, to }
    });
  }

  /**
   * 获取语音服务统计
   */
  getVoiceStatistics(): {
    connectionStats: MetricStatistics;
    audioStats: MetricStatistics;
    errorStats: MetricStatistics;
    retryStats: MetricStatistics;
  } {
    const connectionStats = this.getMetricsStats();
    const audioStats = this.getMetricsStats();
    const errorStats = this.getMetricsStats();
    const retryStats = this.getMetricsStats();

    return {
      connectionStats: {
        count: connectionStats.total,
        min: 0,
        max: 0,
        avg: 0,
        sum: 0,
        p50: 0,
        p95: 0,
        p99: 0
      },
      audioStats: {
        count: audioStats.total,
        min: 0,
        max: 0,
        avg: 0,
        sum: 0,
        p50: 0,
        p95: 0,
        p99: 0
      },
      errorStats: {
        count: errorStats.total,
        min: 0,
        max: 0,
        avg: 0,
        sum: 0,
        p50: 0,
        p95: 0,
        p99: 0
      },
      retryStats: {
        count: retryStats.total,
        min: 0,
        max: 0,
        avg: 0,
        sum: 0,
        p50: 0,
        p95: 0,
        p99: 0
      }
    };
  }
}