import { LogEntry } from '../types';

/**
 * 日志管理器 - 提供统一的日志记录功能
 * 
 * 职责：
 * 1. 统一的日志格式
 * 2. 日志级别控制
 * 3. 日志输出到多个目标
 * 4. 日志轮转和清理
 */
export class Logger {
  private level: 'debug' | 'info' | 'warn' | 'error' = 'info';
  private outputs: LogOutput[] = [];
  private context: Record<string, any> = {};

  constructor(level?: 'debug' | 'info' | 'warn' | 'error') {
    if (level) {
      this.level = level;
    }
    
    // 默认添加控制台输出
    this.addOutput(new ConsoleOutput());
  }

  /**
   * 设置日志级别
   */
  setLevel(level: 'debug' | 'info' | 'warn' | 'error'): void {
    this.level = level;
  }

  /**
   * 添加输出目标
   */
  addOutput(output: LogOutput): void {
    this.outputs.push(output);
  }

  /**
   * 移除输出目标
   */
  removeOutput(output: LogOutput): void {
    const index = this.outputs.indexOf(output);
    if (index > -1) {
      this.outputs.splice(index, 1);
    }
  }

  /**
   * 设置上下文
   */
  setContext(context: Record<string, any>): void {
    this.context = { ...this.context, ...context };
  }

  /**
   * 清除上下文
   */
  clearContext(): void {
    this.context = {};
  }

  /**
   * 调试日志
   */
  debug(message: string, metadata?: any): void {
    if (this.shouldLog('debug')) {
      this.log('debug', message, metadata);
    }
  }

  /**
   * 信息日志
   */
  info(message: string, metadata?: any): void {
    if (this.shouldLog('info')) {
      this.log('info', message, metadata);
    }
  }

  /**
   * 警告日志
   */
  warn(message: string, metadata?: any): void {
    if (this.shouldLog('warn')) {
      this.log('warn', message, metadata);
    }
  }

  /**
   * 错误日志
   */
  error(message: string, metadata?: any): void {
    if (this.shouldLog('error')) {
      this.log('error', message, metadata);
    }
  }

  /**
   * 记录性能日志
   */
  performance(operation: string, duration: number, metadata?: any): void {
    this.info(`Performance: ${operation} took ${duration}ms`, {
      ...metadata,
      operation,
      duration,
      type: 'performance'
    });
  }

  /**
   * 记录错误
   */
  errorWithStack(error: Error, context?: string): void {
    this.error(error.message, {
      stack: error.stack,
      context,
      type: 'error_with_stack'
    });
  }

  // ==================== 私有方法 ====================

  /**
   * 检查是否应该记录日志
   */
  private shouldLog(level: 'debug' | 'info' | 'warn' | 'error'): boolean {
    const levels = ['debug', 'info', 'warn', 'error'];
    const currentLevelIndex = levels.indexOf(this.level);
    const logLevelIndex = levels.indexOf(level);
    
    return logLevelIndex >= currentLevelIndex;
  }

  /**
   * 记录日志
   */
  private log(level: 'debug' | 'info' | 'warn' | 'error', message: string, metadata?: any): void {
    const logEntry: LogEntry = {
      level,
      message,
      timestamp: Date.now(),
      metadata: {
        ...this.context,
        ...metadata,
        pid: process?.pid || 0,
        timestamp: new Date().toISOString()
      }
    };

    // 输出到所有目标
    this.outputs.forEach(output => {
      try {
        output.write(logEntry);
      } catch (error) {
        console.error('Error writing log:', error);
      }
    });
  }
}

/**
 * 日志输出接口
 */
export interface LogOutput {
  write(entry: LogEntry): void;
}

/**
 * 控制台输出
 */
export class ConsoleOutput implements LogOutput {
  write(entry: LogEntry): void {
    const message = this.formatMessage(entry);
    
    switch (entry.level) {
      case 'debug':
        console.debug(message);
        break;
      case 'info':
        console.info(message);
        break;
      case 'warn':
        console.warn(message);
        break;
      case 'error':
        console.error(message);
        break;
    }
  }

  private formatMessage(entry: LogEntry): string {
    const timestamp = new Date(entry.timestamp).toISOString();
    const metadata = entry.metadata ? JSON.stringify(entry.metadata, null, 2) : '';
    
    return `[${timestamp}] ${entry.level.toUpperCase()}: ${entry.message}${metadata ? '\n' + metadata : ''}`;
  }
}

/**
 * 文件输出（简化版）
 */
export class FileOutput implements LogOutput {
  private buffer: string[] = [];
  private flushInterval: any;

  constructor(private filePath: string, private flushDelay: number = 5000) {
    // 定期刷新缓冲区
    this.flushInterval = setInterval(() => {
      this.flush();
    }, flushDelay);
  }

  write(entry: LogEntry): void {
    this.buffer.push(JSON.stringify(entry));
    
    // 如果是错误日志，立即刷新
    if (entry.level === 'error') {
      this.flush();
    }
  }

  private flush(): void {
    if (this.buffer.length === 0) {
      return;
    }

    const content = this.buffer.join('\n') + '\n';
    this.buffer = [];

    // 这里需要使用Node.js的fs模块或浏览器的File API
    // 简化实现：输出到控制台
    console.log(`[FileOutput] Would write to ${this.filePath}:`, content);
  }

  destroy(): void {
    if (this.flushInterval) {
      clearInterval(this.flushInterval);
    }
    this.flush();
  }
}

/**
 * 远程输出
 */
export class RemoteOutput implements LogOutput {
  constructor(
    private endpoint: string,
    private apiKey?: string
  ) {}

  async write(entry: LogEntry): Promise<void> {
    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json'
      };

      if (this.apiKey) {
        headers['Authorization'] = `Bearer ${this.apiKey}`;
      }

      await fetch(this.endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify(entry)
      });
    } catch (error) {
      console.error('Failed to send log to remote endpoint:', error);
    }
  }
}

/**
 * 创建默认Logger实例
 */
export function createLogger(level?: 'debug' | 'info' | 'warn' | 'error'): Logger {
  return new Logger(level);
}