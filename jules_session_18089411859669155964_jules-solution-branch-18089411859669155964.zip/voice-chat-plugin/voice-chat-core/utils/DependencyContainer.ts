import { TYPES } from '../types';

/**
 * 依赖注入容器 - 实现控制反转
 * 
 * 职责：
 * 1. 管理依赖的注册和解析
 * 2. 实现单例和工厂模式
 * 3. 提供依赖的生命周期管理
 * 4. 支持依赖的延迟加载
 */
export class DependencyContainer {
  private bindings: Map<symbol, Binding<any>> = new Map();
  private singletons: Map<symbol, any> = new Map();

  /**
   * 绑定接口到实现
   */
  bind<T>(token: symbol): BindingBuilder<T> {
    return new BindingBuilder<T>(this, token);
  }

  /**
   * 解析依赖
   */
  get<T>(token: symbol): T {
    const binding = this.bindings.get(token);
    
    if (!binding) {
      throw new Error(`No binding found for token: ${token.toString()}`);
    }

    // 如果是单例且已存在，直接返回
    if (binding.isSingleton && this.singletons.has(token)) {
      return this.singletons.get(token);
    }

    // 创建实例
    const instance = binding.factory(this);

    // 如果是单例，缓存实例
    if (binding.isSingleton) {
      this.singletons.set(token, instance);
    }

    return instance;
  }

  /**
   * 检查是否已绑定
   */
  isBound(token: symbol): boolean {
    return this.bindings.has(token);
  }

  /**
   * 解绑
   */
  unbind(token: symbol): void {
    this.bindings.delete(token);
    this.singletons.delete(token);
  }

  /**
   * 清空所有绑定
   */
  reset(): void {
    this.bindings.clear();
    this.singletons.clear();
  }

  /**
   * 注册绑定
   */
  private register<T>(token: symbol, binding: Binding<T>): void {
    this.bindings.set(token, binding as Binding<any>);
  }
}

/**
 * 绑定构建器 - 用于配置依赖绑定
 */
export class BindingBuilder<T> {
  constructor(
    private container: DependencyContainer,
    private token: symbol
  ) {}

  /**
   * 绑定到类
   */
  to(Class: new (...args: any[]) => T): void {
    this.container.register(this.token, {
      isSingleton: false,
      factory: (container: DependencyContainer) => {
        // 自动解析构造函数参数
        const instance = this.resolveDependencies(Class, container);
        return instance;
      }
    });
  }

  /**
   * 绑定到单例类
   */
  toSingleton(Class: new (...args: any[]) => T): void {
    this.container.register(this.token, {
      isSingleton: true,
      factory: (container: DependencyContainer) => {
        const instance = this.resolveDependencies(Class, container);
        return instance;
      }
    });
  }

  /**
   * 绑定到值
   */
  toValue(value: T): void {
    this.container.register(this.token, {
      isSingleton: true,
      factory: () => value
    });
  }

  /**
   * 绑定到工厂函数
   */
  toFactory(factory: (container: DependencyContainer) => T): void {
    this.container.register(this.token, {
      isSingleton: false,
      factory
    });
  }

  /**
   * 绑定到单例工厂函数
   */
  toSingletonFactory(factory: (container: DependencyContainer) => T): void {
    this.container.register(this.token, {
      isSingleton: true,
      factory
    });
  }

  /**
   * 解析类的依赖
   */
  private resolveDependencies<T>(Class: new (...args: any[]) => T, container: DependencyContainer): T {
    // 获取类的参数类型（需要在类上使用装饰器或手动配置）
    const dependencies = this.getDependencies(Class);
    
    // 解析每个依赖
    const args = dependencies.map(dep => container.get(dep));
    
    // 创建实例
    return new Class(...args);
  }

  /**
   * 获取类的依赖（简化实现）
   */
  private getDependencies<T>(Class: new (...args: any[]) => T): symbol[] {
    // 这里可以使用装饰器或反射来获取依赖
    // 简化实现：从类的静态属性获取
    return (Class as any).__dependencies__ || [];
  }
}

/**
 * 绑定接口
 */
interface Binding<T> {
  isSingleton: boolean;
  factory: (container: DependencyContainer) => T;
}

/**
 * 依赖装饰器
 */
export function inject(token: symbol) {
  return function (target: any, propertyKey: string, parameterIndex: number) {
    // 存储依赖信息
    const existingDependencies = target.__dependencies__ || [];
    existingDependencies[parameterIndex] = token;
    target.__dependencies__ = existingDependencies;
  };
}

/**
 * 创建标准的语音聊天服务容器
 */
export function createVoiceChatContainer(config: any) {
  const container = new DependencyContainer();

  // 绑定配置管理器
  container.bind(TYPES.ConfigManager)
    .toSingleton(ConfigManager)
    .toValue(config);

  // 绑定音频管理器
  container.bind(TYPES.AudioManager)
    .toSingleton(AudioManager)
    .toFactory((container) => {
      const configManager = container.get(TYPES.ConfigManager);
      return new AudioManager(configManager.getAudioConfig());
    });

  // 绑定网络管理器
  container.bind(TYPES.NetworkManager)
    .toSingleton(NetworkManager)
    .toFactory((container) => {
      const configManager = container.get(TYPES.ConfigManager);
      return new NetworkManager(configManager.getConfig().network);
    });

  // 绑定错误管理器
  container.bind(TYPES.ErrorManager)
    .toSingleton(ErrorManager);

  // 绑定重试管理器
  container.bind(TYPES.RetryManager)
    .toSingleton(RetryManager)
    .toFactory((container) => {
      const configManager = container.get(TYPES.ConfigManager);
      return new RetryManager(configManager.getConfig().voice.retry);
    });

  // 绑定会话管理器
  container.bind(TYPES.SessionManager)
    .toSingleton(SessionManager)
    .toFactory((container) => {
      const configManager = container.get(TYPES.ConfigManager);
      return new SessionManager(configManager.getSessionConfig());
    });

  // 绑定适配器工厂
  container.bind(TYPES.VoiceAdapterFactory)
    .toSingleton(VoiceAdapterFactory);

  // 绑定语音适配器
  container.bind(TYPES.VoiceAdapter)
    .toFactory((container) => {
      const configManager = container.get(TYPES.ConfigManager);
      const adapterFactory = container.get(TYPES.VoiceAdapterFactory);
      return adapterFactory.createAdapter(configManager.getConfig());
    });

  // 绑定语音服务
  container.bind(TYPES.VoiceService)
    .toSingleton(VoiceChatService);

  return container;
}