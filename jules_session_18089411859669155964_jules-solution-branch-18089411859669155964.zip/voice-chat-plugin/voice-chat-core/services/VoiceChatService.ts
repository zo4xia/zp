import { VoiceService, VoiceAdapter, VoiceResponse, VoiceSession, VoiceEvent, VoiceEventHandler, VoiceError, VoiceErrorType, ChatMessage, SessionState } from '../types';
import { AudioManager } from '../infrastructure/AudioManager';
import { ErrorManager } from '../infrastructure/ErrorManager';
import { RetryManager } from '../infrastructure/RetryManager';
import { SessionManager } from '../infrastructure/SessionManager';
import { NetworkManager } from '../infrastructure/NetworkManager';
import { ConfigManager } from '../infrastructure/ConfigManager';

/**
 * 语音聊天服务 - 实现模块隔离的核心服务
 * 
 * 职责：
 * 1. 协调各个基础设施管理器
 * 2. 管理语音交互的业务流程
 * 3. 处理服务级别的错误和降级
 * 4. 提供统一的语音服务接口
 */
export class VoiceChatService implements VoiceService {
  private adapter: VoiceAdapter;
  private audioManager: AudioManager;
  private errorManager: ErrorManager;
  private retryManager: RetryManager;
  private sessionManager: SessionManager;
  private networkManager: NetworkManager;
  private configManager: ConfigManager;
  
  private eventHandlers: Map<VoiceEvent, VoiceEventHandler[]> = new Map();
  private isStarted: boolean = false;
  private currentSession: VoiceSession | null = null;

  constructor(deps: {
    adapter: VoiceAdapter;
    audioManager: AudioManager;
    errorManager: ErrorManager;
    retryManager: RetryManager;
    sessionManager: SessionManager;
    networkManager: NetworkManager;
    configManager: ConfigManager;
  }) {
    this.adapter = deps.adapter;
    this.audioManager = deps.audioManager;
    this.errorManager = deps.errorManager;
    this.retryManager = deps.retryManager;
    this.sessionManager = deps.sessionManager;
    this.networkManager = deps.networkManager;
    this.configManager = deps.configManager;

    // 设置适配器事件监听
    this.setupAdapterEvents();
  }

  /**
   * 启动语音服务
   * 包含完整的启动检查和错误处理
   */
  async start(): Promise<void> {
    if (this.isStarted) {
      throw new VoiceError(VoiceErrorType.API_ERROR, 'Voice service is already started');
    }

    try {
      // 1. 健康检查
      await this.performHealthCheck();

      // 2. 初始化音频管理器
      await this.audioManager.initialize();

      // 3. 连接适配器
      await this.adapter.connect();

      // 4. 创建新会话
      this.currentSession = await this.sessionManager.createSession();

      this.isStarted = true;
      this.emit('connected', { sessionId: this.currentSession.id });

      console.log('[VoiceChatService] Service started successfully');
    } catch (error) {
      const voiceError = this.errorManager.handleError(error, 'VoiceChatService.start');
      this.emit('error', voiceError);
      throw voiceError;
    }
  }

  /**
   * 停止语音服务
   * 确保所有资源正确释放
   */
  async stop(): Promise<void> {
    if (!this.isStarted) {
      return;
    }

    try {
      // 1. 断开适配器连接
      await this.adapter.disconnect();

      // 2. 清理音频资源
      await this.audioManager.cleanup();

      // 3. 结束当前会话
      if (this.currentSession) {
        await this.sessionManager.endSession(this.currentSession.id);
        this.currentSession = null;
      }

      this.isStarted = false;
      this.emit('disconnected');

      console.log('[VoiceChatService] Service stopped successfully');
    } catch (error) {
      const voiceError = this.errorManager.handleError(error, 'VoiceChatService.stop');
      this.emit('error', voiceError);
      // 停止服务时的错误不应阻止服务关闭
      console.warn('[VoiceChatService] Error during stop:', voiceError.message);
    }
  }

  /**
   * 发送音频数据
   * 包含重试机制和会话管理
   */
  async sendAudio(audioData: Float32Array): Promise<VoiceResponse> {
    if (!this.isStarted) {
      throw new VoiceError(VoiceErrorType.API_ERROR, 'Voice service is not started');
    }

    try {
      // 1. 检查网络状态
      const networkStatus = await this.networkManager.getStatus();
      if (!networkStatus.isOnline) {
        throw new VoiceError(VoiceErrorType.NETWORK_ERROR, 'Network is offline');
      }

      // 2. 检查会话状态
      if (!this.currentSession || !this.currentSession.isActive) {
        this.currentSession = await this.sessionManager.createSession();
      }

      // 3. 更新会话活动时间
      await this.sessionManager.updateActivity(this.currentSession.id);

      // 4. 使用重试机制发送音频
      const response = await this.retryManager.executeWithRetry(
        () => this.adapter.sendAudio(audioData, this.audioManager.getInputSampleRate()),
        `sendAudio`
      );

      // 5. 记录到会话历史
      if (response.transcription) {
        await this.sessionManager.addMessage(this.currentSession.id, {
          id: this.generateId(),
          role: 'user',
          content: response.transcription,
          timestamp: Date.now(),
          type: 'transcription'
        });
      }

      return response;
    } catch (error) {
      const voiceError = this.errorManager.handleError(error, 'VoiceChatService.sendAudio');
      this.emit('error', voiceError);
      throw voiceError;
    }
  }

  /**
   * 发送文本消息
   * 用于降级到文字聊天
   */
  async sendText(text: string): Promise<VoiceResponse> {
    if (!this.isStarted) {
      throw new VoiceError(VoiceErrorType.API_ERROR, 'Voice service is not started');
    }

    try {
      // 1. 检查会话状态
      if (!this.currentSession || !this.currentSession.isActive) {
        this.currentSession = await this.sessionManager.createSession();
      }

      // 2. 更新会话活动时间
      await this.sessionManager.updateActivity(this.currentSession.id);

      // 3. 记录用户消息到历史
      await this.sessionManager.addMessage(this.currentSession.id, {
        id: this.generateId(),
        role: 'user',
        content: text,
        timestamp: Date.now(),
        type: 'text'
      });

      // 4. 发送文本到适配器
      const response = await this.retryManager.executeWithRetry(
        () => this.adapter.sendText(text),
        `sendText`
      );

      // 5. 记录助手回复到历史
      if (response.text) {
        await this.sessionManager.addMessage(this.currentSession.id, {
          id: this.generateId(),
          role: 'assistant',
          content: response.text,
          timestamp: Date.now(),
          type: 'text'
        });
      }

      return response;
    } catch (error) {
      const voiceError = this.errorManager.handleError(error, 'VoiceChatService.sendText');
      this.emit('error', voiceError);
      throw voiceError;
    }
  }

  /**
   * 获取当前会话信息
   */
  getSession(): VoiceSession | null {
    return this.currentSession;
  }

  /**
   * 添加事件监听器
   */
  on(event: VoiceEvent, handler: VoiceEventHandler): void {
    if (!this.eventHandlers.has(event)) {
      this.eventHandlers.set(event, []);
    }
    this.eventHandlers.get(event)!.push(handler);
  }

  /**
   * 移除事件监听器
   */
  off(event: VoiceEvent, handler: VoiceEventHandler): void {
    const handlers = this.eventHandlers.get(event);
    if (handlers) {
      const index = handlers.indexOf(handler);
      if (index > -1) {
        handlers.splice(index, 1);
      }
    }
  }

  /**
   * 获取会话历史
   */
  async getSessionHistory(sessionId?: string): Promise<ChatMessage[]> {
    const id = sessionId || this.currentSession?.id;
    if (!id) {
      return [];
    }
    return this.sessionManager.getHistory(id);
  }

  /**
   * 清除会话历史
   */
  async clearSessionHistory(sessionId?: string): Promise<void> {
    const id = sessionId || this.currentSession?.id;
    if (!id) {
      return;
    }
    await this.sessionManager.clearHistory(id);
  }

  /**
   * 手动恢复会话
   */
  async resumeSession(sessionId: string): Promise<boolean> {
    try {
      const session = await this.sessionManager.resumeSession(sessionId);
      if (session) {
        this.currentSession = session;
        this.emit('session_resumed', session);
        return true;
      }
      return false;
    } catch (error) {
      const voiceError = this.errorManager.handleError(error, 'VoiceChatService.resumeSession');
      this.emit('error', voiceError);
      return false;
    }
  }

  // ==================== 私有方法 ====================

  /**
   * 设置适配器事件监听
   */
  private setupAdapterEvents(): void {
    const events: VoiceEvent[] = ['audio_start', 'audio_end', 'transcription', 'response', 'error'];
    
    events.forEach(event => {
      this.adapter.on(event, (data) => {
        this.emit(event, data);
      });
    });
  }

  /**
   * 执行健康检查
   */
  private async performHealthCheck(): Promise<void> {
    // 检查网络连接
    const networkStatus = await this.networkManager.getStatus();
    if (!networkStatus.isOnline) {
      throw new VoiceError(VoiceErrorType.NETWORK_ERROR, 'Network is not available');
    }

    // 检查音频设备
    const audioDevices = await this.audioManager.getAvailableDevices();
    if (audioDevices.microphones.length === 0) {
      throw new VoiceError(VoiceErrorType.AUDIO_ERROR, 'No microphone available');
    }

    // 检查配置
    const config = this.configManager.getConfig();
    if (!config.voice.api.google.models.live) {
      throw new VoiceError(VoiceErrorType.CONFIG_ERROR, 'Voice model configuration is missing');
    }
  }

  /**
   * 触发事件
   */
  private emit(event: VoiceEvent, data?: any): void {
    const handlers = this.eventHandlers.get(event) || [];
    handlers.forEach(handler => {
      try {
        handler(event, data);
      } catch (error) {
        console.error(`Error in event handler for ${event}:`, error);
      }
    });
  }

  /**
   * 生成唯一ID
   */
  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}