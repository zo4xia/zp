import { VoiceAdapter, VoiceConfig } from '../types';
import { GoogleLiveAdapter } from '../infrastructure/GoogleLiveAdapter';
import { GoogleTextAdapter } from '../infrastructure/GoogleTextAdapter';
import { LocalTTSAdapter } from '../infrastructure/LocalTTSAdapter';
import { AudioManager } from '../infrastructure/AudioManager';
import { ErrorManager } from '../infrastructure/ErrorManager';
import { NetworkManager } from '../infrastructure/NetworkManager';
import { ConfigManager } from '../infrastructure/ConfigManager';

/**
 * 语音适配器工厂 - 负责创建不同类型的语音适配器
 * 
 * 职责：
 * 1. 根据配置创建合适的适配器
 * 2. 管理适配器的依赖注入
 * 3. 提供适配器的配置验证
 */
export class VoiceAdapterFactory {
  /**
   * 根据配置创建适配器
   */
  createAdapter(config: VoiceConfig): VoiceAdapter {
    // 创建共享的基础设施管理器
    const audioManager = new AudioManager({
      sampleRate: config.audio.inputSampleRate,
      channels: 1,
      bufferSize: config.audio.bufferSize
    });
    
    const errorManager = new ErrorManager();
    const networkManager = new NetworkManager({
      timeout: 30000,
      retryConfig: config.retry,
      endpoints: config.api.google.endpoints
    });
    
    const configManager = new ConfigManager({
      voice: config,
      network: {
        timeout: 30000,
        retryConfig: config.retry,
        endpoints: config.api.google.endpoints
      },
      session: {
        timeout: config.session.timeout,
        resumeEnabled: config.session.resumeEnabled,
        maxHistory: 100
      },
      audio: {
        inputSampleRate: config.audio.inputSampleRate,
        outputSampleRate: config.audio.outputSampleRate,
        bufferSize: config.audio.bufferSize
      }
    });

    // 根据配置选择适配器类型
    const adapterType = this.determineAdapterType(config);
    
    switch (adapterType) {
      case 'google-live':
        return new GoogleLiveAdapter({
          audioManager,
          errorManager,
          networkManager,
          configManager
        });
        
      case 'google-text':
        return new GoogleTextAdapter({
          audioManager,
          errorManager,
          networkManager,
          configManager
        });
        
      case 'local-tts':
        return new LocalTTSAdapter({
          audioManager,
          errorManager,
          configManager
        });
        
      default:
        throw new Error(`Unknown adapter type: ${adapterType}`);
    }
  }

  /**
   * 创建Google Live适配器
   */
  createGoogleLiveAdapter(deps: {
    audioManager: AudioManager;
    errorManager: ErrorManager;
    networkManager: NetworkManager;
    configManager: ConfigManager;
  }): VoiceAdapter {
    return new GoogleLiveAdapter(deps);
  }

  /**
   * 创建Google Text适配器
   */
  createGoogleTextAdapter(deps: {
    audioManager: AudioManager;
    errorManager: ErrorManager;
    networkManager: NetworkManager;
    configManager: ConfigManager;
  }): VoiceAdapter {
    return new GoogleTextAdapter(deps);
  }

  /**
   * 创建本地TTS适配器
   */
  createLocalTTSAdapter(deps: {
    audioManager: AudioManager;
    errorManager: ErrorManager;
    configManager: ConfigManager;
  }): VoiceAdapter {
    return new LocalTTSAdapter(deps);
  }

  /**
   * 确定适配器类型
   */
  private determineAdapterType(config: VoiceConfig): string {
    // 检查是否有Live API配置
    if (config.api.google.models.live) {
      return 'google-live';
    }
    
    // 检查是否有Text API配置
    if (config.api.google.models.text) {
      return 'google-text';
    }
    
    // 默认使用本地TTS
    return 'local-tts';
  }

  /**
   * 验证适配器配置
   */
  validateAdapterConfig(config: VoiceConfig, adapterType: string): boolean {
    switch (adapterType) {
      case 'google-live':
        return this.validateGoogleLiveConfig(config);
        
      case 'google-text':
        return this.validateGoogleTextConfig(config);
        
      case 'local-tts':
        return this.validateLocalTTSConfig(config);
        
      default:
        return false;
    }
  }

  /**
   * 验证Google Live配置
   */
  private validateGoogleLiveConfig(config: VoiceConfig): boolean {
    return !!(
      config.api.google.apiKeys &&
      config.api.google.apiKeys.length > 0 &&
      config.api.google.models.live &&
      config.cdn.google &&
      config.cdn.google.length > 0
    );
  }

  /**
   * 验证Google Text配置
   */
  private validateGoogleTextConfig(config: VoiceConfig): boolean {
    return !!(
      config.api.google.apiKeys &&
      config.api.google.apiKeys.length > 0 &&
      config.api.google.models.text
    );
  }

  /**
   * 验证本地TTS配置
   */
  private validateLocalTTSConfig(config: VoiceConfig): boolean {
    // 本地TTS只需要基本的音频配置
    return !!(
      config.audio.inputSampleRate &&
      config.audio.outputSampleRate
    );
  }

  /**
   * 获取支持的适配器列表
   */
  getSupportedAdapters(): string[] {
    return ['google-live', 'google-text', 'local-tts'];
  }

  /**
   * 检查适配器是否可用
   */
  async checkAdapterAvailability(adapterType: string): Promise<boolean> {
    switch (adapterType) {
      case 'google-live':
        return this.checkGoogleLiveAvailability();
        
      case 'google-text':
        return this.checkGoogleTextAvailability();
        
      case 'local-tts':
        return this.checkLocalTTSAvailability();
        
      default:
        return false;
    }
  }

  /**
   * 检查Google Live是否可用
   */
  private async checkGoogleLiveAvailability(): Promise<boolean> {
    try {
      // 检查网络连接
      const response = await fetch('https://generativelanguage.googleapis.com', {
        method: 'HEAD',
        mode: 'no-cors'
      });
      return true;
    } catch (error) {
      return false;
    }
  }

  /**
   * 检查Google Text是否可用
   */
  private async checkGoogleTextAvailability(): Promise<boolean> {
    return this.checkGoogleLiveAvailability(); // 与Live API使用相同的端点
  }

  /**
   * 检查本地TTS是否可用
   */
  private checkLocalTTSAvailability(): boolean {
    return 'speechSynthesis' in window;
  }
}