# Google语音模块 - 模块隔离架构

## 架构概述

本项目采用**分层架构**和**依赖注入**模式，实现Google语音模块的完全隔离，确保模块间的低耦合和高内聚。

## 架构图

```
┌─────────────────────────────────────────────────────────────┐
│                    应用层 (Application Layer)                 │
├─────────────────────────────────────────────────────────────┤
│  App.tsx  │  ProfilePage  │  MapPage  │  DetailPage         │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    服务层 (Service Layer)                     │
├─────────────────────────────────────────────────────────────┤
│  VoiceChatService  │  TextChatService  │  FallbackService   │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    适配器层 (Adapter Layer)                   │
├─────────────────────────────────────────────────────────────┤
│  GoogleLiveAdapter  │  GoogleTextAdapter  │  LocalTTSAdapter │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    基础设施层 (Infrastructure)                │
├─────────────────────────────────────────────────────────────┤
│  AudioManager  │  NetworkManager  │  ConfigManager  │       │
│  ErrorManager  │  RetryManager   │  SessionManager │       │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    外部依赖 (External Dependencies)           │
├─────────────────────────────────────────────────────────────┤
│  Google GenAI SDK  │  Web Speech API  │  CDN Resources      │
└─────────────────────────────────────────────────────────────┘
```

## 核心设计原则

### 1. 单一职责原则 (SRP)
- 每个模块只负责一个特定功能
- VoiceChatService 只负责语音交互流程
- AudioManager 只负责音频资源管理
- NetworkManager 只负责网络连接管理

### 2. 依赖倒置原则 (DIP)
- 高层模块不依赖低层模块，都依赖抽象
- 使用接口而非具体实现
- 便于单元测试和模块替换

### 3. 接口隔离原则 (ISP)
- 定义最小化的接口
- 避免实现不必要的方法
- 减少模块间的耦合

### 4. 开闭原则 (OCP)
- 对扩展开放，对修改关闭
- 新增功能通过添加新模块实现
- 不修改现有稳定代码

## 模块职责划分

### 应用层 (Application Layer)
**职责**：用户界面和交互逻辑
- App.tsx：主应用入口，协调各个服务
- 页面组件：负责UI展示和用户交互

**依赖**：服务层接口

### 服务层 (Service Layer)
**职责**：业务逻辑和流程控制
- VoiceChatService：语音聊天业务逻辑
- TextChatService：文字聊天业务逻辑
- FallbackService：降级和备用方案

**依赖**：适配器层接口

### 适配器层 (Adapter Layer)
**职责**：与外部系统的接口适配
- GoogleLiveAdapter：Google Live API适配器
- GoogleTextAdapter：Google Text API适配器
- LocalTTSAdapter：本地TTS适配器

**依赖**：基础设施层

### 基础设施层 (Infrastructure)
**职责**：通用功能和资源管理
- AudioManager：音频资源管理
- NetworkManager：网络连接管理
- ConfigManager：配置管理
- ErrorManager：错误处理
- RetryManager：重试机制
- SessionManager：会话管理

**依赖**：外部依赖

## 数据流

```
用户输入 → 应用层 → 服务层 → 适配器层 → 基础设施层 → 外部依赖
     ↑                                                                        │
     └──────────────── 响应数据 ← 响应处理 ← 错误处理 ← 重试机制 ←─────────────┘
```

## 错误处理策略

### 1. 分层错误处理
- **应用层**：用户友好的错误提示
- **服务层**：业务逻辑错误处理
- **适配器层**：外部API错误处理
- **基础设施层**：系统级错误处理

### 2. 降级策略
1. **Google Live API** → **Google Text API** → **本地TTS**
2. **主CDN** → **备用CDN** → **本地资源**
3. **实时语音** → **文字聊天** → **离线模式**

### 3. 重试机制
- 指数退避算法
- 最大重试次数限制
- 网络恢复检测

## 配置管理

### 环境配置
```typescript
interface VoiceConfig {
  // API配置
  api: {
    google: {
      models: {
        live: string;
        text: string;
        fallback: string;
      };
      endpoints: {
        primary: string;
        backup: string;
      };
    };
  };
  
  // CDN配置
  cdn: {
    google: string[];
    fallback: string[];
    local: string;
  };
  
  // 重试配置
  retry: {
    maxAttempts: number;
    baseDelay: number;
    maxDelay: number;
  };
  
  // 会话配置
  session: {
    timeout: number;
    resumeEnabled: boolean;
  };
}
```

## 使用示例

### 基本使用
```typescript
// 1. 初始化配置管理器
const configManager = new ConfigManager(config);

// 2. 初始化基础设施
const audioManager = new AudioManager();
const networkManager = new NetworkManager(configManager);
const errorManager = new ErrorManager();

// 3. 初始化适配器
const googleLiveAdapter = new GoogleLiveAdapter({
  configManager,
  audioManager,
  networkManager,
  errorManager
});

// 4. 初始化服务
const voiceChatService = new VoiceChatService({
  adapter: googleLiveAdapter,
  errorManager,
  retryManager
});

// 5. 使用服务
await voiceChatService.startConversation();
```

### 依赖注入
```typescript
// 使用依赖注入容器
const container = new Container();

container.bind<ConfigManager>(TYPES.ConfigManager).to(ConfigManager);
container.bind<AudioManager>(TYPES.AudioManager).to(AudioManager);
container.bind<GoogleLiveAdapter>(TYPES.GoogleLiveAdapter).to(GoogleLiveAdapter);
container.bind<VoiceChatService>(TYPES.VoiceChatService).to(VoiceChatService);

// 获取服务实例
const voiceChatService = container.get<VoiceChatService>(TYPES.VoiceChatService);
```

## 测试策略

### 单元测试
- 每个模块独立测试
- 使用Mock对象隔离依赖
- 覆盖率目标：90%+

### 集成测试
- 模块间接口测试
- 端到端流程测试
- 错误场景测试

### 性能测试
- 音频处理性能
- 网络延迟测试
- 内存泄漏检测

## 部署和监控

### 健康检查
- API连接状态
- 音频设备状态
- 网络连接状态

### 日志记录
- 分层日志记录
- 错误追踪
- 性能指标收集

### 监控告警
- API失败率监控
- 响应时间监控
- 资源使用率监控

## 扩展性考虑

### 新增语音服务
1. 实现VoiceAdapter接口
2. 在配置中添加新服务配置
3. 在服务层添加路由逻辑

### 新增降级策略
1. 实现FallbackStrategy接口
2. 在FallbackService中注册
3. 配置触发条件

### 新增CDN
1. 在CDN配置中添加新地址
2. 实现CDN健康检查
3. 更新切换逻辑

## 最佳实践

1. **保持接口稳定**：避免频繁修改公共接口
2. **文档完善**：每个模块都有详细的使用文档
3. **代码规范**：遵循TypeScript最佳实践
4. **性能优化**：及时释放资源，避免内存泄漏
5. **错误恢复**：提供优雅的错误恢复机制