import { VoiceChatService } from '../services/VoiceChatService';
import { GoogleLiveAdapter } from '../infrastructure/GoogleLiveAdapter';
import { AudioManager } from '../infrastructure/AudioManager';
import { ErrorManager } from '../infrastructure/ErrorManager';
import { RetryManager } from '../infrastructure/RetryManager';
import { SessionManager } from '../infrastructure/SessionManager';
import { NetworkManager } from '../infrastructure/NetworkManager';
import { ConfigManager, createDefaultConfig } from '../infrastructure/ConfigManager';
import { VoiceError, VoiceErrorType } from '../types';

// Mock 依赖
jest.mock('../infrastructure/GoogleLiveAdapter');
jest.mock('../infrastructure/AudioManager');
jest.mock('../infrastructure/ErrorManager');
jest.mock('../infrastructure/RetryManager');
jest.mock('../infrastructure/SessionManager');
jest.mock('../infrastructure/NetworkManager');

describe('VoiceChatService', () => {
  let service: VoiceChatService;
  let mockAdapter: jest.Mocked<GoogleLiveAdapter>;
  let mockAudioManager: jest.Mocked<AudioManager>;
  let mockErrorManager: jest.Mocked<ErrorManager>;
  let mockRetryManager: jest.Mocked<RetryManager>;
  let mockSessionManager: jest.Mocked<SessionManager>;
  let mockNetworkManager: jest.Mocked<NetworkManager>;
  let mockConfigManager: jest.Mocked<ConfigManager>;

  beforeEach(() => {
    // 创建 Mock 对象
    mockAdapter = {
      connect: jest.fn(),
      disconnect: jest.fn(),
      sendAudio: jest.fn(),
      sendText: jest.fn(),
      on: jest.fn(),
      off: jest.fn()
    } as any;

    mockAudioManager = {
      initialize: jest.fn(),
      cleanup: jest.fn(),
      getAvailableDevices: jest.fn(),
      downsampleBuffer: jest.fn(),
      getInputSampleRate: jest.fn(),
      getOutputSampleRate: jest.fn(),
      startRecording: jest.fn(),
      stopRecording: jest.fn(),
      playAudio: jest.fn(),
      isReady: jest.fn(),
      setLogCallback: jest.fn(),
      setMetricsCallback: jest.fn()
    } as any;

    mockErrorManager = {
      handleError: jest.fn(),
      setLogCallback: jest.fn(),
      setMetricsCallback: jest.fn(),
      setHealthCallback: jest.fn(),
      getErrorStats: jest.fn(),
      resetErrorCount: jest.fn(),
      shouldTriggerFallback: jest.fn(),
      executeFallback: jest.fn()
    } as any;

    mockRetryManager = {
      executeWithRetry: jest.fn()
    } as any;

    mockSessionManager = {
      createSession: jest.fn(),
      endSession: jest.fn(),
      getSession: jest.fn(),
      addMessage: jest.fn(),
      getHistory: jest.fn(),
      clearHistory: jest.fn(),
      resumeSession: jest.fn(),
      updateActivity: jest.fn()
    } as any;

    mockNetworkManager = {
      getStatus: jest.fn(),
      getCurrentCdn: jest.fn(),
      performHealthCheck: jest.fn(),
      testLatency: jest.fn(),
      testBandwidth: jest.fn(),
      executeWithRetry: jest.fn(),
      switchCdn: jest.fn(),
      onStatusChange: jest.fn(),
      setMetricsCallback: jest.fn(),
      setLogCallback: jest.fn(),
      startHealthCheck: jest.fn(),
      stopHealthCheck: jest.fn(),
      cleanup: jest.fn()
    } as any;

    mockConfigManager = {
      getConfig: jest.fn(),
      getVoiceConfig: jest.fn(),
      getApiKey: jest.fn(),
      getNextApiKey: jest.fn(),
      getPrimaryCdn: jest.fn(),
      getFallbackCdns: jest.fn(),
      getLocalCdn: jest.fn(),
      updateConfig: jest.fn(),
      onConfigChange: jest.fn(),
      getCdnHealthCheckConfig: jest.fn(),
      getRetryConfig: jest.fn(),
      getSessionConfig: jest.fn(),
      getAudioConfig: jest.fn()
    } as any;

    // 设置默认返回值
    mockConfigManager.getConfig.mockReturnValue(createDefaultConfig());
    mockConfigManager.getAudioConfig.mockReturnValue({
      inputSampleRate: 16000,
      outputSampleRate: 24000,
      bufferSize: 4096
    });
    mockNetworkManager.getStatus.mockReturnValue({
      isOnline: true,
      latency: 100,
      lastCheck: Date.now()
    });
    mockSessionManager.createSession.mockResolvedValue({
      id: 'test-session',
      startTime: Date.now(),
      isActive: true,
      metadata: {}
    });

    // 创建服务实例
    service = new VoiceChatService({
      adapter: mockAdapter,
      audioManager: mockAudioManager,
      errorManager: mockErrorManager,
      retryManager: mockRetryManager,
      sessionManager: mockSessionManager,
      networkManager: mockNetworkManager,
      configManager: mockConfigManager
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('start', () => {
    it('should start service successfully', async () => {
      // Arrange
      mockAudioManager.initialize.mockResolvedValue();
      mockAdapter.connect.mockResolvedValue();
      mockErrorManager.handleError.mockImplementation((error) => error);

      // Act
      await service.start();

      // Assert
      expect(mockAudioManager.initialize).toHaveBeenCalled();
      expect(mockAdapter.connect).toHaveBeenCalled();
      expect(mockSessionManager.createSession).toHaveBeenCalled();
    });

    it('should throw error if service is already started', async () => {
      // Arrange
      await service.start();

      // Act & Assert
      await expect(service.start()).rejects.toThrow('Voice service is already started');
    });

    it('should handle errors during start', async () => {
      // Arrange
      const startError = new Error('Network error');
      mockAudioManager.initialize.mockRejectedValue(startError);
      mockErrorManager.handleError.mockImplementation((error) => new VoiceError(VoiceErrorType.NETWORK_ERROR, error.message));

      // Act
      await expect(service.start()).rejects.toBeInstanceOf(VoiceError);

      // Assert
      expect(mockErrorManager.handleError).toHaveBeenCalled();
    });
  });

  describe('stop', () => {
    beforeEach(async () => {
      await service.start();
    });

    it('should stop service successfully', async () => {
      // Act
      await service.stop();

      // Assert
      expect(mockAdapter.disconnect).toHaveBeenCalled();
      expect(mockAudioManager.cleanup).toHaveBeenCalled();
      expect(mockSessionManager.endSession).toHaveBeenCalled();
    });

    it('should handle errors during stop', async () => {
      // Arrange
      const stopError = new Error('Cleanup error');
      mockAudioManager.cleanup.mockRejectedValue(stopError);
      mockErrorManager.handleError.mockImplementation((error) => new VoiceError(VoiceErrorType.AUDIO_ERROR, error.message));

      // Act
      await service.stop();

      // Assert
      expect(mockErrorManager.handleError).toHaveBeenCalled();
    });
  });

  describe('sendAudio', () => {
    beforeEach(async () => {
      await service.start();
    });

    it('should send audio successfully', async () => {
      // Arrange
      const audioData = new Float32Array([1, 2, 3, 4]);
      const mockResponse = { text: 'Hello', transcription: 'Hello' };
      mockRetryManager.executeWithRetry.mockResolvedValue(mockResponse);

      // Act
      const result = await service.sendAudio(audioData);

      // Assert
      expect(mockRetryManager.executeWithRetry).toHaveBeenCalled();
      expect(result).toEqual(mockResponse);
    });

    it('should throw error if service is not started', async () => {
      // Arrange
      await service.stop();
      const audioData = new Float32Array([1, 2, 3, 4]);

      // Act & Assert
      await expect(service.sendAudio(audioData)).rejects.toThrow('Voice service is not started');
    });

    it('should handle network errors', async () => {
      // Arrange
      const audioData = new Float32Array([1, 2, 3, 4]);
      const networkError = new Error('Network offline');
      mockNetworkManager.getStatus.mockReturnValue({
        isOnline: false,
        latency: 0,
        lastCheck: Date.now()
      });

      // Act
      await expect(service.sendAudio(audioData)).rejects.toBeInstanceOf(VoiceError);
    });
  });

  describe('sendText', () => {
    beforeEach(async () => {
      await service.start();
    });

    it('should send text successfully', async () => {
      // Arrange
      const text = 'Hello world';
      const mockResponse = { text: 'Response' };
      mockRetryManager.executeWithRetry.mockResolvedValue(mockResponse);

      // Act
      const result = await service.sendText(text);

      // Assert
      expect(mockRetryManager.executeWithRetry).toHaveBeenCalled();
      expect(result).toEqual(mockResponse);
    });

    it('should handle errors', async () => {
      // Arrange
      const text = 'Hello world';
      const sendError = new Error('API error');
      mockRetryManager.executeWithRetry.mockRejectedValue(sendError);
      mockErrorManager.handleError.mockImplementation((error) => new VoiceError(VoiceErrorType.API_ERROR, error.message));

      // Act
      await expect(service.sendText(text)).rejects.toBeInstanceOf(VoiceError);

      // Assert
      expect(mockErrorManager.handleError).toHaveBeenCalled();
    });
  });

  describe('getSession', () => {
    beforeEach(async () => {
      await service.start();
    });

    it('should return current session', () => {
      // Act
      const session = service.getSession();

      // Assert
      expect(session).toBeDefined();
      expect(session?.id).toBe('test-session');
    });

    it('should return null if service is not started', async () => {
      // Arrange
      await service.stop();

      // Act
      const session = service.getSession();

      // Assert
      expect(session).toBeNull();
    });
  });

  describe('event handling', () => {
    it('should handle events', () => {
      // Arrange
      const mockHandler = jest.fn();

      // Act
      service.on('connected', mockHandler);
      // Simulate event emission (would need to mock the internal event system)

      // Assert
      expect(mockHandler).not.toHaveBeenCalled(); // This would need proper event mocking
    });
  });

  describe('session management', () => {
    beforeEach(async () => {
      await service.start();
    });

    it('should get session history', async () => {
      // Arrange
      const mockHistory = [
        { id: '1', role: 'user', content: 'Hello', timestamp: Date.now(), type: 'text' as const }
      ];
      mockSessionManager.getHistory.mockReturnValue(mockHistory);

      // Act
      const history = await service.getSessionHistory();

      // Assert
      expect(history).toEqual(mockHistory);
    });

    it('should clear session history', async () => {
      // Act
      await service.clearSessionHistory();

      // Assert
      expect(mockSessionManager.clearHistory).toHaveBeenCalled();
    });

    it('should resume session', async () => {
      // Arrange
      const sessionId = 'test-session';
      const mockSession = {
        id: sessionId,
        isActive: true,
        startTime: Date.now(),
        lastActivity: Date.now(),
        history: [],
        metadata: {}
      };
      mockSessionManager.resumeSession.mockResolvedValue(mockSession);

      // Act
      const result = await service.resumeSession(sessionId);

      // Assert
      expect(result).toBe(true);
      expect(mockSessionManager.resumeSession).toHaveBeenCalledWith(sessionId);
    });
  });
});