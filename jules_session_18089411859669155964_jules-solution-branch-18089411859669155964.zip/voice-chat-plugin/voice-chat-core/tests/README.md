# Google语音模块测试文档

## 测试概述

本测试套件针对Google语音模块进行全面的单元测试和集成测试，确保模块的稳定性、可靠性和性能。

## 测试结构

```
tests/
├── VoiceChatService.test.ts          # 语音聊天服务测试
├── GoogleLiveAdapter.test.ts         # Google Live适配器测试
├── GoogleTextAdapter.test.ts         # Google Text适配器测试
├── LocalTTSAdapter.test.ts           # 本地TTS适配器测试
├── AudioManager.test.ts               # 音频管理器测试
├── ErrorManager.test.ts               # 错误管理器测试
├── NetworkManager.test.ts             # 网络管理器测试
├── ConfigManager.test.ts              # 配置管理器测试
├── SessionManager.test.ts             # 会话管理器测试
├── RetryManager.test.ts               # 重试管理器测试
├── FallbackService.test.ts            # 降级服务测试
├── Logger.test.ts                     # 日志管理器测试
├── MetricsCollector.test.ts           # 指标收集器测试
└── integration/                       # 集成测试
    ├── end-to-end.test.ts             # 端到端测试
    ├── error-recovery.test.ts         # 错误恢复测试
    └── performance.test.ts            # 性能测试
```

## 测试覆盖范围

### 单元测试

#### 1. VoiceChatService 测试
- ✅ 服务启动和停止
- ✅ 音频和文本消息发送
- ✅ 会话管理
- ✅ 事件处理
- ✅ 错误处理

#### 2. GoogleLiveAdapter 测试
- ✅ Live API 连接
- ✅ 音频数据发送和接收
- ✅ 语音识别和转录
- ✅ 重连机制
- ✅ 错误处理

#### 3. GoogleTextAdapter 测试
- ✅ Text API 连接
- ✅ 文本消息发送
- ✅ 降级功能

#### 4. LocalTTSAdapter 测试
- ✅ 本地TTS连接
- ✅ 语音合成
- ✅ 离线模式

#### 5. 基础设施管理器测试
- ✅ AudioManager：音频设备管理
- ✅ ErrorManager：错误处理和恢复
- ✅ NetworkManager：网络连接和CDN切换
- ✅ ConfigManager：配置管理
- ✅ SessionManager：会话生命周期
- ✅ RetryManager：重试策略
- ✅ FallbackService：降级策略

#### 6. 工具类测试
- ✅ Logger：日志记录
- ✅ MetricsCollector：指标收集

### 集成测试

#### 1. 端到端测试
- ✅ 完整的语音对话流程
- ✅ 多适配器切换
- ✅ 会话恢复

#### 2. 错误恢复测试
- ✅ 网络中断恢复
- ✅ API错误恢复
- ✅ 音频设备故障恢复

#### 3. 性能测试
- ✅ 音频处理性能
- ✅ 响应时间测试
- ✅ 并发连接测试

## 运行测试

### 安装依赖
```bash
npm install
```

### 运行所有测试
```bash
npm test
```

### 运行特定测试
```bash
# 运行单个测试文件
npm test VoiceChatService.test.ts

# 运行集成测试
npm test -- --testPathPattern=integration

# 运行性能测试
npm test -- --testPathPattern=performance
```

### 生成测试覆盖率报告
```bash
npm run test:coverage
```

## 测试配置

### Jest 配置
```javascript
// jest.config.js
module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'jsdom',
  setupFilesAfterEnv: ['<rootDir>/tests/setup.ts'],
  moduleNameMapping: {
    '^@/(.*)$': '<rootDir>/src/$1'
  },
  collectCoverageFrom: [
    'src/**/*.ts',
    '!src/**/*.d.ts',
    '!src/**/*.test.ts',
    '!src/**/*.spec.ts'
  ],
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: 80
    }
  }
};
```

### 测试环境设置
```typescript
// tests/setup.ts
import '@testing-library/jest-dom';

// Mock Web Speech API
Object.defineProperty(window, 'speechSynthesis', {
  value: {
    speak: jest.fn(),
    cancel: jest.fn(),
    pause: jest.fn(),
    resume: jest.fn(),
    getVoices: jest.fn().mockReturnValue([]),
    onvoiceschanged: null
  },
  writable: true
});

// Mock AudioContext
Object.defineProperty(window, 'AudioContext', {
  value: jest.fn().mockImplementation(() => ({
    sampleRate: 44100,
    state: 'running',
    close: jest.fn(),
    createMediaStreamSource: jest.fn(),
    createScriptProcessor: jest.fn().mockReturnValue({
      connect: jest.fn(),
      disconnect: jest.fn(),
      onaudioprocess: null
    }),
    destination: {},
    resume: jest.fn()
  })),
  writable: true
});

// Mock navigator.mediaDevices
Object.defineProperty(navigator, 'mediaDevices', {
  value: {
    getUserMedia: jest.fn()
  },
  writable: true
});
```

## 测试最佳实践

### 1. Mock 策略
- 使用 Jest 的自动 Mock 功能
- 为外部依赖创建 Mock 实现
- 确保测试的独立性

### 2. 测试数据
- 使用工厂函数创建测试数据
- 避免在测试中使用真实API密钥
- 使用测试专用的配置

### 3. 异步测试
- 使用 async/await 处理异步操作
- 正确处理 Promise 和 setTimeout
- 使用 Jest 的定时器 Mock

### 4. 错误测试
- 测试各种错误场景
- 验证错误处理逻辑
- 确保错误恢复机制正常工作

## 测试覆盖率目标

- **分支覆盖率**: 80%+
- **函数覆盖率**: 80%+
- **行覆盖率**: 80%+
- **语句覆盖率**: 80%+

## CI/CD 集成

### GitHub Actions 工作流
```yaml
name: Test
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
        with:
          node-version: '16'
          cache: 'npm'
      - run: npm install
      - run: npm test
      - run: npm run test:coverage
      - uses: codecov/codecov-action@v1
        with:
          file: ./coverage/lcov.info
```

## 测试报告

### 生成测试报告
```bash
# 生成 HTML 报告
npm run test:report

# 生成 JUnit 报告（用于 CI）
npm run test:junit
```

### 查看覆盖率报告
```bash
# 打开覆盖率报告
open coverage/lcov-report/index.html
```

## 常见问题

### 1. Mock 失败
确保正确配置了 Jest 的 Mock 策略，检查 Mock 实现是否完整。

### 2. 异步测试超时
使用 `jest.setTimeout(10000)` 增加超时时间，或检查异步操作是否正确处理。

### 3. 浏览器 API 不可用
在 `setup.ts` 中正确 Mock 所有需要的浏览器 API。

### 4. 测试数据污染
在 `beforeEach` 和 `afterEach` 中正确清理测试状态。

## 贡献指南

1. 编写测试时遵循 AAA 模式（Arrange, Act, Assert）
2. 为新功能添加相应的测试
3. 确保测试通过后才能提交代码
4. 更新测试文档以反映新的测试用例

## 相关文档

- [Jest 官方文档](https://jestjs.io/docs/getting-started)
- [Testing Library](https://testing-library.com/docs/)
- [TypeScript 测试最佳实践](https://www.typescriptlang.org/docs/handbook/intro-to-tests.html)