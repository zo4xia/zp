import { VoiceChatService } from '../services/VoiceChatService';
import { GoogleLiveAdapter } from '../infrastructure/GoogleLiveAdapter';
import { AudioManager } from '../infrastructure/AudioManager';
import { ErrorManager } from '../infrastructure/ErrorManager';
import { RetryManager } from '../infrastructure/RetryManager';
import { SessionManager } from '../infrastructure/SessionManager';
import { NetworkManager } from '../infrastructure/NetworkManager';
import { ConfigManager, createDefaultConfig } from '../infrastructure/ConfigManager';
import { FallbackService } from '../infrastructure/FallbackService';
import { GoogleTextAdapter } from '../infrastructure/GoogleTextAdapter';
import { LocalTTSAdapter } from '../infrastructure/LocalTTSAdapter';
import { VoiceError, VoiceErrorType } from '../types';

// Mock 所有依赖
jest.mock('../infrastructure/GoogleLiveAdapter');
jest.mock('../infrastructure/GoogleTextAdapter');
jest.mock('../infrastructure/LocalTTSAdapter');
jest.mock('../infrastructure/AudioManager');
jest.mock('../infrastructure/ErrorManager');
jest.mock('../infrastructure/RetryManager');
jest.mock('../infrastructure/SessionManager');
jest.mock('../infrastructure/NetworkManager');
jest.mock('../infrastructure/ConfigManager');
jest.mock('../infrastructure/FallbackService');

describe('VoiceChatService Integration Tests', () => {
  let service: VoiceChatService;
  let mockAdapter: jest.Mocked<GoogleLiveAdapter>;
  let mockAudioManager: jest.Mocked<AudioManager>;
  let mockErrorManager: jest.Mocked<ErrorManager>;
  let mockRetryManager: jest.Mocked<RetryManager>;
  let mockSessionManager: jest.Mocked<SessionManager>;
  let mockNetworkManager: jest.Mocked<NetworkManager>;
  let mockConfigManager: jest.Mocked<ConfigManager>;
  let mockFallbackService: jest.Mocked<FallbackService>;

  beforeEach(() => {
    // 创建 Mock 对象
    mockAdapter = {
      connect: jest.fn(),
      disconnect: jest.fn(),
      sendAudio: jest.fn(),
      sendText: jest.fn(),
      on: jest.fn(),
      off: jest.fn()
    } as any;

    mockAudioManager = {
      initialize: jest.fn(),
      cleanup: jest.fn(),
      getAvailableDevices: jest.fn(),
      downsampleBuffer: jest.fn(),
      getInputSampleRate: jest.fn(),
      getOutputSampleRate: jest.fn(),
      startRecording: jest.fn(),
      stopRecording: jest.fn(),
      playAudio: jest.fn(),
      isReady: jest.fn(),
      setLogCallback: jest.fn(),
      setMetricsCallback: jest.fn()
    } as any;

    mockErrorManager = {
      handleError: jest.fn(),
      setLogCallback: jest.fn(),
      setMetricsCallback: jest.fn(),
      setHealthCallback: jest.fn(),
      getErrorStats: jest.fn(),
      resetErrorCount: jest.fn(),
      shouldTriggerFallback: jest.fn(),
      executeFallback: jest.fn()
    } as any;

    mockRetryManager = {
      executeWithRetry: jest.fn()
    } as any;

    mockSessionManager = {
      createSession: jest.fn(),
      endSession: jest.fn(),
      getSession: jest.fn(),
      addMessage: jest.fn(),
      getHistory: jest.fn(),
      clearHistory: jest.fn(),
      resumeSession: jest.fn(),
      updateActivity: jest.fn()
    } as any;

    mockNetworkManager = {
      getStatus: jest.fn(),
      getCurrentCdn: jest.fn(),
      performHealthCheck: jest.fn(),
      testLatency: jest.fn(),
      testBandwidth: jest.fn(),
      executeWithRetry: jest.fn(),
      switchCdn: jest.fn(),
      onStatusChange: jest.fn(),
      setMetricsCallback: jest.fn(),
      setLogCallback: jest.fn(),
      startHealthCheck: jest.fn(),
      stopHealthCheck: jest.fn(),
      cleanup: jest.fn()
    } as any;

    mockConfigManager = {
      getConfig: jest.fn(),
      getVoiceConfig: jest.fn(),
      getApiKey: jest.fn(),
      getNextApiKey: jest.fn(),
      getPrimaryCdn: jest.fn(),
      getFallbackCdns: jest.fn(),
      getLocalCdn: jest.fn(),
      updateConfig: jest.fn(),
      onConfigChange: jest.fn(),
      getCdnHealthCheckConfig: jest.fn(),
      getRetryConfig: jest.fn(),
      getSessionConfig: jest.fn(),
      getAudioConfig: jest.fn()
    } as any;

    mockFallbackService = {
      executeFallback: jest.fn(),
      getFallbackHistory: jest.fn(),
      getFallbackStats: jest.fn(),
      setLogCallback: jest.fn(),
      setMetricsCallback: jest.fn()
    } as any;

    // 设置默认返回值
    const config = createDefaultConfig();
    config.voice.api.google.apiKeys = ['test-api-key'];
    mockConfigManager.getConfig.mockReturnValue(config);
    mockConfigManager.getAudioConfig.mockReturnValue({
      inputSampleRate: 16000,
      outputSampleRate: 24000,
      bufferSize: 4096
    });
    mockNetworkManager.getStatus.mockReturnValue({
      isOnline: true,
      latency: 100,
      lastCheck: Date.now()
    });
    mockSessionManager.createSession.mockResolvedValue({
      id: 'test-session',
      startTime: Date.now(),
      isActive: true,
      metadata: {}
    });
    mockErrorManager.shouldTriggerFallback.mockReturnValue(false);

    // 创建服务实例
    service = new VoiceChatService({
      adapter: mockAdapter,
      audioManager: mockAudioManager,
      errorManager: mockErrorManager,
      retryManager: mockRetryManager,
      sessionManager: mockSessionManager,
      networkManager: mockNetworkManager,
      configManager: mockConfigManager
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('Full Workflow', () => {
    it('should handle complete voice chat workflow', async () => {
      // Arrange
      const audioData = new Float32Array([1, 2, 3, 4]);
      const text = 'Hello world';
      const mockResponse = { text: 'Response', transcription: 'Transcription' };

      mockAudioManager.initialize.mockResolvedValue();
      mockAdapter.connect.mockResolvedValue();
      mockRetryManager.executeWithRetry
        .mockResolvedValueOnce(mockResponse) // sendAudio
        .mockResolvedValueOnce(mockResponse); // sendText
      mockSessionManager.addMessage.mockResolvedValue();

      // Act
      await service.start();
      const audioResult = await service.sendAudio(audioData);
      const textResult = await service.sendText(text);
      await service.stop();

      // Assert
      expect(mockAudioManager.initialize).toHaveBeenCalled();
      expect(mockAdapter.connect).toHaveBeenCalled();
      expect(mockSessionManager.createSession).toHaveBeenCalled();
      expect(mockRetryManager.executeWithRetry).toHaveBeenCalledTimes(2);
      expect(mockSessionManager.addMessage).toHaveBeenCalledTimes(2);
      expect(mockAdapter.disconnect).toHaveBeenCalled();
      expect(mockAudioManager.cleanup).toHaveBeenCalled();
      expect(mockSessionManager.endSession).toHaveBeenCalled();

      expect(audioResult).toEqual(mockResponse);
      expect(textResult).toEqual(mockResponse);
    });

    it('should handle network failure with fallback', async () => {
      // Arrange
      const audioData = new Float32Array([1, 2, 3, 4]);
      const networkError = new Error('Network error');

      mockAudioManager.initialize.mockResolvedValue();
      mockAdapter.connect.mockRejectedValue(networkError);
      mockErrorManager.handleError.mockImplementation((error) => new VoiceError(VoiceErrorType.NETWORK_ERROR, error.message));
      mockErrorManager.shouldTriggerFallback.mockReturnValue(true);
      mockFallbackService.executeFallback.mockResolvedValue(null);

      // Act & Assert
      await expect(service.start()).rejects.toBeInstanceOf(VoiceError);
      
      expect(mockErrorManager.handleError).toHaveBeenCalled();
      expect(mockErrorManager.shouldTriggerFallback).toHaveBeenCalled();
      expect(mockFallbackService.executeFallback).toHaveBeenCalled();
    });

    it('should handle session management correctly', async () => {
      // Arrange
      const mockSession = {
        id: 'test-session',
        startTime: Date.now(),
        isActive: true,
        metadata: {}
      };

      mockAudioManager.initialize.mockResolvedValue();
      mockAdapter.connect.mockResolvedValue();
      mockSessionManager.createSession.mockResolvedValue(mockSession);
      mockSessionManager.getHistory.mockReturnValue([
        { id: '1', role: 'user', content: 'Hello', timestamp: Date.now(), type: 'text' },
        { id: '2', role: 'assistant', content: 'Hi', timestamp: Date.now(), type: 'text' }
      ]);

      // Act
      await service.start();
      const session = service.getSession();
      const history = await service.getSessionHistory();
      await service.clearSessionHistory();
      await service.stop();

      // Assert
      expect(session).toEqual(mockSession);
      expect(history).toHaveLength(2);
      expect(mockSessionManager.clearHistory).toHaveBeenCalled();
    });

    it('should handle multiple errors gracefully', async () => {
      // Arrange
      const audioData = new Float32Array([1, 2, 3, 4]);
      const errors = [
        new Error('First error'),
        new Error('Second error'),
        new Error('Third error')
      ];

      mockAudioManager.initialize.mockResolvedValue();
      mockAdapter.connect.mockResolvedValue();
      mockRetryManager.executeWithRetry.mockRejectedValueOnce(errors[0]);
      mockErrorManager.handleError
        .mockReturnValueOnce(new VoiceError(VoiceErrorType.API_ERROR, errors[0].message))
        .mockReturnValueOnce(new VoiceError(VoiceErrorType.NETWORK_ERROR, errors[1].message))
        .mockReturnValueOnce(new VoiceError(VoiceErrorType.TIMEOUT_ERROR, errors[2].message));

      // Act & Assert
      await service.start();
      
      await expect(service.sendAudio(audioData)).rejects.toBeInstanceOf(VoiceError);
      
      expect(mockErrorManager.handleError).toHaveBeenCalledTimes(1);
      expect(mockErrorManager.getErrorStats).toHaveBeenCalled();
    });

    it('should handle concurrent operations', async () => {
      // Arrange
      const audioData1 = new Float32Array([1, 2, 3, 4]);
      const audioData2 = new Float32Array([5, 6, 7, 8]);
      const text1 = 'Hello';
      const text2 = 'World';
      const mockResponse = { text: 'Response' };

      mockAudioManager.initialize.mockResolvedValue();
      mockAdapter.connect.mockResolvedValue();
      mockRetryManager.executeWithRetry.mockResolvedValue(mockResponse);

      // Act
      await service.start();

      const promises = [
        service.sendAudio(audioData1),
        service.sendAudio(audioData2),
        service.sendText(text1),
        service.sendText(text2)
      ];

      const results = await Promise.all(promises);
      await service.stop();

      // Assert
      expect(results).toHaveLength(4);
      expect(results.every(r => r.text === 'Response')).toBe(true);
      expect(mockRetryManager.executeWithRetry).toHaveBeenCalledTimes(4);
    });
  });

  describe('Error Recovery', () => {
    it('should recover from temporary network issues', async () => {
      // Arrange
      const audioData = new Float32Array([1, 2, 3, 4]);
      const mockResponse = { text: 'Response' };

      mockAudioManager.initialize.mockResolvedValue();
      mockAdapter.connect.mockResolvedValue();
      mockNetworkManager.getStatus
        .mockReturnValueOnce({ isOnline: false, latency: 0, lastCheck: Date.now() })
        .mockReturnValueOnce({ isOnline: true, latency: 100, lastCheck: Date.now() });
      mockRetryManager.executeWithRetry.mockResolvedValue(mockResponse);

      // Act
      await service.start();

      // 第一次失败
      await expect(service.sendAudio(audioData)).rejects.toBeInstanceOf(VoiceError);

      // 第二次成功
      const result = await service.sendAudio(audioData);

      // Assert
      expect(result).toEqual(mockResponse);
    });

    it('should handle session timeout and resume', async () => {
      // Arrange
      const mockSession = {
        id: 'test-session',
        startTime: Date.now() - 1000000, // 超过超时时间
        isActive: false,
        metadata: {}
      };

      mockAudioManager.initialize.mockResolvedValue();
      mockAdapter.connect.mockResolvedValue();
      mockSessionManager.createSession.mockResolvedValue(mockSession);
      mockSessionManager.resumeSession.mockResolvedValue(mockSession);

      // Act
      await service.start();
      const resumed = await service.resumeSession('test-session');

      // Assert
      expect(resumed).toBe(true);
      expect(mockSessionManager.resumeSession).toHaveBeenCalledWith('test-session');
    });
  });

  describe('Performance', () => {
    it('should handle large audio data', async () => {
      // Arrange
      const largeAudioData = new Float32Array(100000); // 大音频数据
      for (let i = 0; i < largeAudioData.length; i++) {
        largeAudioData[i] = Math.random();
      }
      const mockResponse = { text: 'Response' };

      mockAudioManager.initialize.mockResolvedValue();
      mockAdapter.connect.mockResolvedValue();
      mockRetryManager.executeWithRetry.mockResolvedValue(mockResponse);

      // Act
      await service.start();
      const result = await service.sendAudio(largeAudioData);
      await service.stop();

      // Assert
      expect(result).toEqual(mockResponse);
      expect(mockAudioManager.downsampleBuffer).toHaveBeenCalled();
    });

    it('should handle rapid successive calls', async () => {
      // Arrange
      const mockResponse = { text: 'Response' };
      const callCount = 100;

      mockAudioManager.initialize.mockResolvedValue();
      mockAdapter.connect.mockResolvedValue();
      mockRetryManager.executeWithRetry.mockResolvedValue(mockResponse);

      // Act
      await service.start();

      const startTime = Date.now();
      const promises = Array.from({ length: callCount }, (_, i) =>
        service.sendText(`Message ${i}`)
      );

      await Promise.all(promises);
      const endTime = Date.now();

      await service.stop();

      // Assert
      expect(endTime - startTime).toBeLessThan(10000); // 应该在10秒内完成
      expect(mockRetryManager.executeWithRetry).toHaveBeenCalledTimes(callCount);
    });
  });
});