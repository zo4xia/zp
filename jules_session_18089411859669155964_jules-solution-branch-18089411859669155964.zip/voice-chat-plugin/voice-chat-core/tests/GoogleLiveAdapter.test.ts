import { GoogleLiveAdapter } from '../infrastructure/GoogleLiveAdapter';
import { AudioManager } from '../infrastructure/AudioManager';
import { ErrorManager } from '../infrastructure/ErrorManager';
import { NetworkManager } from '../infrastructure/NetworkManager';
import { ConfigManager } from '../infrastructure/ConfigManager';
import { VoiceError, VoiceErrorType } from '../types';

// Mock 依赖
jest.mock('../infrastructure/AudioManager');
jest.mock('../infrastructure/ErrorManager');
jest.mock('../infrastructure/NetworkManager');
jest.mock('../infrastructure/ConfigManager');
jest.mock('@google/genai', () => ({
  GoogleGenAI: jest.fn(),
  LiveServerMessage: jest.fn(),
  Modality: {
    AUDIO: 'audio'
  }
}));

describe('GoogleLiveAdapter', () => {
  let adapter: GoogleLiveAdapter;
  let mockAudioManager: jest.Mocked<AudioManager>;
  let mockErrorManager: jest.Mocked<ErrorManager>;
  let mockNetworkManager: jest.Mocked<NetworkManager>;
  let mockConfigManager: jest.Mocked<ConfigManager>;

  beforeEach(() => {
    // 创建 Mock 对象
    mockAudioManager = {
      initialize: jest.fn(),
      cleanup: jest.fn(),
      getAvailableDevices: jest.fn(),
      downsampleBuffer: jest.fn(),
      getInputSampleRate: jest.fn(),
      getOutputSampleRate: jest.fn(),
      startRecording: jest.fn(),
      stopRecording: jest.fn(),
      playAudio: jest.fn(),
      isReady: jest.fn(),
      setLogCallback: jest.fn(),
      setMetricsCallback: jest.fn(),
      downsampleBuffer: jest.fn()
    } as any;

    mockErrorManager = {
      handleError: jest.fn(),
      setLogCallback: jest.fn(),
      setMetricsCallback: jest.fn(),
      setHealthCallback: jest.fn(),
      getErrorStats: jest.fn(),
      resetErrorCount: jest.fn(),
      shouldTriggerFallback: jest.fn(),
      executeFallback: jest.fn()
    } as any;

    mockNetworkManager = {
      getStatus: jest.fn(),
      getCurrentCdn: jest.fn(),
      performHealthCheck: jest.fn(),
      testLatency: jest.fn(),
      testBandwidth: jest.fn(),
      executeWithRetry: jest.fn(),
      switchCdn: jest.fn(),
      onStatusChange: jest.fn(),
      setMetricsCallback: jest.fn(),
      setLogCallback: jest.fn(),
      startHealthCheck: jest.fn(),
      stopHealthCheck: jest.fn(),
      cleanup: jest.fn()
    } as any;

    mockConfigManager = {
      getConfig: jest.fn(),
      getVoiceConfig: jest.fn(),
      getApiKey: jest.fn(),
      getNextApiKey: jest.fn(),
      getPrimaryCdn: jest.fn(),
      getFallbackCdns: jest.fn(),
      getLocalCdn: jest.fn(),
      updateConfig: jest.fn(),
      onConfigChange: jest.fn(),
      getCdnHealthCheckConfig: jest.fn(),
      getRetryConfig: jest.fn(),
      getSessionConfig: jest.fn(),
      getAudioConfig: jest.fn()
    } as any;

    // 设置默认返回值
    mockConfigManager.getConfig.mockReturnValue({
      voice: {
        api: {
          google: {
            models: {
              live: 'gemini-2.5-flash-native-audio-preview-12-2025',
              text: 'gemini-2.5-flash',
              fallback: 'gemini-2.5-flash'
            },
            endpoints: {
              primary: 'https://generativelanguage.googleapis.com',
              backup: []
            }
          }
        },
        cdn: {
          google: ['https://cdn.jsdelivr.net'],
          fallback: [],
          local: '/local-assets'
        },
        retry: {
          maxAttempts: 3,
          baseDelay: 1000,
          maxDelay: 10000
        },
        session: {
          timeout: 900000,
          resumeEnabled: true
        }
      },
      network: {
        timeout: 30000,
        retryConfig: {
          maxAttempts: 3,
          baseDelay: 1000,
          maxDelay: 10000,
          backoffMultiplier: 2
        },
        endpoints: {
          primary: 'https://generativelanguage.googleapis.com',
          backup: []
        }
      },
      session: {
        timeout: 900000,
        resumeEnabled: true,
        maxHistory: 100
      },
      audio: {
        inputSampleRate: 16000,
        outputSampleRate: 24000,
        bufferSize: 4096
      }
    });

    mockConfigManager.getApiKey.mockReturnValue('test-api-key');
    mockNetworkManager.getStatus.mockReturnValue({
      isOnline: true,
      latency: 100,
      lastCheck: Date.now()
    });

    // 创建适配器实例
    adapter = new GoogleLiveAdapter({
      audioManager: mockAudioManager,
      errorManager: mockErrorManager,
      networkManager: mockNetworkManager,
      configManager: mockConfigManager
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('connect', () => {
    it('should connect successfully', async () => {
      // Arrange
      const mockGenAI = {
        live: {
          connect: jest.fn().mockResolvedValue({
            id: 'test-session',
            on: jest.fn(),
            off: jest.fn(),
            sendRealtimeInput: jest.fn(),
            sendClientContent: jest.fn(),
            close: jest.fn()
          })
        }
      };
      
      const { GoogleGenAI } = require('@google/genai');
      GoogleGenAI.mockImplementation(() => mockGenAI);

      // Act
      await adapter.connect();

      // Assert
      expect(mockNetworkManager.getStatus).toHaveBeenCalled();
      expect(mockAudioManager.getAvailableDevices).toHaveBeenCalled();
      expect(GoogleGenAI).toHaveBeenCalledWith({
        apiKey: 'test-api-key',
        baseUrl: 'https://generativelanguage.googleapis.com'
      });
    });

    it('should handle connection errors', async () => {
      // Arrange
      const connectError = new Error('Connection failed');
      const { GoogleGenAI } = require('@google/genai');
      GoogleGenAI.mockImplementation(() => {
        throw connectError;
      });

      mockErrorManager.handleError.mockImplementation((error) => new VoiceError(VoiceErrorType.API_ERROR, error.message));

      // Act & Assert
      await expect(adapter.connect()).rejects.toBeInstanceOf(VoiceError);
    });

    it('should not connect if already connecting', async () => {
      // Arrange
      const mockGenAI = {
        live: {
          connect: jest.fn().mockResolvedValue({})
        }
      };
      
      const { GoogleGenAI } = require('@google/genai');
      GoogleGenAI.mockImplementation(() => mockGenAI);

      // Act
      await adapter.connect();
      await adapter.connect();

      // Assert
      expect(GoogleGenAI).toHaveBeenCalledTimes(1);
    });
  });

  describe('disconnect', () => {
    beforeEach(async () => {
      const mockGenAI = {
        live: {
          connect: jest.fn().mockResolvedValue({
            id: 'test-session',
            on: jest.fn(),
            off: jest.fn(),
            sendRealtimeInput: jest.fn(),
            sendClientContent: jest.fn(),
            close: jest.fn()
          })
        }
      };
      
      const { GoogleGenAI } = require('@google/genai');
      GoogleGenAI.mockImplementation(() => mockGenAI);
      
      await adapter.connect();
    });

    it('should disconnect successfully', async () => {
      // Act
      await adapter.disconnect();

      // Assert
      expect(mockAudioManager.cleanup).toHaveBeenCalled();
    });

    it('should handle disconnection errors', async () => {
      // Arrange
      const disconnectError = new Error('Disconnect failed');
      mockAudioManager.cleanup.mockRejectedValue(disconnectError);
      mockErrorManager.handleError.mockImplementation((error) => new VoiceError(VoiceErrorType.AUDIO_ERROR, error.message));

      // Act
      await adapter.disconnect();

      // Assert
      expect(mockErrorManager.handleError).toHaveBeenCalled();
    });
  });

  describe('sendAudio', () => {
    beforeEach(async () => {
      const mockSession = {
        id: 'test-session',
        on: jest.fn(),
        off: jest.fn(),
        sendRealtimeInput: jest.fn().mockResolvedValue(),
        sendClientContent: jest.fn(),
        close: jest.fn()
      };
      
      const mockGenAI = {
        live: {
          connect: jest.fn().mockResolvedValue(mockSession)
        }
      };
      
      const { GoogleGenAI } = require('@google/genai');
      GoogleGenAI.mockImplementation(() => mockGenAI);
      
      await adapter.connect();
    });

    it('should send audio successfully', async () => {
      // Arrange
      const audioData = new Float32Array([1, 2, 3, 4]);
      mockAudioManager.downsampleBuffer.mockReturnValue(audioData);

      // Act
      await adapter.sendAudio(audioData, 16000);

      // Assert
      expect(mockAudioManager.downsampleBuffer).toHaveBeenCalled();
    });

    it('should queue audio if not connected', async () => {
      // Arrange
      const audioData = new Float32Array([1, 2, 3, 4]);
      
      // Disconnect first
      await adapter.disconnect();

      // Act
      await adapter.sendAudio(audioData, 16000);

      // Assert
      // Should not throw and should queue the audio
    });
  });

  describe('sendText', () => {
    beforeEach(async () => {
      const mockSession = {
        id: 'test-session',
        on: jest.fn(),
        off: jest.fn(),
        sendRealtimeInput: jest.fn(),
        sendClientContent: jest.fn().mockResolvedValue(),
        close: jest.fn()
      };
      
      const mockGenAI = {
        live: {
          connect: jest.fn().mockResolvedValue(mockSession)
        }
      };
      
      const { GoogleGenAI } = require('@google/genai');
      GoogleGenAI.mockImplementation(() => mockGenAI);
      
      await adapter.connect();
    });

    it('should send text successfully', async () => {
      // Arrange
      const text = 'Hello world';

      // Act
      const result = await adapter.sendText(text);

      // Assert
      expect(result).toBeDefined();
    });

    it('should handle text sending errors', async () => {
      // Arrange
      const text = 'Hello world';
      const sendError = new Error('Send failed');
      
      // Mock the session to throw an error
      const mockSession = {
        id: 'test-session',
        on: jest.fn(),
        off: jest.fn(),
        sendRealtimeInput: jest.fn(),
        sendClientContent: jest.fn().mockRejectedValue(sendError),
        close: jest.fn()
      };
      
      const { GoogleGenAI } = require('@google/genai');
      const mockGenAI = GoogleGenAI.mock.results[0].value;
      mockGenAI.live.connect.mockResolvedValue(mockSession);
      
      mockErrorManager.handleError.mockImplementation((error) => new VoiceError(VoiceErrorType.API_ERROR, error.message));

      // Act & Assert
      await expect(adapter.sendText(text)).rejects.toBeInstanceOf(VoiceError);
    });
  });

  describe('event handling', () => {
    it('should handle events', () => {
      // Arrange
      const mockHandler = jest.fn();

      // Act
      adapter.on('connected', mockHandler);
      // Simulate event emission (would need to mock the internal event system)

      // Assert
      expect(mockHandler).not.toHaveBeenCalled(); // This would need proper event mocking
    });
  });

  describe('error handling', () => {
    it('should handle authentication errors', async () => {
      // Arrange
      mockConfigManager.getApiKey.mockReturnValue('');
      mockErrorManager.handleError.mockImplementation((error) => new VoiceError(VoiceErrorType.AUTH_ERROR, error.message));

      // Act & Assert
      await expect(adapter.connect()).rejects.toBeInstanceOf(VoiceError);
      expect(mockErrorManager.handleError).toHaveBeenCalledWith(
        expect.any(Error),
        'GoogleLiveAdapter.connect'
      );
    });

    it('should handle network errors', async () => {
      // Arrange
      mockNetworkManager.getStatus.mockReturnValue({
        isOnline: false,
        latency: 0,
        lastCheck: Date.now()
      });
      mockErrorManager.handleError.mockImplementation((error) => new VoiceError(VoiceErrorType.NETWORK_ERROR, error.message));

      // Act & Assert
      await expect(adapter.connect()).rejects.toBeInstanceOf(VoiceError);
    });
  });
});