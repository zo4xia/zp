// ==================== 基础类型定义 ====================

export interface VoiceConfig {
  // API配置
  api: {
    google: {
      models: {
        live: string;
        text: string;
        fallback: string;
      };
      endpoints: {
        primary: string;
        backup: string;
      };
    };
  };
  
  // CDN配置
  cdn: {
    google: string[];
    fallback: string[];
    local: string;
  };
  
  // 重试配置
  retry: {
    maxAttempts: number;
    baseDelay: number;
    maxDelay: number;
  };
  
  // 会话配置
  session: {
    timeout: number;
    resumeEnabled: boolean;
  };
  
  // 音频配置
  audio: {
    inputSampleRate: number;
    outputSampleRate: number;
    bufferSize: number;
  };
}

// ==================== 语音服务接口 ====================

export interface VoiceAdapter {
  connect(): Promise<void>;
  disconnect(): Promise<void>;
  sendAudio(audioData: Float32Array, sampleRate: number): Promise<void>;
  sendText(text: string): Promise<VoiceResponse>;
  on(event: string, callback: (...args: any[]) => void): void;
  off(event: string, callback: (...args: any[]) => void): void;
}

export interface VoiceResponse {
  text?: string;
  audio?: ArrayBuffer;
  transcription?: string;
  confidence?: number;
}

export interface VoiceSession {
  id: string;
  startTime: number;
  endTime?: number;
  isActive: boolean;
  metadata: Record<string, any>;
}

// ==================== 事件系统 ====================

export type VoiceEvent = 
  | 'connected'
  | 'disconnected'
  | 'audio_start'
  | 'audio_end'
  | 'transcription'
  | 'response'
  | 'error'
  | 'session_resumed'
  | 'fallback_triggered';

export interface VoiceEventHandler {
  (event: VoiceEvent, data?: any): void;
}

// ==================== 错误处理 ====================

export enum VoiceErrorType {
  NETWORK_ERROR = 'NETWORK_ERROR',
  API_ERROR = 'API_ERROR',
  AUDIO_ERROR = 'AUDIO_ERROR',
  AUTH_ERROR = 'AUTH_ERROR',
  TIMEOUT_ERROR = 'TIMEOUT_ERROR',
  FALLBACK_ERROR = 'FALLBACK_ERROR'
}

export class VoiceError extends Error {
  constructor(
    public type: VoiceErrorType,
    message: string,
    public originalError?: Error,
    public metadata?: Record<string, any>
  ) {
    super(message);
    this.name = 'VoiceError';
  }
}

// ==================== 重试策略 ====================

export interface RetryStrategy {
  shouldRetry(attempt: number, error: Error): boolean;
  getDelay(attempt: number): number;
}

export interface RetryConfig {
  maxAttempts: number;
  baseDelay: number;
  maxDelay: number;
  backoffMultiplier: number;
}

// ==================== 音频管理 ====================

export interface AudioConfig {
  sampleRate: number;
  channels: number;
  bufferSize: number;
}

export interface AudioBuffer {
  data: Float32Array;
  sampleRate: number;
  channels: number;
}

// ==================== 会话管理 ====================

export interface SessionConfig {
  timeout: number;
  resumeEnabled: boolean;
  maxHistory: number;
}

export interface SessionState {
  id: string;
  isActive: boolean;
  startTime: number;
  lastActivity: number;
  history: ChatMessage[];
  metadata: Record<string, any>;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  type: 'text' | 'audio' | 'transcription';
  metadata?: Record<string, any>;
}

// ==================== 服务接口 ====================

export interface VoiceService {
  start(): Promise<void>;
  stop(): Promise<void>;
  sendAudio(audioData: Float32Array): Promise<VoiceResponse>;
  sendText(text: string): Promise<VoiceResponse>;
  getSession(): VoiceSession | null;
  on(event: VoiceEvent, handler: VoiceEventHandler): void;
  off(event: VoiceEvent, handler: VoiceEventHandler): void;
}

// ==================== 降级策略 ====================

export interface FallbackStrategy {
  name: string;
  priority: number;
  canHandle(error: VoiceError): boolean;
  execute(context: FallbackContext): Promise<boolean>;
}

export interface FallbackContext {
  originalError: VoiceError;
  currentAdapter: VoiceAdapter;
  availableAdapters: VoiceAdapter[];
  session: VoiceSession | null;
}

// ==================== 网络管理 ====================

export interface NetworkConfig {
  timeout: number;
  retryConfig: RetryConfig;
  endpoints: {
    primary: string;
    backup: string[];
  };
}

export interface NetworkStatus {
  isOnline: boolean;
  latency: number;
  bandwidth?: number;
  lastCheck: number;
}

// ==================== 配置管理 ====================

export interface AppConfig {
  voice: VoiceConfig;
  network: NetworkConfig;
  session: SessionConfig;
  audio: AudioConfig;
}

// ==================== 工厂接口 ====================

export interface VoiceAdapterFactory {
  createAdapter(config: VoiceConfig): VoiceAdapter;
}

export interface RetryStrategyFactory {
  createStrategy(type: string, config: RetryConfig): RetryStrategy;
}

// ==================== 中间件接口 ====================

export interface MiddlewareContext {
  request: any;
  response?: any;
  error?: Error;
  next: () => Promise<void>;
}

export interface Middleware {
  name: string;
  priority: number;
  handle(context: MiddlewareContext): Promise<void>;
}

// ==================== 监控和日志 ====================

export interface Metrics {
  name: string;
  value: number;
  timestamp: number;
  tags?: Record<string, string>;
}

export interface LogEntry {
  level: 'debug' | 'info' | 'warn' | 'error';
  message: string;
  timestamp: number;
  metadata?: Record<string, any>;
}

export interface HealthCheck {
  name: string;
  status: 'healthy' | 'unhealthy' | 'degraded';
  message?: string;
  lastCheck: number;
  details?: Record<string, any>;
}

// ==================== 依赖注入标识 ====================

export const TYPES = {
  // 服务
  VoiceService: Symbol.for('VoiceService'),
  VoiceAdapter: Symbol.for('VoiceAdapter'),
  
  // 管理器
  ConfigManager: Symbol.for('ConfigManager'),
  AudioManager: Symbol.for('AudioManager'),
  NetworkManager: Symbol.for('NetworkManager'),
  ErrorManager: Symbol.for('ErrorManager'),
  RetryManager: Symbol.for('RetryManager'),
  SessionManager: Symbol.for('SessionManager'),
  
  // 工厂
  VoiceAdapterFactory: Symbol.for('VoiceAdapterFactory'),
  RetryStrategyFactory: Symbol.for('RetryStrategyFactory'),
  
  // 中间件
  Middleware: Symbol.for('Middleware'),
  
  // 配置
  AppConfig: Symbol.for('AppConfig')
};

// ==================== 工具类型 ====================

export type Optional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;

export type RequiredKeys<T> = {
  [K in keyof T]-?: {} extends Pick<T, K> ? never : K
}[keyof T];

export type OptionalKeys<T> = {
  [K in keyof T]-?: {} extends Pick<T, K> ? K : never
}[keyof T];