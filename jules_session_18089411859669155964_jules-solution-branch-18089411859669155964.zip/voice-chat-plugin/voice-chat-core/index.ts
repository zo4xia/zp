// ==================== 导出类型定义 ====================
export * from './types';

// ==================== 导出核心服务 ====================
export { VoiceChatService } from './services/VoiceChatService';

// ==================== 导出基础设施管理器 ====================
export { AudioManager } from './infrastructure/AudioManager';
export { ErrorManager } from './infrastructure/ErrorManager';
export { NetworkManager } from './infrastructure/NetworkManager';
export { ConfigManager, createDefaultConfig } from './infrastructure/ConfigManager';
export { SessionManager } from './infrastructure/SessionManager';
export { RetryManager } from './infrastructure/RetryManager';
export { FallbackService } from './infrastructure/FallbackService';

// ==================== 导出适配器 ====================
export { GoogleLiveAdapter } from './infrastructure/GoogleLiveAdapter';
export { GoogleTextAdapter } from './infrastructure/GoogleTextAdapter';
export { LocalTTSAdapter } from './infrastructure/LocalTTSAdapter';

// ==================== 导出工厂和工具 ====================
export { VoiceAdapterFactory } from './factories/VoiceAdapterFactory';
export { DependencyContainer } from './utils/DependencyContainer';
export { Logger } from './utils/Logger';
export { MetricsCollector } from './utils/MetricsCollector';

// ==================== 导出配置示例 ====================
export const exampleConfig = {
  voice: {
    api: {
      google: {
        apiKeys: ['your-api-key-here'],
        models: {
          live: 'gemini-2.5-flash-native-audio-preview-12-2025',
          text: 'gemini-2.5-flash',
          fallback: 'gemini-2.5-flash'
        },
        endpoints: {
          primary: 'https://generativelanguage.googleapis.com',
          backup: []
        }
      }
    },
    cdn: {
      google: [
        'https://cdn.jsdelivr.net',
        'https://unpkg.com',
        'https://cdnjs.cloudflare.com'
      ],
      fallback: [
        'https://cdn.bootcdn.net',
        'https://cdn.staticfile.org'
      ],
      local: '/local-assets'
    },
    retry: {
      maxAttempts: 3,
      baseDelay: 1000,
      maxDelay: 10000
    },
    session: {
      timeout: 900000,
      resumeEnabled: true
    }
  },
  network: {
    timeout: 30000,
    retryConfig: {
      maxAttempts: 3,
      baseDelay: 1000,
      maxDelay: 10000,
      backoffMultiplier: 2
    },
    endpoints: {
      primary: 'https://generativelanguage.googleapis.com',
      backup: []
    }
  },
  session: {
    timeout: 900000,
    resumeEnabled: true,
    maxHistory: 100
  },
  audio: {
    inputSampleRate: 16000,
    outputSampleRate: 24000,
    bufferSize: 4096
  }
};

// ==================== 快速开始示例 ====================
export function createVoiceChatService(config: any) {
  // 创建基础设施管理器
  const configManager = new ConfigManager(config);
  const audioManager = new AudioManager(config.audio);
  const networkManager = new NetworkManager(config.network);
  const errorManager = new ErrorManager();
  const retryManager = new RetryManager(config.voice.retry);
  const sessionManager = new SessionManager(config.session);
  
  // 创建适配器工厂
  const adapterFactory = new VoiceAdapterFactory();
  const adapter = adapterFactory.createAdapter(config);
  
  // 创建服务
  const voiceChatService = new VoiceChatService({
    adapter,
    audioManager,
    errorManager,
    retryManager,
    sessionManager,
    networkManager,
    configManager
  });
  
  return voiceChatService;
}

// ==================== TypeScript 类型导出 ====================
export type {
  VoiceConfig,
  VoiceAdapter,
  VoiceResponse,
  VoiceSession,
  VoiceEvent,
  VoiceEventHandler,
  VoiceError,
  VoiceErrorType,
  RetryStrategy,
  RetryConfig,
  AudioConfig,
  AudioBuffer,
  SessionConfig,
  SessionState,
  ChatMessage,
  FallbackStrategy,
  FallbackContext,
  NetworkConfig,
  NetworkStatus,
  AppConfig,
  VoiceAdapterFactory,
  RetryStrategyFactory,
  Middleware,
  MiddlewareContext,
  Metrics,
  LogEntry,
  HealthCheck
} from './types';