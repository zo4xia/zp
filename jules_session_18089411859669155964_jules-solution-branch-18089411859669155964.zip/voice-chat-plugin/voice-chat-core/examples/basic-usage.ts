import { 
  VoiceChatService, 
  createDefaultConfig,
  Logger,
  createMetricsCollector
} from '../index';

/**
 * 基础使用示例
 * 展示如何使用Google语音模块进行基本的语音聊天
 */
async function basicUsageExample() {
  console.log('=== 基础使用示例 ===');

  // 1. 创建配置
  const config = createDefaultConfig();
  config.voice.api.google.apiKeys = ['your-api-key-here'];
  config.voice.cdn.google = [
    'https://cdn.jsdelivr.net',
    'https://cdn.bootcdn.net'
  ];

  // 2. 创建日志记录器
  const logger = Logger.createLogger('info');

  // 3. 创建指标收集器
  const metricsCollector = createMetricsCollector();

  // 4. 创建语音聊天服务
  const voiceService = new VoiceChatService(config);

  // 5. 设置日志和指标回调
  voiceService.setLogger(logger);
  voiceService.setMetricsCollector(metricsCollector);

  // 6. 添加事件监听器
  voiceService.on('connected', () => {
    console.log('✅ 语音服务已连接');
  });

  voiceService.on('disconnected', () => {
    console.log('❌ 语音服务已断开');
  });

  voiceService.on('transcription', (data) => {
    console.log('📝 收到转录:', data.text);
  });

  voiceService.on('response', (data) => {
    console.log('🤖 收到回复:', data.text);
  });

  voiceService.on('error', (error) => {
    console.error('🚨 错误:', error.message);
  });

  try {
    // 7. 启动服务
    console.log('🚀 启动语音服务...');
    await voiceService.start();

    // 8. 发送文本消息
    console.log('💬 发送文本消息...');
    const textResponse = await voiceService.sendText('Hello, how are you?');
    console.log('📤 文本回复:', textResponse.text);

    // 9. 模拟发送音频数据
    console.log('🎤 发送音频数据...');
    const audioData = new Float32Array([1, 2, 3, 4, 5]);
    const audioResponse = await voiceService.sendAudio(audioData);
    console.log('📤 音频回复:', audioResponse.text);

    // 10. 获取会话信息
    const session = voiceService.getSession();
    console.log('📊 会话信息:', session);

    // 11. 获取会话历史
    const history = await voiceService.getSessionHistory();
    console.log('📜 会话历史:', history);

    // 12. 停止服务
    console.log('🛑 停止语音服务...');
    await voiceService.stop();

    // 13. 获取指标统计
    const stats = metricsCollector.getVoiceStatistics();
    console.log('📈 指标统计:', stats);

  } catch (error) {
    console.error('❌ 操作失败:', error);
  }
}

/**
 * 高级配置示例
 * 展示如何进行高级配置和自定义
 */
async function advancedConfigurationExample() {
  console.log('=== 高级配置示例 ===');

  // 自定义配置
  const config = {
    voice: {
      api: {
        google: {
          apiKeys: ['api-key-1', 'api-key-2'], // 多个API密钥用于轮换
          models: {
            live: 'gemini-2.5-flash-native-audio-preview-12-2025',
            text: 'gemini-2.5-flash',
            fallback: 'gemini-2.5-flash'
          },
          endpoints: {
            primary: 'https://generativelanguage.googleapis.com',
            backup: ['https://backup.googleapis.com']
          }
        }
      },
      cdn: {
        google: [
          'https://cdn.jsdelivr.net',
          'https://unpkg.com',
          'https://cdnjs.cloudflare.com'
        ],
        fallback: [
          'https://cdn.bootcdn.net',
          'https://cdn.staticfile.org'
        ],
        local: '/local-assets'
      },
      retry: {
        maxAttempts: 5,
        baseDelay: 1000,
        maxDelay: 10000
      },
      session: {
        timeout: 1800000, // 30分钟
        resumeEnabled: true
      }
    },
    network: {
      timeout: 60000,
      retryConfig: {
        maxAttempts: 3,
        baseDelay: 2000,
        maxDelay: 20000,
        backoffMultiplier: 2
      }
    },
    audio: {
      inputSampleRate: 16000,
      outputSampleRate: 24000,
      bufferSize: 8192
    }
  };

  // 创建服务
  const voiceService = new VoiceChatService(config);

  // 自定义事件处理
  voiceService.on('fallback_triggered', (data) => {
    console.log('🔄 触发降级策略:', data.strategy);
  });

  voiceService.on('session_resumed', (session) => {
    console.log('🔄 恢复会话:', session.id);
  });

  // 启动服务
  await voiceService.start();

  // 执行一些操作...
  await voiceService.sendText('Testing advanced configuration');

  await voiceService.stop();
}

/**
 * 错误处理示例
 * 展示如何处理各种错误情况
 */
async function errorHandlingExample() {
  console.log('=== 错误处理示例 ===');

  const config = createDefaultConfig();
  config.voice.api.google.apiKeys = ['invalid-api-key'];

  const voiceService = new VoiceChatService(config);

  // 全局错误处理
  voiceService.on('error', (error) => {
    console.log(`🚨 错误类型: ${error.type}`);
    console.log(`🚨 错误消息: ${error.message}`);
    
    if (error.originalError) {
      console.log(`🚨 原始错误: ${error.originalError.message}`);
    }

    // 根据错误类型采取不同行动
    switch (error.type) {
      case 'NETWORK_ERROR':
        console.log('🌐 网络错误，尝试切换CDN...');
        break;
      case 'AUTH_ERROR':
        console.log('🔑 认证错误，请检查API密钥');
        break;
      case 'API_ERROR':
        console.log('🔧 API错误，尝试重试...');
        break;
      case 'TIMEOUT_ERROR':
        console.log('⏱️ 超时错误，增加超时时间');
        break;
    }
  });

  try {
    await voiceService.start();
  } catch (error) {
    console.log('❌ 启动失败，但已通过事件处理');
  }
}

/**
 * 性能监控示例
 * 展示如何监控和分析性能
 */
async function performanceMonitoringExample() {
  console.log('=== 性能监控示例 ===');

  const voiceService = new VoiceChatService(createDefaultConfig());
  const metricsCollector = voiceService.getMetricsCollector();

  // 监控指标变化
  metricsCollector.onMetric((metric) => {
    console.log(`📊 指标: ${metric.name} = ${metric.value}`);
  });

  await voiceService.start();

  // 执行性能测试
  const startTime = Date.now();
  
  // 发送多条消息测试性能
  const promises = Array.from({ length: 10 }, (_, i) => 
    voiceService.sendText(`Message ${i}`)
  );

  await Promise.all(promises);
  
  const endTime = Date.now();
  const avgTime = (endTime - startTime) / 10;

  console.log(`⏱️ 平均响应时间: ${avgTime}ms`);

  // 获取性能统计
  const stats = metricsCollector.getVoiceStatistics();
  console.log('📈 性能统计:', {
    connectionTime: stats.connectionStats.avg,
    audioProcessingTime: stats.audioStats.avg,
    errorRate: stats.errorStats.count / 10,
    retryRate: stats.retryStats.count / 10
  });

  await voiceService.stop();
}

// 导出示例函数
export {
  basicUsageExample,
  advancedConfigurationExample,
  errorHandlingExample,
  performanceMonitoringExample
};