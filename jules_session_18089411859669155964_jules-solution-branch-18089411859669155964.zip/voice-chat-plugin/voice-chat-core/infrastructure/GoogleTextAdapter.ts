import { VoiceAdapter, VoiceResponse, VoiceEvent, VoiceEventHandler, VoiceError, VoiceErrorType } from '../types';
import { AudioManager } from './AudioManager';
import { ErrorManager } from './ErrorManager';
import { NetworkManager } from './NetworkManager';
import { ConfigManager } from './ConfigManager';
import { GoogleGenAI } from '@google/genai';

/**
 * Google Text API 适配器 - 用于降级到文字聊天
 * 
 * 职责：
 * 1. 封装 Google Text API
 * 2. 提供文字聊天功能
 * 3. 作为 Live API 的降级方案
 */
export class GoogleTextAdapter implements VoiceAdapter {
  private audioManager: AudioManager;
  private errorManager: ErrorManager;
  private networkManager: NetworkManager;
  private configManager: ConfigManager;
  
  private ai: GoogleGenAI | null = null;
  private model: any = null;
  private isConnecting: boolean = false;
  
  private eventHandlers: Map<VoiceEvent, VoiceEventHandler[]> = new Map();

  constructor(deps: {
    audioManager: AudioManager;
    errorManager: ErrorManager;
    networkManager: NetworkManager;
    configManager: ConfigManager;
  }) {
    this.audioManager = deps.audioManager;
    this.errorManager = deps.errorManager;
    this.networkManager = deps.networkManager;
    this.configManager = deps.configManager;
  }

  /**
   * 连接到 Google Text API
   */
  async connect(): Promise<void> {
    if (this.isConnecting || this.model) {
      return;
    }

    this.isConnecting = true;

    try {
      // 1. 初始化 Google GenAI
      await this.initializeGoogleGenAI();

      // 2. 加载文本模型
      await this.loadModel();

      this.emit('connected');
      console.log('[GoogleTextAdapter] Connected to Google Text API');
    } catch (error) {
      const voiceError = this.errorManager.handleError(error, 'GoogleTextAdapter.connect');
      this.emit('error', voiceError);
      throw voiceError;
    } finally {
      this.isConnecting = false;
    }
  }

  /**
   * 断开连接
   */
  async disconnect(): Promise<void> {
    try {
      this.model = null;
      this.ai = null;
      
      this.emit('disconnected');
      console.log('[GoogleTextAdapter] Disconnected from Google Text API');
    } catch (error) {
      const voiceError = this.errorManager.handleError(error, 'GoogleTextAdapter.disconnect');
      this.emit('error', voiceError);
      throw voiceError;
    }
  }

  /**
   * 发送音频数据（在文本模式下，这会被忽略）
   */
  async sendAudio(audioData: Float32Array, sampleRate: number): Promise<void> {
    // 在文本模式下，音频数据会被忽略
    // 可以在这里实现语音转文字的功能
    this.emit('audio_start');
    this.emit('audio_end');
  }

  /**
   * 发送文本消息
   */
  async sendText(text: string): Promise<VoiceResponse> {
    try {
      if (!this.model) {
        throw new VoiceError(VoiceErrorType.API_ERROR, 'Not connected to Google Text API');
      }

      // 发送文本到模型
      const result = await this.model.generateContent(text);
      const response = result.response;
      const textResponse = response.text();

      const voiceResponse: VoiceResponse = {
        text: textResponse
      };

      this.emit('response', voiceResponse);
      return voiceResponse;
    } catch (error) {
      const voiceError = this.errorManager.handleError(error, 'GoogleTextAdapter.sendText');
      this.emit('error', voiceError);
      throw voiceError;
    }
  }

  /**
   * 添加事件监听器
   */
  on(event: VoiceEvent, callback: VoiceEventHandler): void {
    if (!this.eventHandlers.has(event)) {
      this.eventHandlers.set(event, []);
    }
    this.eventHandlers.get(event)!.push(callback);
  }

  /**
   * 移除事件监听器
   */
  off(event: VoiceEvent, callback: VoiceEventHandler): void {
    const handlers = this.eventHandlers.get(event);
    if (handlers) {
      const index = handlers.indexOf(callback);
      if (index > -1) {
        handlers.splice(index, 1);
      }
    }
  }

  // ==================== 私有方法 ====================

  /**
   * 初始化 Google GenAI
   */
  private async initializeGoogleGenAI(): Promise<void> {
    const config = this.configManager.getConfig();
    const apiKey = this.configManager.getApiKey();
    
    if (!apiKey) {
      throw new VoiceError(VoiceErrorType.AUTH_ERROR, 'Google API key is not configured');
    }

    // 检查网络连接
    const networkStatus = await this.networkManager.getStatus();
    if (!networkStatus.isOnline) {
      throw new VoiceError(VoiceErrorType.NETWORK_ERROR, 'Network is not available');
    }

    try {
      this.ai = new GoogleGenAI({
        apiKey: apiKey,
        baseUrl: config.voice.api.google.endpoints.primary
      });
    } catch (error) {
      throw new VoiceError(VoiceErrorType.API_ERROR, 'Failed to initialize Google GenAI', error as Error);
    }
  }

  /**
   * 加载文本模型
   */
  private async loadModel(): Promise<void> {
    if (!this.ai) {
      throw new VoiceError(VoiceErrorType.API_ERROR, 'Google GenAI is not initialized');
    }

    const config = this.configManager.getConfig();
    
    try {
      this.model = await this.ai.getGenerativeModel({
        model: config.voice.api.google.models.text
      });
    } catch (error) {
      throw new VoiceError(VoiceErrorType.API_ERROR, 'Failed to load text model', error as Error);
    }
  }

  /**
   * 触发事件
   */
  private emit(event: VoiceEvent, data?: any): void {
    const handlers = this.eventHandlers.get(event) || [];
    handlers.forEach(handler => {
      try {
        handler(event, data);
      } catch (error) {
        console.error(`Error in event handler for ${event}:`, error);
      }
    });
  }
}