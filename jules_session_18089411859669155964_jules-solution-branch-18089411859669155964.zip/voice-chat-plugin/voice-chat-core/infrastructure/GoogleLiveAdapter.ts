import { VoiceAdapter, VoiceResponse, VoiceEvent, VoiceEventHandler, VoiceError, VoiceErrorType, AudioConfig } from '../types';
import { AudioManager } from './AudioManager';
import { ErrorManager } from './ErrorManager';
import { NetworkManager } from './NetworkManager';
import { ConfigManager } from './ConfigManager';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';

/**
 * Google Live API 适配器
 * 
 * 职责：
 * 1. 封装 Google GenAI SDK 的具体实现
 * 2. 处理 Live API 的连接和通信
 * 3. 管理音频数据的发送和接收
 * 4. 处理适配器级别的错误和重试
 */
export class GoogleLiveAdapter implements VoiceAdapter {
  private audioManager: AudioManager;
  private errorManager: ErrorManager;
  private networkManager: NetworkManager;
  private configManager: ConfigManager;
  
  private ai: GoogleGenAI | null = null;
  private session: any = null;
  private isConnecting: boolean = false;
  private reconnectAttempts: number = 0;
  private maxReconnectAttempts: number = 3;
  
  private eventHandlers: Map<VoiceEvent, VoiceEventHandler[]> = new Map();
  private audioQueue: { data: Float32Array; sampleRate: number }[] = [];
  private isProcessingQueue: boolean = false;

  constructor(deps: {
    audioManager: AudioManager;
    errorManager: ErrorManager;
    networkManager: NetworkManager;
    configManager: ConfigManager;
  }) {
    this.audioManager = deps.audioManager;
    this.errorManager = deps.errorManager;
    this.networkManager = deps.networkManager;
    this.configManager = deps.configManager;
  }

  /**
   * 连接到 Google Live API
   */
  async connect(): Promise<void> {
    if (this.isConnecting || this.session) {
      return;
    }

    this.isConnecting = true;

    try {
      // 1. 初始化 Google GenAI
      await this.initializeGoogleGenAI();

      // 2. 建立 Live API 连接
      await this.connectLiveSession();

      this.reconnectAttempts = 0; // 连接成功后重置重试次数
      this.emit('connected');

      // 3. 开始处理音频队列
      this.processAudioQueue();

      console.log('[GoogleLiveAdapter] Connected to Google Live API');
    } catch (error) {
      const voiceError = this.errorManager.handleError(error, 'GoogleLiveAdapter.connect');
      
      // 尝试重连
      if (this.shouldAttemptReconnect()) {
        this.scheduleReconnect();
      } else {
        this.emit('error', voiceError);
        throw voiceError;
      }
    } finally {
      this.isConnecting = false;
    }
  }

  /**
   * 断开连接
   */
  async disconnect(): Promise<void> {
    try {
      if (this.session) {
        await this.session.close();
        this.session = null;
      }
      
      if (this.ai) {
        this.ai = null;
      }
      
      this.audioQueue = [];
      this.isProcessingQueue = false;
      
      this.emit('disconnected');
      console.log('[GoogleLiveAdapter] Disconnected from Google Live API');
    } catch (error) {
      const voiceError = this.errorManager.handleError(error, 'GoogleLiveAdapter.disconnect');
      this.emit('error', voiceError);
      throw voiceError;
    }
  }

  /**
   * 发送音频数据
   */
  async sendAudio(audioData: Float32Array, sampleRate: number): Promise<void> {
    try {
      // 如果还没有连接，将音频数据加入队列
      if (!this.session) {
        this.audioQueue.push({ data: audioData, sampleRate });
        return;
      }

      // 转换音频格式
      const processedData = await this.processAudioData(audioData, sampleRate);
      
      // 发送音频数据
      await this.session.sendRealtimeInput({
        audio: {
          data: processedData,
          mimeType: 'audio/pcm;rate=16000'
        }
      });

      this.emit('audio_start');
    } catch (error) {
      const voiceError = this.errorManager.handleError(error, 'GoogleLiveAdapter.sendAudio');
      this.emit('error', voiceError);
      throw voiceError;
    }
  }

  /**
   * 发送文本消息
   */
  async sendText(text: string): Promise<VoiceResponse> {
    try {
      if (!this.session) {
        throw new VoiceError(VoiceErrorType.API_ERROR, 'Not connected to Google Live API');
      }

      // 发送文本消息
      await this.session.sendClientContent({
        turns: [{ role: 'user', parts: [{ text }] }],
        turnComplete: true
      });

      // 等待响应
      const response = await this.waitForTextResponse();
      
      this.emit('response', response);
      return response;
    } catch (error) {
      const voiceError = this.errorManager.handleError(error, 'GoogleLiveAdapter.sendText');
      this.emit('error', voiceError);
      throw voiceError;
    }
  }

  /**
   * 添加事件监听器
   */
  on(event: VoiceEvent, callback: VoiceEventHandler): void {
    if (!this.eventHandlers.has(event)) {
      this.eventHandlers.set(event, []);
    }
    this.eventHandlers.get(event)!.push(callback);
  }

  /**
   * 移除事件监听器
   */
  off(event: VoiceEvent, callback: VoiceEventHandler): void {
    const handlers = this.eventHandlers.get(event);
    if (handlers) {
      const index = handlers.indexOf(callback);
      if (index > -1) {
        handlers.splice(index, 1);
      }
    }
  }

  // ==================== 私有方法 ====================

  /**
   * 初始化 Google GenAI
   */
  private async initializeGoogleGenAI(): Promise<void> {
    const config = this.configManager.getConfig();
    const apiKey = this.configManager.getApiKey();
    
    if (!apiKey) {
      throw new VoiceError(VoiceErrorType.AUTH_ERROR, 'Google API key is not configured');
    }

    // 检查网络连接
    const networkStatus = await this.networkManager.getStatus();
    if (!networkStatus.isOnline) {
      throw new VoiceError(VoiceErrorType.NETWORK_ERROR, 'Network is not available');
    }

    try {
      this.ai = new GoogleGenAI({
        apiKey: apiKey,
        baseUrl: config.voice.api.google.endpoints.primary
      });
    } catch (error) {
      throw new VoiceError(VoiceErrorType.API_ERROR, 'Failed to initialize Google GenAI', error as Error);
    }
  }

  /**
   * 建立 Live API 连接
   */
  private async connectLiveSession(): Promise<void> {
    if (!this.ai) {
      throw new VoiceError(VoiceErrorType.API_ERROR, 'Google GenAI is not initialized');
    }

    const config = this.configManager.getConfig();
    
    try {
      this.session = await this.ai.live.connect({
        model: config.voice.api.google.models.live,
        callbacks: {
          onopen: () => {
            console.log('[GoogleLiveAdapter] Live session opened');
            this.emit('connected');
          },
          onmessage: (message: LiveServerMessage) => {
            this.handleServerMessage(message);
          },
          onerror: (error: any) => {
            const voiceError = new VoiceError(
              VoiceErrorType.API_ERROR, 
              'Live API error', 
              error,
              { sessionId: this.session?.id }
            );
            this.emit('error', voiceError);
            
            // 触发重连
            this.handleConnectionError(voiceError);
          },
          onclose: () => {
            console.log('[GoogleLiveAdapter] Live session closed');
            this.emit('disconnected');
            
            // 尝试重连
            if (this.shouldAttemptReconnect()) {
              this.scheduleReconnect();
            }
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: {
                voiceName: config.voice.api.google.voiceName || 'Aoede'
              }
            }
          },
          inputAudioTranscription: {},
          outputAudioTranscription: {}
        }
      });
    } catch (error) {
      throw new VoiceError(VoiceErrorType.API_ERROR, 'Failed to connect to Live API', error as Error);
    }
  }

  /**
   * 处理服务器消息
   */
  private handleServerMessage(message: LiveServerMessage): void {
    try {
      // 处理音频响应
      if (message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data) {
        const audioData = message.serverContent.modelTurn.parts[0].inlineData.data;
        this.emit('response', { audio: this.base64ToArrayBuffer(audioData) });
      }

      // 处理转录
      if (message.serverContent?.outputTranscription?.text) {
        this.emit('transcription', {
          role: 'assistant',
          text: message.serverContent.outputTranscription.text,
          confidence: message.serverContent.outputTranscription.confidence
        });
      }

      if (message.serverContent?.inputTranscription?.text) {
        this.emit('transcription', {
          role: 'user',
          text: message.serverContent.inputTranscription.text,
          confidence: message.serverContent.inputTranscription.confidence
        });
      }

      // 处理会话结束
      if (message.serverContent?.turnComplete) {
        this.emit('audio_end');
      }
    } catch (error) {
      const voiceError = this.errorManager.handleError(error, 'GoogleLiveAdapter.handleServerMessage');
      this.emit('error', voiceError);
    }
  }

  /**
   * 处理音频数据
   */
  private async processAudioData(audioData: Float32Array, sampleRate: number): Promise<ArrayBuffer> {
    // 如果采样率不是16kHz，需要重采样
    let processedData = audioData;
    if (sampleRate !== 16000) {
      processedData = this.audioManager.downsampleBuffer(audioData, sampleRate, 16000);
    }

    // 转换为16位PCM
    const pcmData = this.float32ToPCM16(processedData);
    
    return pcmData.buffer;
  }

  /**
   * 等待文本响应
   */
  private async waitForTextResponse(timeout: number = 30000): Promise<VoiceResponse> {
    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        reject(new VoiceError(VoiceErrorType.TIMEOUT_ERROR, 'Text response timeout'));
      }, timeout);

      const handleMessage = (message: LiveServerMessage) => {
        if (message.serverContent?.modelTurn?.parts?.[0]?.text) {
          clearTimeout(timeoutId);
          this.session?.off('message', handleMessage);
          
          resolve({
            text: message.serverContent.modelTurn.parts[0].text
          });
        }
      };

      this.session?.on('message', handleMessage);
    });
  }

  /**
   * 处理连接错误
   */
  private handleConnectionError(error: VoiceError): void {
    console.warn('[GoogleLiveAdapter] Connection error:', error.message);
    
    if (this.shouldAttemptReconnect()) {
      this.scheduleReconnect();
    } else {
      this.emit('error', error);
    }
  }

  /**
   * 检查是否应该重连
   */
  private shouldAttemptReconnect(): boolean {
    return this.reconnectAttempts < this.maxReconnectAttempts;
  }

  /**
   * 安排重连
   */
  private scheduleReconnect(): void {
    this.reconnectAttempts++;
    const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts), 10000); // 指数退避，最大10秒
    
    console.log(`[GoogleLiveAdapter] Scheduling reconnect in ${delay}ms (attempt ${this.reconnectAttempts})`);
    
    setTimeout(async () => {
      try {
        await this.connect();
      } catch (error) {
        console.error('[GoogleLiveAdapter] Reconnect failed:', error);
      }
    }, delay);
  }

  /**
   * 处理音频队列
   */
  private async processAudioQueue(): Promise<void> {
    if (this.isProcessingQueue || this.audioQueue.length === 0) {
      return;
    }

    this.isProcessingQueue = true;

    try {
      while (this.audioQueue.length > 0 && this.session) {
        const { data, sampleRate } = this.audioQueue.shift()!;
        await this.sendAudio(data, sampleRate);
        
        // 避免发送过快
        await new Promise(resolve => setTimeout(resolve, 100));
      }
    } finally {
      this.isProcessingQueue = false;
    }
  }

  /**
   * Float32Array 转 PCM16
   */
  private float32ToPCM16(buffer: Float32Array): Int16Array {
    const pcm = new Int16Array(buffer.length);
    
    for (let i = 0; i < buffer.length; i++) {
      const sample = Math.max(-1, Math.min(1, buffer[i]));
      pcm[i] = sample < 0 ? sample * 0x8000 : sample * 0x7FFF;
    }
    
    return pcm;
  }

  /**
   * Base64 转 ArrayBuffer
   */
  private base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    
    return bytes.buffer;
  }

  /**
   * 触发事件
   */
  private emit(event: VoiceEvent, data?: any): void {
    const handlers = this.eventHandlers.get(event) || [];
    handlers.forEach(handler => {
      try {
        handler(event, data);
      } catch (error) {
        console.error(`Error in event handler for ${event}:`, error);
      }
    });
  }
}