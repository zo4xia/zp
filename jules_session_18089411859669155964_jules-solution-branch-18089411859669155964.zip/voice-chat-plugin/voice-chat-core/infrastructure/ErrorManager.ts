import { VoiceError, VoiceErrorType, LogEntry, Metrics, HealthCheck } from '../types';

/**
 * 错误管理器 - 负责统一的错误处理和恢复策略
 * 
 * 职责：
 * 1. 统一的错误分类和处理
 * 2. 错误恢复策略执行
 * 3. 错误日志记录和监控
 * 4. 健康状态管理
 */
export class ErrorManager {
  private errorCounts: Map<VoiceErrorType, number> = new Map();
  private lastErrorTime: Map<VoiceErrorType, number> = new Map();
  private maxErrorCounts: Map<VoiceErrorType, number> = new Map();
  private errorRecoveryStrategies: Map<VoiceErrorType, (error: VoiceError) => Promise<boolean>> = new Map();
  
  private logCallback?: (entry: LogEntry) => void;
  private metricsCallback?: (metrics: Metrics) => void;
  private healthCallback?: (health: HealthCheck) => void;

  constructor() {
    // 初始化错误计数限制
    this.initializeErrorLimits();
    
    // 注册错误恢复策略
    this.registerRecoveryStrategies();
  }

  /**
   * 处理错误 - 主要的错误处理入口
   */
  handleError(error: Error | VoiceError, context: string): VoiceError {
    const voiceError = this.normalizeError(error, context);
    
    // 记录错误
    this.recordError(voiceError);
    
    // 记录日志
    this.logError(voiceError, context);
    
    // 更新指标
    this.updateMetrics(voiceError, context);
    
    // 尝试恢复
    this.attemptRecovery(voiceError);
    
    // 检查健康状态
    this.updateHealthStatus(voiceError);
    
    return voiceError;
  }

  /**
   * 设置日志回调
   */
  setLogCallback(callback: (entry: LogEntry) => void): void {
    this.logCallback = callback;
  }

  /**
   * 设置指标回调
   */
  setMetricsCallback(callback: (metrics: Metrics) => void): void {
    this.metricsCallback = callback;
  }

  /**
   * 设置健康状态回调
   */
  setHealthCallback(callback: (health: HealthCheck) => void): void {
    this.healthCallback = callback;
  }

  /**
   * 获取错误统计
   */
  getErrorStats(): Record<VoiceErrorType, { count: number; lastTime: number }> {
    const stats: Record<VoiceErrorType, { count: number; lastTime: number }> = {} as any;
    
    for (const [type, count] of this.errorCounts) {
      stats[type] = {
        count,
        lastTime: this.lastErrorTime.get(type) || 0
      };
    }
    
    return stats;
  }

  /**
   * 重置错误计数
   */
  resetErrorCount(type?: VoiceErrorType): void {
    if (type) {
      this.errorCounts.delete(type);
      this.lastErrorTime.delete(type);
    } else {
      this.errorCounts.clear();
      this.lastErrorTime.clear();
    }
  }

  /**
   * 检查是否应该触发降级
   */
  shouldTriggerFallback(errorType: VoiceErrorType): boolean {
    const count = this.errorCounts.get(errorType) || 0;
    const maxCount = this.maxErrorCounts.get(errorType) || 5;
    
    return count >= maxCount;
  }

  /**
   * 执行降级策略
   */
  async executeFallback(fallbackName: string, context: any): Promise<boolean> {
    try {
      console.log(`[ErrorManager] Executing fallback: ${fallbackName}`, context);
      
      // 这里可以实现具体的降级逻辑
      // 例如：切换到备用API、启用离线模式等
      
      this.logInfo(`Fallback executed: ${fallbackName}`, { fallbackName, context });
      return true;
    } catch (error) {
      this.logError(error as Error, 'ErrorManager.executeFallback');
      return false;
    }
  }

  // ==================== 私有方法 ====================

  /**
   * 标准化错误
   */
  private normalizeError(error: Error | VoiceError, context: string): VoiceError {
    if (error instanceof VoiceError) {
      return error;
    }

    // 根据错误信息判断错误类型
    const errorType = this.classifyError(error);
    
    return new VoiceError(
      errorType,
      `Error in ${context}: ${error.message}`,
      error,
      { context, timestamp: Date.now() }
    );
  }

  /**
   * 错误分类
   */
  private classifyError(error: Error): VoiceErrorType {
    const message = error.message.toLowerCase();
    
    if (message.includes('network') || message.includes('timeout')) {
      return VoiceErrorType.NETWORK_ERROR;
    }
    
    if (message.includes('api') || message.includes('404') || message.includes('500')) {
      return VoiceErrorType.API_ERROR;
    }
    
    if (message.includes('microphone') || message.includes('audio')) {
      return VoiceErrorType.AUDIO_ERROR;
    }
    
    if (message.includes('unauthorized') || message.includes('401') || message.includes('403')) {
      return VoiceErrorType.AUTH_ERROR;
    }
    
    if (message.includes('timeout')) {
      return VoiceErrorType.TIMEOUT_ERROR;
    }
    
    // 默认返回 API_ERROR
    return VoiceErrorType.API_ERROR;
  }

  /**
   * 记录错误
   */
  private recordError(error: VoiceError): void {
    const currentCount = this.errorCounts.get(error.type) || 0;
    this.errorCounts.set(error.type, currentCount + 1);
    this.lastErrorTime.set(error.type, Date.now());
  }

  /**
   * 记录日志
   */
  private logError(error: VoiceError, context: string): void {
    const logEntry: LogEntry = {
      level: 'error',
      message: error.message,
      timestamp: Date.now(),
      metadata: {
        errorType: error.type,
        context,
        originalError: error.originalError?.message,
        stack: error.originalError?.stack,
        metadata: error.metadata
      }
    };

    this.logCallback?.(logEntry);
  }

  /**
   * 记录信息日志
   */
  private logInfo(message: string, metadata?: any): void {
    const logEntry: LogEntry = {
      level: 'info',
      message,
      timestamp: Date.now(),
      metadata
    };

    this.logCallback?.(logEntry);
  }

  /**
   * 更新指标
   */
  private updateMetrics(error: VoiceError, context: string): void {
    const metrics: Metrics = {
      name: `error.${error.type}`,
      value: 1,
      timestamp: Date.now(),
      tags: {
        context,
        errorType: error.type
      }
    };

    this.metricsCallback?.(metrics);
  }

  /**
   * 尝试恢复
   */
  private async attemptRecovery(error: VoiceError): Promise<void> {
    const strategy = this.errorRecoveryStrategies.get(error.type);
    
    if (strategy) {
      try {
        const recovered = await strategy(error);
        if (recovered) {
          this.logInfo(`Error recovered: ${error.type}`, { errorType: error.type });
          this.resetErrorCount(error.type);
        }
      } catch (recoveryError) {
        this.logError(recoveryError as Error, 'ErrorManager.attemptRecovery');
      }
    }
  }

  /**
   * 更新健康状态
   */
  private updateHealthStatus(error: VoiceError): void {
    const health: HealthCheck = {
      name: `error.${error.type}`,
      status: this.shouldTriggerFallback(error.type) ? 'unhealthy' : 'healthy',
      message: error.message,
      lastCheck: Date.now(),
      details: {
        errorCount: this.errorCounts.get(error.type),
        maxErrorCount: this.maxErrorCounts.get(error.type),
        lastErrorTime: this.lastErrorTime.get(error.type)
      }
    };

    this.healthCallback?.(health);
  }

  /**
   * 初始化错误限制
   */
  private initializeErrorLimits(): void {
    this.maxErrorCounts.set(VoiceErrorType.NETWORK_ERROR, 5);
    this.maxErrorCounts.set(VoiceErrorType.API_ERROR, 3);
    this.maxErrorCounts.set(VoiceErrorType.AUDIO_ERROR, 3);
    this.maxErrorCounts.set(VoiceErrorType.AUTH_ERROR, 1);
    this.maxErrorCounts.set(VoiceErrorType.TIMEOUT_ERROR, 3);
    this.maxErrorCounts.set(VoiceErrorType.FALLBACK_ERROR, 2);
  }

  /**
   * 注册恢复策略
   */
  private registerRecoveryStrategies(): void {
    // 网络错误恢复策略
    this.errorRecoveryStrategies.set(VoiceErrorType.NETWORK_ERROR, async (error) => {
      // 可以实现网络重连逻辑
      console.log('[ErrorManager] Attempting network recovery');
      return true; // 假设恢复成功
    });

    // API错误恢复策略
    this.errorRecoveryStrategies.set(VoiceErrorType.API_ERROR, async (error) => {
      // 可以实现切换到备用API的逻辑
      console.log('[ErrorManager] Attempting API recovery');
      return false; // 假设恢复失败，需要降级
    });

    // 音频错误恢复策略
    this.errorRecoveryStrategies.set(VoiceErrorType.AUDIO_ERROR, async (error) => {
      // 可以实现音频设备重置逻辑
      console.log('[ErrorManager] Attempting audio recovery');
      return true;
    });

    // 认证错误恢复策略
    this.errorRecoveryStrategies.set(VoiceErrorType.AUTH_ERROR, async (error) => {
      // 认证错误通常需要用户干预
      console.log('[ErrorManager] Auth error, cannot recover automatically');
      return false;
    });
  }
}