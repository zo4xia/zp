import { AudioConfig, AudioBuffer, LogEntry, Metrics } from '../types';

/**
 * 音频管理器 - 负责音频资源的统一管理
 * 
 * 职责：
 * 1. 音频上下文的创建和管理
 * 2. 音频设备的检测和选择
 * 3. 音频数据的处理和转换
 * 4. 音频资源的释放和清理
 */
export class AudioManager {
  private audioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private processorNode: ScriptProcessorNode | null = null;
  
  private config: AudioConfig;
  private isInitialized: boolean = false;
  
  private logCallback?: (entry: LogEntry) => void;
  private metricsCallback?: (metrics: Metrics) => void;

  constructor(config: AudioConfig) {
    this.config = config;
  }

  /**
   * 初始化音频管理器
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) {
      return;
    }

    try {
      // 创建音频上下文
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: this.config.sampleRate
      });

      // 请求麦克风权限
      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          channelCount: 1,
          sampleRate: this.config.sampleRate,
          sampleSize: 16
        }
      });

      this.isInitialized = true;
      
      this.logInfo('Audio manager initialized');
      this.updateMetrics('audio_initialized', 1);
    } catch (error) {
      this.logError(error as Error, 'AudioManager.initialize');
      throw error;
    }
  }

  /**
   * 开始音频录制
   */
  startRecording(onAudioData: (buffer: Float32Array) => void): void {
    if (!this.audioContext || !this.mediaStream) {
      throw new Error('Audio manager not initialized');
    }

    try {
      // 创建音频源节点
      this.sourceNode = this.audioContext.createMediaStreamSource(this.mediaStream);
      
      // 创建脚本处理器节点
      this.processorNode = this.audioContext.createScriptProcessor(
        this.config.bufferSize,
        1, // 输入通道数
        1  // 输出通道数
      );

      // 设置音频处理回调
      this.processorNode.onaudioprocess = (event) => {
        const inputBuffer = event.inputBuffer;
        const inputData = inputBuffer.getChannelData(0);
        
        // 复制数据避免引用问题
        const audioData = new Float32Array(inputData);
        
        // 调用回调函数
        onAudioData(audioData);
      };

      // 连接音频节点
      this.sourceNode.connect(this.processorNode);
      this.processorNode.connect(this.audioContext.destination);
      
      this.logInfo('Audio recording started');
      this.updateMetrics('recording_started', 1);
    } catch (error) {
      this.logError(error as Error, 'AudioManager.startRecording');
      throw error;
    }
  }

  /**
   * 停止音频录制
   */
  stopRecording(): void {
    try {
      if (this.processorNode) {
        this.processorNode.onaudioprocess = null;
        this.processorNode.disconnect();
        this.processorNode = null;
      }

      if (this.sourceNode) {
        this.sourceNode.disconnect();
        this.sourceNode = null;
      }
      
      this.logInfo('Audio recording stopped');
      this.updateMetrics('recording_stopped', 1);
    } catch (error) {
      this.logError(error as Error, 'AudioManager.stopRecording');
      throw error;
    }
  }

  /**
   * 播放音频
   */
  async playAudio(audioData: ArrayBuffer): Promise<void> {
    if (!this.audioContext) {
      throw new Error('Audio context not available');
    }

    try {
      // 解码音频数据
      const audioBuffer = await this.audioContext.decodeAudioData(audioData);
      
      // 创建音频源
      const source = this.audioContext.createBufferSource();
      source.buffer = audioBuffer;
      
      // 连接到输出
      source.connect(this.audioContext.destination);
      
      // 播放
      source.start();
      
      this.logInfo('Audio playback started');
      this.updateMetrics('audio_played', audioBuffer.duration);
    } catch (error) {
      this.logError(error as Error, 'AudioManager.playAudio');
      throw error;
    }
  }

  /**
   * 获取可用的音频设备
   */
  async getAvailableDevices(): Promise<{
    microphones: MediaDeviceInfo[];
    speakers: MediaDeviceInfo[];
  }> {
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      
      const microphones = devices.filter(device => device.kind === 'audioinput');
      const speakers = devices.filter(device => device.kind === 'audiooutput');
      
      return { microphones, speakers };
    } catch (error) {
      this.logError(error as Error, 'AudioManager.getAvailableDevices');
      return { microphones: [], speakers: [] };
    }
  }

  /**
   * 重采样音频数据
   */
  downsampleBuffer(buffer: Float32Array, fromSampleRate: number, toSampleRate: number): Float32Array {
    if (fromSampleRate === toSampleRate) {
      return buffer;
    }

    const sampleRateRatio = fromSampleRate / toSampleRate;
    const newLength = Math.round(buffer.length / sampleRateRatio);
    const result = new Float32Array(newLength);
    
    let offset = 0;
    
    for (let i = 0; i < newLength; i++) {
      const nextOffset = (i + 1) * sampleRateRatio;
      let accumulator = 0;
      let count = 0;
      
      // 累加样本值进行平均
      for (let j = Math.floor(offset); j < Math.floor(nextOffset); j++) {
        accumulator += buffer[j];
        count++;
      }
      
      result[i] = accumulator / count;
      offset = nextOffset;
    }
    
    return result;
  }

  /**
   * 获取输入采样率
   */
  getInputSampleRate(): number {
    return this.audioContext?.sampleRate || this.config.sampleRate;
  }

  /**
   * 获取输出采样率
   */
  getOutputSampleRate(): number {
    return this.audioContext?.sampleRate || this.config.sampleRate;
  }

  /**
   * 清理资源
   */
  async cleanup(): Promise<void> {
    try {
      // 停止录制
      this.stopRecording();
      
      // 停止媒体流
      if (this.mediaStream) {
        this.mediaStream.getTracks().forEach(track => track.stop());
        this.mediaStream = null;
      }
      
      // 关闭音频上下文
      if (this.audioContext && this.audioContext.state !== 'closed') {
        await this.audioContext.close();
        this.audioContext = null;
      }
      
      this.isInitialized = false;
      
      this.logInfo('Audio manager cleaned up');
      this.updateMetrics('audio_cleaned_up', 1);
    } catch (error) {
      this.logError(error as Error, 'AudioManager.cleanup');
      throw error;
    }
  }

  /**
   * 检查是否已初始化
   */
  isReady(): boolean {
    return this.isInitialized;
  }

  /**
   * 设置日志回调
   */
  setLogCallback(callback: (entry: LogEntry) => void): void {
    this.logCallback = callback;
  }

  /**
   * 设置指标回调
   */
  setMetricsCallback(callback: (metrics: Metrics) => void): void {
    this.metricsCallback = callback;
  }

  // ==================== 私有方法 ====================

  /**
   * 记录信息日志
   */
  private logInfo(message: string, metadata?: any): void {
    const logEntry: LogEntry = {
      level: 'info',
      message,
      timestamp: Date.now(),
      metadata
    };
    
    this.logCallback?.(logEntry);
  }

  /**
   * 记录错误日志
   */
  private logError(error: Error, context: string): void {
    const logEntry: LogEntry = {
      level: 'error',
      message: error.message,
      timestamp: Date.now(),
      metadata: {
        context,
        stack: error.stack
      }
    };
    
    this.logCallback?.(logEntry);
  }

  /**
   * 更新指标
   */
  private updateMetrics(name: string, value: number): void {
    const metrics: Metrics = {
      name: `audio.${name}`,
      value,
      timestamp: Date.now()
    };
    
    this.metricsCallback?.(metrics);
  }
}