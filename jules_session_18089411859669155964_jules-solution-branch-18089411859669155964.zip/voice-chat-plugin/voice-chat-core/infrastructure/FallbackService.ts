import { VoiceAdapter, VoiceResponse, VoiceError, VoiceErrorType, FallbackStrategy, FallbackContext, LogEntry, Metrics } from '../types';
import { GoogleLiveAdapter } from './GoogleLiveAdapter';
import { GoogleTextAdapter } from './GoogleTextAdapter';
import { LocalTTSAdapter } from './LocalTTSAdapter';

/**
 * 降级服务 - 负责在主要服务失败时提供备用方案
 * 
 * 职责：
 * 1. 管理多种降级策略
 * 2. 根据错误类型选择合适的降级方案
 * 3. 执行降级逻辑
 * 4. 监控降级服务的健康状态
 */
export class FallbackService {
  private strategies: FallbackStrategy[] = [];
  private currentAdapter: VoiceAdapter | null = null;
  private fallbackHistory: Array<{
    timestamp: number;
    originalError: VoiceError;
    strategy: string;
    success: boolean;
  }> = [];
  
  private logCallback?: (entry: LogEntry) => void;
  private metricsCallback?: (metrics: Metrics) => void;

  constructor() {
    this.initializeStrategies();
  }

  /**
   * 添加降级策略
   */
  addStrategy(strategy: FallbackStrategy): void {
    this.strategies.push(strategy);
    this.strategies.sort((a, b) => a.priority - b.priority); // 按优先级排序
  }

  /**
   * 执行降级
   */
  async executeFallback(
    originalError: VoiceError,
    currentAdapter: VoiceAdapter,
    availableAdapters: VoiceAdapter[],
    session: any = null
  ): Promise<VoiceAdapter | null> {
    const context: FallbackContext = {
      originalError,
      currentAdapter,
      availableAdapters,
      session
    };

    this.logInfo('Starting fallback execution', {
      errorType: originalError.type,
      errorMessage: originalError.message,
      adapterCount: availableAdapters.length
    });

    // 按优先级尝试每个策略
    for (const strategy of this.strategies) {
      try {
        if (strategy.canHandle(originalError)) {
          this.logInfo(`Trying fallback strategy: ${strategy.name}`, {
            strategy: strategy.name,
            errorType: originalError.type
          });

          const success = await strategy.execute(context);
          
          this.fallbackHistory.push({
            timestamp: Date.now(),
            originalError,
            strategy: strategy.name,
            success
          });

          this.updateMetrics('fallback_attempt', 1, {
            strategy: strategy.name,
            errorType: originalError.type,
            success: success.toString()
          });

          if (success) {
            this.logInfo(`Fallback successful with strategy: ${strategy.name}`, {
              strategy: strategy.name
            });

            this.updateMetrics('fallback_success', 1, {
              strategy: strategy.name
            });

            // 如果策略返回了新的适配器，使用它
            if (context.currentAdapter !== currentAdapter) {
              this.currentAdapter = context.currentAdapter;
              return this.currentAdapter;
            }
            
            return currentAdapter;
          }
        }
      } catch (error) {
        this.logError(error as Error, `Fallback strategy ${strategy.name} failed`);
        
        this.updateMetrics('fallback_error', 1, {
          strategy: strategy.name,
          error: (error as Error).message
        });
      }
    }

    // 所有降级策略都失败了
    this.logError(new Error('All fallback strategies failed'), 'FallbackService.executeFallback');
    
    this.updateMetrics('fallback_exhausted', 1, {
      errorType: originalError.type
    });

    return null;
  }

  /**
   * 获取降级历史
   */
  getFallbackHistory(): Array<{
    timestamp: number;
    originalError: VoiceError;
    strategy: string;
    success: boolean;
  }> {
    return [...this.fallbackHistory];
  }

  /**
   * 获取降级统计
   */
  getFallbackStats(): {
    totalAttempts: number;
    successCount: number;
    successRate: number;
    strategyStats: Record<string, { attempts: number; successes: number }>;
  } {
    const totalAttempts = this.fallbackHistory.length;
    const successCount = this.fallbackHistory.filter(h => h.success).length;
    const successRate = totalAttempts > 0 ? successCount / totalAttempts : 0;

    const strategyStats: Record<string, { attempts: number; successes: number }> = {};

    this.fallbackHistory.forEach(history => {
      if (!strategyStats[history.strategy]) {
        strategyStats[history.strategy] = { attempts: 0, successes: 0 };
      }
      strategyStats[history.strategy].attempts++;
      if (history.success) {
        strategyStats[history.strategy].successes++;
      }
    });

    return {
      totalAttempts,
      successCount,
      successRate,
      strategyStats
    };
  }

  /**
   * 设置日志回调
   */
  setLogCallback(callback: (entry: LogEntry) => void): void {
    this.logCallback = callback;
  }

  /**
   * 设置指标回调
   */
  setMetricsCallback(callback: (metrics: Metrics) => void): void {
    this.metricsCallback = callback;
  }

  // ==================== 私有方法 ====================

  /**
   * 初始化降级策略
   */
  private initializeStrategies(): void {
    // 1. Google Text API 降级策略
    this.addStrategy(new GoogleTextFallbackStrategy());

    // 2. 本地TTS降级策略
    this.addStrategy(new LocalTTSFallbackStrategy());

    // 3. 离线模式降级策略
    this.addStrategy(new OfflineFallbackStrategy());
  }

  /**
   * 记录信息日志
   */
  private logInfo(message: string, metadata?: any): void {
    const logEntry: LogEntry = {
      level: 'info',
      message,
      timestamp: Date.now(),
      metadata
    };
    
    this.logCallback?.(logEntry);
  }

  /**
   * 记录错误日志
   */
  private logError(error: Error, context: string): void {
    const logEntry: LogEntry = {
      level: 'error',
      message: error.message,
      timestamp: Date.now(),
      metadata: {
        context,
        stack: error.stack
      }
    };
    
    this.logCallback?.(logEntry);
  }

  /**
   * 更新指标
   */
  private updateMetrics(name: string, value: number, tags?: Record<string, string>): void {
    const metrics: Metrics = {
      name: `fallback.${name}`,
      value,
      timestamp: Date.now(),
      tags
    };
    
    this.metricsCallback?.(metrics);
  }
}

/**
 * Google Text API 降级策略
 */
class GoogleTextFallbackStrategy implements FallbackStrategy {
  name = 'Google Text API';
  priority = 1;

  canHandle(error: VoiceError): boolean {
    // 对于网络错误、API错误、超时错误，尝试降级到文本API
    return [
      VoiceErrorType.NETWORK_ERROR,
      VoiceErrorType.API_ERROR,
      VoiceErrorType.TIMEOUT_ERROR
    ].includes(error.type);
  }

  async execute(context: FallbackContext): Promise<boolean> {
    try {
      // 查找Google Text Adapter
      const textAdapter = context.availableAdapters.find(
        adapter => adapter instanceof GoogleTextAdapter
      ) as GoogleTextAdapter;

      if (!textAdapter) {
        return false;
      }

      // 连接Text Adapter
      await textAdapter.connect();
      
      // 切换到Text Adapter
      context.currentAdapter = textAdapter;
      
      return true;
    } catch (error) {
      throw new Error(`Google Text API fallback failed: ${error}`);
    }
  }
}

/**
 * 本地TTS降级策略
 */
class LocalTTSFallbackStrategy implements FallbackStrategy {
  name = 'Local TTS';
  priority = 2;

  canHandle(error: VoiceError): boolean {
    // 当Google服务完全不可用时，降级到本地TTS
    return [
      VoiceErrorType.NETWORK_ERROR,
      VoiceErrorType.API_ERROR,
      VoiceErrorType.AUTH_ERROR
    ].includes(error.type);
  }

  async execute(context: FallbackContext): Promise<boolean> {
    try {
      // 查找Local TTS Adapter
      const localAdapter = context.availableAdapters.find(
        adapter => adapter instanceof LocalTTSAdapter
      ) as LocalTTSAdapter;

      if (!localAdapter) {
        return false;
      }

      // 连接Local Adapter
      await localAdapter.connect();
      
      // 切换到Local Adapter
      context.currentAdapter = localAdapter;
      
      return true;
    } catch (error) {
      throw new Error(`Local TTS fallback failed: ${error}`);
    }
  }
}

/**
 * 离线模式降级策略
 */
class OfflineFallbackStrategy implements FallbackStrategy {
  name = 'Offline Mode';
  priority = 3;

  canHandle(error: VoiceError): boolean {
    // 当所有在线服务都不可用时，启用离线模式
    return true; // 最后的降级策略，处理所有错误
  }

  async execute(context: FallbackContext): Promise<boolean> {
    try {
      // 在离线模式下，我们可以：
      // 1. 提供缓存的响应
      // 2. 显示友好的错误消息
      // 3. 等待网络恢复

      // 这里可以实现具体的离线逻辑
      console.log('[FallbackService] Entering offline mode');
      
      return true;
    } catch (error) {
      throw new Error(`Offline mode fallback failed: ${error}`);
    }
  }
}