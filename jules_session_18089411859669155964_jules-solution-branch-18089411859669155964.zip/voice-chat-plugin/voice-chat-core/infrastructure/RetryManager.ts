import { RetryConfig, RetryStrategy, LogEntry, Metrics } from '../types';

/**
 * 重试管理器 - 负责实现智能重试机制
 * 
 * 职责：
 * 1. 实现指数退避算法
 * 2. 管理重试次数和延迟
 * 3. 提供多种重试策略
 * 4. 记录重试统计信息
 */
export class RetryManager {
  private config: RetryConfig;
  private retryStrategies: Map<string, RetryStrategy> = new Map();
  
  private logCallback?: (entry: LogEntry) => void;
  private metricsCallback?: (metrics: Metrics) => void;

  constructor(config: RetryConfig) {
    this.config = config;
    this.initializeStrategies();
  }

  /**
   * 使用重试机制执行函数
   */
  async executeWithRetry<T>(
    fn: () => Promise<T>,
    operationName: string = 'operation',
    strategyName: string = 'exponential'
  ): Promise<T> {
    const strategy = this.retryStrategies.get(strategyName);
    if (!strategy) {
      throw new Error(`Unknown retry strategy: ${strategyName}`);
    }

    let lastError: Error | null = null;
    
    for (let attempt = 1; attempt <= this.config.maxAttempts; attempt++) {
      try {
        const result = await fn();
        
        // 成功时记录指标
        this.updateMetrics('retry_success', attempt, {
          operation: operationName,
          strategy: strategyName,
          attempts: attempt
        });
        
        this.logInfo(`Operation succeeded after ${attempt} attempts`, {
          operation: operationName,
          strategy: strategyName,
          attempts: attempt
        });
        
        return result;
      } catch (error) {
        lastError = error as Error;
        
        // 记录失败
        this.updateMetrics('retry_failure', 1, {
          operation: operationName,
          strategy: strategyName,
          attempt,
          error: error instanceof Error ? error.message : 'Unknown error'
        });
        
        this.logInfo(`Operation failed (attempt ${attempt}/${this.config.maxAttempts})`, {
          operation: operationName,
          strategy: strategyName,
          attempt,
          error: error instanceof Error ? error.message : 'Unknown error'
        });
        
        // 检查是否应该重试
        if (!strategy.shouldRetry(attempt, lastError)) {
          break;
        }
        
        // 计算延迟时间
        const delay = strategy.getDelay(attempt);
        
        this.logInfo(`Waiting ${delay}ms before retry`, {
          operation: operationName,
          strategy: strategyName,
          attempt,
          delay
        });
        
        // 等待延迟时间
        await this.sleep(delay);
      }
    }
    
    // 所有重试都失败了
    this.updateMetrics('retry_exhausted', 1, {
      operation: operationName,
      strategy: strategyName,
      attempts: this.config.maxAttempts,
      error: lastError?.message
    });
    
    this.logError(lastError as Error, `All retry attempts failed for ${operationName}`);
    
    throw lastError;
  }

  /**
   * 使用退避策略执行函数
   */
  async executeWithBackoff<T>(
    fn: () => Promise<T>,
    operationName: string = 'operation'
  ): Promise<T> {
    return this.executeWithRetry(fn, operationName, 'exponential');
  }

  /**
   * 使用固定延迟策略执行函数
   */
  async executeWithFixedDelay<T>(
    fn: () => Promise<T>,
    operationName: string = 'operation'
  ): Promise<T> {
    return this.executeWithRetry(fn, operationName, 'fixed');
  }

  /**
   * 添加自定义重试策略
   */
  addStrategy(name: string, strategy: RetryStrategy): void {
    this.retryStrategies.set(name, strategy);
  }

  /**
   * 获取重试配置
   */
  getConfig(): RetryConfig {
    return { ...this.config };
  }

  /**
   * 设置日志回调
   */
  setLogCallback(callback: (entry: LogEntry) => void): void {
    this.logCallback = callback;
  }

  /**
   * 设置指标回调
   */
  setMetricsCallback(callback: (metrics: Metrics) => void): void {
    this.metricsCallback = callback;
  }

  // ==================== 私有方法 ====================

  /**
   * 初始化重试策略
   */
  private initializeStrategies(): void {
    // 指数退避策略
    this.retryStrategies.set('exponential', new ExponentialBackoffStrategy(this.config));
    
    // 固定延迟策略
    this.retryStrategies.set('fixed', new FixedDelayStrategy(this.config));
    
    // 线性退避策略
    this.retryStrategies.set('linear', new LinearBackoffStrategy(this.config));
  }

  /**
   * 睡眠
   */
  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * 记录信息日志
   */
  private logInfo(message: string, metadata?: any): void {
    const logEntry: LogEntry = {
      level: 'info',
      message,
      timestamp: Date.now(),
      metadata
    };
    
    this.logCallback?.(logEntry);
  }

  /**
   * 记录错误日志
   */
  private logError(error: Error, context: string): void {
    const logEntry: LogEntry = {
      level: 'error',
      message: error.message,
      timestamp: Date.now(),
      metadata: {
        context,
        stack: error.stack
      }
    };
    
    this.logCallback?.(logEntry);
  }

  /**
   * 更新指标
   */
  private updateMetrics(name: string, value: number, tags?: Record<string, string>): void {
    const metrics: Metrics = {
      name: `retry.${name}`,
      value,
      timestamp: Date.now(),
      tags
    };
    
    this.metricsCallback?.(metrics);
  }
}

/**
 * 指数退避策略
 */
class ExponentialBackoffStrategy implements RetryStrategy {
  constructor(private config: RetryConfig) {}

  shouldRetry(attempt: number, error: Error): boolean {
    // 对于网络错误和超时错误，总是重试
    const message = error.message.toLowerCase();
    if (message.includes('network') || message.includes('timeout')) {
      return attempt < this.config.maxAttempts;
    }
    
    // 对于其他错误，只重试前几次
    return attempt < Math.min(this.config.maxAttempts, 3);
  }

  getDelay(attempt: number): number {
    const delay = Math.min(
      this.config.baseDelay * Math.pow(this.config.backoffMultiplier, attempt - 1),
      this.config.maxDelay
    );
    
    // 添加抖动，避免雪崩效应
    const jitter = Math.random() * 0.1 * delay;
    return Math.floor(delay + jitter);
  }
}

/**
 * 固定延迟策略
 */
class FixedDelayStrategy implements RetryStrategy {
  constructor(private config: RetryConfig) {}

  shouldRetry(attempt: number, error: Error): boolean {
    return attempt < this.config.maxAttempts;
  }

  getDelay(attempt: number): number {
    return this.config.baseDelay;
  }
}

/**
 * 线性退避策略
 */
class LinearBackoffStrategy implements RetryStrategy {
  constructor(private config: RetryConfig) {}

  shouldRetry(attempt: number, error: Error): boolean {
    return attempt < this.config.maxAttempts;
  }

  getDelay(attempt: number): number {
    const delay = this.config.baseDelay * attempt;
    return Math.min(delay, this.config.maxDelay);
  }
}