import { NetworkConfig, NetworkStatus, HealthCheck, Metrics, LogEntry } from '../types';

/**
 * 网络管理器 - 负责网络连接管理和CDN切换
 * 
 * 职责：
 * 1. 网络连接状态监控
 * 2. CDN健康检查和自动切换
 * 3. 网络重试机制
 * 4. 带宽和延迟检测
 */
export class NetworkManager {
  private config: NetworkConfig;
  private currentStatus: NetworkStatus = {
    isOnline: navigator.onLine,
    latency: 0,
    lastCheck: 0
  };
  
  private healthCheckInterval: number = 30000; // 30秒检查一次
  private healthCheckTimer: any = null;
  private cdnHealthStatus: Map<string, boolean> = new Map();
  private currentCdnIndex: number = 0;
  
  private statusChangeCallback?: (status: NetworkStatus) => void;
  private metricsCallback?: (metrics: Metrics) => void;
  private logCallback?: (entry: LogEntry) => void;

  constructor(config: NetworkConfig) {
    this.config = config;
    this.initialize();
  }

  /**
   * 获取当前网络状态
   */
  getStatus(): NetworkStatus {
    return { ...this.currentStatus };
  }

  /**
   * 获取当前CDN地址
   */
  getCurrentCdn(): string {
    const primary = this.config.endpoints.primary;
    const backups = this.config.endpoints.backup;
    
    if (this.cdnHealthStatus.get(primary) === true) {
      return primary;
    }
    
    // 查找健康的备用CDN
    for (const backup of backups) {
      if (this.cdnHealthStatus.get(backup) === true) {
        return backup;
      }
    }
    
    // 如果都没有健康，返回主CDN
    return primary;
  }

  /**
   * 执行健康检查
   */
  async performHealthCheck(): Promise<HealthCheck> {
    const startTime = Date.now();
    
    try {
      // 检查主CDN
      const primaryHealthy = await this.checkCdnHealth(this.config.endpoints.primary);
      this.cdnHealthStatus.set(this.config.endpoints.primary, primaryHealthy);
      
      // 检查备用CDN
      const backupHealth: Record<string, boolean> = {};
      for (const backup of this.config.endpoints.backup) {
        const healthy = await this.checkCdnHealth(backup);
        this.cdnHealthStatus.set(backup, healthy);
        backupHealth[backup] = healthy;
      }
      
      const isHealthy = primaryHealthy || Object.values(backupHealth).some(h => h);
      
      const healthCheck: HealthCheck = {
        name: 'network',
        status: isHealthy ? 'healthy' : 'unhealthy',
        message: isHealthy ? 'Network is healthy' : 'All CDNs are unhealthy',
        lastCheck: Date.now(),
        details: {
          primary: {
            url: this.config.endpoints.primary,
            healthy: primaryHealthy
          },
          backups: backupHealth,
          latency: Date.now() - startTime
        }
      };
      
      this.updateMetrics('health_check', Date.now() - startTime);
      this.logInfo('Health check completed', healthCheck);
      
      return healthCheck;
    } catch (error) {
      this.logError(error as Error, 'NetworkManager.performHealthCheck');
      
      return {
        name: 'network',
        status: 'unhealthy',
        message: 'Health check failed',
        lastCheck: Date.now(),
        details: { error: (error as Error).message }
      };
    }
  }

  /**
   * 测试网络延迟
   */
  async testLatency(url?: string): Promise<number> {
    const testUrl = url || this.getCurrentCdn();
    const startTime = Date.now();
    
    try {
      const response = await fetch(testUrl, {
        method: 'HEAD',
        mode: 'no-cors',
        cache: 'no-cache',
        signal: AbortSignal.timeout(this.config.timeout)
      });
      
      const latency = Date.now() - startTime;
      this.currentStatus.latency = latency;
      this.currentStatus.lastCheck = Date.now();
      
      this.updateMetrics('latency', latency);
      this.logInfo(`Latency test: ${latency}ms`, { url: testUrl });
      
      return latency;
    } catch (error) {
      const latency = Date.now() - startTime;
      this.logError(error as Error, `Latency test failed for ${testUrl}`);
      return latency;
    }
  }

  /**
   * 检查带宽（简单实现）
   */
  async testBandwidth(url?: string): Promise<number> {
    const testUrl = url || this.getCurrentCdn();
    const startTime = Date.now();
    const testSize = 1024 * 1024; // 1MB
    
    try {
      const response = await fetch(`${testUrl}/test-data?size=${testSize}`, {
        signal: AbortSignal.timeout(this.config.timeout)
      });
      
      const data = await response.arrayBuffer();
      const duration = (Date.now() - startTime) / 1000;
      const bandwidth = (data.byteLength * 8) / duration; // bits per second
      
      this.updateMetrics('bandwidth', bandwidth);
      this.logInfo(`Bandwidth test: ${bandwidth / 1024 / 1024} Mbps`, { url: testUrl });
      
      return bandwidth;
    } catch (error) {
      this.logError(error as Error, `Bandwidth test failed for ${testUrl}`);
      return 0;
    }
  }

  /**
   * 执行带重试的网络请求
   */
  async executeWithRetry<T>(
    requestFn: (cdn: string) => Promise<T>,
    maxAttempts?: number
  ): Promise<T> {
    const attempts = maxAttempts || this.config.retryConfig.maxAttempts;
    
    for (let i = 0; i < attempts; i++) {
      try {
        const cdn = this.getCurrentCdn();
        const result = await requestFn(cdn);
        
        // 请求成功，重置CDN健康状态
        this.cdnHealthStatus.set(cdn, true);
        this.updateMetrics('request_success', 1);
        
        return result;
      } catch (error) {
        const cdn = this.getCurrentCdn();
        this.cdnHealthStatus.set(cdn, false);
        this.updateMetrics('request_failure', 1);
        
        this.logError(error as Error, `Request failed (attempt ${i + 1}/${attempts})`);
        
        if (i === attempts - 1) {
          throw error;
        }
        
        // 指数退避
        const delay = Math.min(
          this.config.retryConfig.baseDelay * Math.pow(2, i),
          this.config.retryConfig.maxDelay
        );
        
        await this.sleep(delay);
      }
    }
    
    throw new Error('All retry attempts failed');
  }

  /**
   * 手动切换CDN
   */
  switchCdn(cdnUrl: string): boolean {
    if (this.cdnHealthStatus.get(cdnUrl) === true) {
      this.logInfo(`Manually switching to CDN: ${cdnUrl}`);
      return true;
    }
    
    this.logError(new Error(`CDN is not healthy: ${cdnUrl}`), 'NetworkManager.switchCdn');
    return false;
  }

  /**
   * 设置状态变更回调
   */
  onStatusChange(callback: (status: NetworkStatus) => void): () => void {
    this.statusChangeCallback = callback;
    
    return () => {
      this.statusChangeCallback = undefined;
    };
  }

  /**
   * 设置指标回调
   */
  setMetricsCallback(callback: (metrics: Metrics) => void): void {
    this.metricsCallback = callback;
  }

  /**
   * 设置日志回调
   */
  setLogCallback(callback: (entry: LogEntry) => void): void {
    this.logCallback = callback;
  }

  /**
   * 启动健康检查
   */
  startHealthCheck(): void {
    if (this.healthCheckTimer) {
      return;
    }
    
    this.healthCheckTimer = setInterval(async () => {
      await this.performHealthCheck();
    }, this.healthCheckInterval);
  }

  /**
   * 停止健康检查
   */
  stopHealthCheck(): void {
    if (this.healthCheckTimer) {
      clearInterval(this.healthCheckTimer);
      this.healthCheckTimer = null;
    }
  }

  /**
   * 清理资源
   */
  cleanup(): void {
    this.stopHealthCheck();
  }

  // ==================== 私有方法 ====================

  /**
   * 初始化
   */
  private initialize(): void {
    // 监听网络状态变化
    window.addEventListener('online', () => {
      this.currentStatus.isOnline = true;
      this.currentStatus.lastCheck = Date.now();
      this.statusChangeCallback?.({ ...this.currentStatus });
      this.logInfo('Network online');
    });
    
    window.addEventListener('offline', () => {
      this.currentStatus.isOnline = false;
      this.currentStatus.lastCheck = Date.now();
      this.statusChangeCallback?.({ ...this.currentStatus });
      this.logInfo('Network offline');
    });
    
    // 初始化CDN健康状态
    this.cdnHealthStatus.set(this.config.endpoints.primary, true);
    this.config.endpoints.backup.forEach(url => {
      this.cdnHealthStatus.set(url, true);
    });
    
    // 启动健康检查
    this.startHealthCheck();
  }

  /**
   * 检查CDN健康状态
   */
  private async checkCdnHealth(url: string): Promise<boolean> {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.config.timeout);
      
      const response = await fetch(url, {
        method: 'HEAD',
        mode: 'no-cors',
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      return true;
    } catch (error) {
      return false;
    }
  }

  /**
   * 睡眠
   */
  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * 更新指标
   */
  private updateMetrics(name: string, value: number): void {
    const metrics: Metrics = {
      name: `network.${name}`,
      value,
      timestamp: Date.now(),
      tags: {
        cdn: this.getCurrentCdn()
      }
    };
    
    this.metricsCallback?.(metrics);
  }

  /**
   * 记录信息日志
   */
  private logInfo(message: string, metadata?: any): void {
    const logEntry: LogEntry = {
      level: 'info',
      message,
      timestamp: Date.now(),
      metadata
    };
    
    this.logCallback?.(logEntry);
  }

  /**
   * 记录错误日志
   */
  private logError(error: Error, context: string): void {
    const logEntry: LogEntry = {
      level: 'error',
      message: error.message,
      timestamp: Date.now(),
      metadata: {
        context,
        stack: error.stack
      }
    };
    
    this.logCallback?.(logEntry);
  }
}