import { VoiceAdapter, VoiceResponse, VoiceEvent, VoiceEventHandler, VoiceError, VoiceErrorType } from '../types';
import { AudioManager } from './AudioManager';
import { ErrorManager } from './ErrorManager';
import { ConfigManager } from './ConfigManager';

/**
 * 本地TTS适配器 - 用于完全离线的语音合成
 * 
 * 职责：
 * 1. 使用浏览器内置的Web Speech API
 * 2. 提供离线语音合成功能
 * 3. 作为最终的降级方案
 */
export class LocalTTSAdapter implements VoiceAdapter {
  private audioManager: AudioManager;
  private errorManager: ErrorManager;
  private configManager: ConfigManager;
  
  private speechSynthesis: SpeechSynthesis | null = null;
  private isConnecting: boolean = false;
  private isConnected: boolean = false;
  
  private eventHandlers: Map<VoiceEvent, VoiceEventHandler[]> = new Map();

  constructor(deps: {
    audioManager: AudioManager;
    errorManager: ErrorManager;
    configManager: ConfigManager;
  }) {
    this.audioManager = deps.audioManager;
    this.errorManager = deps.errorManager;
    this.configManager = deps.configManager;
  }

  /**
   * 连接到本地TTS服务
   */
  async connect(): Promise<void> {
    if (this.isConnecting || this.isConnected) {
      return;
    }

    this.isConnecting = true;

    try {
      // 检查浏览器是否支持Web Speech API
      if (!('speechSynthesis' in window)) {
        throw new VoiceError(VoiceErrorType.AUDIO_ERROR, 'Web Speech API is not supported in this browser');
      }

      this.speechSynthesis = window.speechSynthesis;
      
      // 等待语音列表加载
      await this.waitForVoices();
      
      this.isConnected = true;
      this.emit('connected');
      
      console.log('[LocalTTSAdapter] Connected to local TTS');
    } catch (error) {
      const voiceError = this.errorManager.handleError(error, 'LocalTTSAdapter.connect');
      this.emit('error', voiceError);
      throw voiceError;
    } finally {
      this.isConnecting = false;
    }
  }

  /**
   * 断开连接
   */
  async disconnect(): Promise<void> {
    try {
      // 取消所有正在进行的语音合成
      if (this.speechSynthesis) {
        this.speechSynthesis.cancel();
      }
      
      this.speechSynthesis = null;
      this.isConnected = false;
      
      this.emit('disconnected');
      console.log('[LocalTTSAdapter] Disconnected from local TTS');
    } catch (error) {
      const voiceError = this.errorManager.handleError(error, 'LocalTTSAdapter.disconnect');
      this.emit('error', voiceError);
      throw voiceError;
    }
  }

  /**
   * 发送音频数据（在本地TTS中忽略）
   */
  async sendAudio(audioData: Float32Array, sampleRate: number): Promise<void> {
    // 本地TTS不处理音频输入
    this.emit('audio_start');
    this.emit('audio_end');
  }

  /**
   * 发送文本消息并合成语音
   */
  async sendText(text: string): Promise<VoiceResponse> {
    try {
      if (!this.isConnected) {
        throw new VoiceError(VoiceErrorType.API_ERROR, 'Not connected to local TTS');
      }

      if (!text || text.trim().length === 0) {
        throw new VoiceError(VoiceErrorType.API_ERROR, 'Text cannot be empty');
      }

      // 创建语音合成请求
      const utterance = new SpeechSynthesisUtterance(text);
      
      // 设置语音参数
      const voices = this.speechSynthesis?.getVoices() || [];
      const config = this.configManager.getConfig();
      
      // 选择语音
      const preferredVoice = this.selectVoice(voices, config);
      if (preferredVoice) {
        utterance.voice = preferredVoice;
      }
      
      // 设置语速和音调
      utterance.rate = config.audio.outputSampleRate / 24000; // 根据配置调整
      utterance.pitch = 1.0;
      utterance.volume = 1.0;

      // 设置事件回调
      utterance.onstart = () => {
        this.emit('audio_start');
      };
      
      utterance.onend = () => {
        this.emit('audio_end');
      };
      
      utterance.onerror = (event) => {
        const error = new VoiceError(VoiceErrorType.AUDIO_ERROR, `TTS error: ${event.error}`);
        this.emit('error', error);
      };

      // 开始语音合成
      this.speechSynthesis?.speak(utterance);

      const voiceResponse: VoiceResponse = {
        text: text,
        audio: null // 本地TTS直接播放，不返回音频数据
      };

      this.emit('response', voiceResponse);
      return voiceResponse;
    } catch (error) {
      const voiceError = this.errorManager.handleError(error, 'LocalTTSAdapter.sendText');
      this.emit('error', voiceError);
      throw voiceError;
    }
  }

  /**
   * 添加事件监听器
   */
  on(event: VoiceEvent, callback: VoiceEventHandler): void {
    if (!this.eventHandlers.has(event)) {
      this.eventHandlers.set(event, []);
    }
    this.eventHandlers.get(event)!.push(callback);
  }

  /**
   * 移除事件监听器
   */
  off(event: VoiceEvent, callback: VoiceEventHandler): void {
    const handlers = this.eventHandlers.get(event);
    if (handlers) {
      const index = handlers.indexOf(callback);
      if (index > -1) {
        handlers.splice(index, 1);
      }
    }
  }

  // ==================== 私有方法 ====================

  /**
   * 等待语音列表加载
   */
  private waitForVoices(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.speechSynthesis) {
        reject(new Error('SpeechSynthesis not available'));
        return;
      }

      const checkVoices = () => {
        const voices = this.speechSynthesis?.getVoices() || [];
        if (voices.length > 0) {
          resolve();
        } else {
          setTimeout(checkVoices, 100);
        }
      };

      // 添加事件监听器
      this.speechSynthesis.onvoiceschanged = checkVoices;
      
      // 立即检查一次
      checkVoices();

      // 超时处理
      setTimeout(() => {
        if (!this.speechSynthesis?.getVoices().length) {
          reject(new Error('Timeout waiting for voices'));
        }
      }, 5000);
    });
  }

  /**
   * 选择合适的语音
   */
  private selectVoice(voices: SpeechSynthesisVoice[], config: any): SpeechSynthesisVoice | null {
    // 优先选择中文语音
    const chineseVoices = voices.filter(v => 
      v.lang && (v.lang.includes('zh-CN') || v.lang.includes('zh-TW'))
    );
    
    if (chineseVoices.length > 0) {
      return chineseVoices[0];
    }

    // 其次选择英文语音
    const englishVoices = voices.filter(v => 
      v.lang && v.lang.includes('en-US')
    );
    
    if (englishVoices.length > 0) {
      return englishVoices[0];
    }

    // 返回默认语音
    return voices[0] || null;
  }

  /**
   * 触发事件
   */
  private emit(event: VoiceEvent, data?: any): void {
    const handlers = this.eventHandlers.get(event) || [];
    handlers.forEach(handler => {
      try {
        handler(event, data);
      } catch (error) {
        console.error(`Error in event handler for ${event}:`, error);
      }
    });
  }
}