import { VoiceConfig, AppConfig } from '../types';

/**
 * 配置管理器 - 负责统一的配置管理
 * 
 * 职责：
 * 1. 配置的加载和验证
 * 2. 配置的动态更新
 * 3. API密钥轮换
 * 4. CDN配置管理
 * 5. 环境配置隔离
 */
export class ConfigManager {
  private config: AppConfig;
  private configListeners: ((config: AppConfig) => void)[] = [];
  private apiKeyIndex: number = 0;

  constructor(initialConfig: AppConfig) {
    this.config = this.validateAndNormalizeConfig(initialConfig);
  }

  /**
   * 获取完整配置
   */
  getConfig(): AppConfig {
    return { ...this.config };
  }

  /**
   * 获取语音配置
   */
  getVoiceConfig(): VoiceConfig {
    return { ...this.config.voice };
  }

  /**
   * 获取API密钥（轮换）
   */
  getApiKey(): string {
    const keys = this.config.voice.api.google.apiKeys;
    if (!keys || keys.length === 0) {
      return '';
    }

    const key = keys[this.apiKeyIndex];
    this.apiKeyIndex = (this.apiKeyIndex + 1) % keys.length;
    
    return key;
  }

  /**
   * 获取下一个API密钥（不轮换索引）
   */
  getNextApiKey(): string {
    const keys = this.config.voice.api.google.apiKeys;
    if (!keys || keys.length === 0) {
      return '';
    }

    const nextIndex = (this.apiKeyIndex + 1) % keys.length;
    return keys[nextIndex];
  }

  /**
   * 获取主CDN地址
   */
  getPrimaryCdn(): string {
    const cdnList = this.config.voice.cdn.google;
    return cdnList[0] || '';
  }

  /**
   * 获取备用CDN地址列表
   */
  getFallbackCdns(): string[] {
    const cdnList = this.config.voice.cdn.google;
    return cdnList.slice(1);
  }

  /**
   * 获取本地CDN地址
   */
  getLocalCdn(): string {
    return this.config.voice.cdn.local;
  }

  /**
   * 更新配置
   */
  updateConfig(newConfig: Partial<AppConfig>): void {
    this.config = this.validateAndNormalizeConfig({
      ...this.config,
      ...newConfig
    });

    // 通知监听器
    this.notifyConfigChange();
  }

  /**
   * 添加配置变更监听器
   */
  onConfigChange(callback: (config: AppConfig) => void): () => void {
    this.configListeners.push(callback);
    
    // 返回取消监听的函数
    return () => {
      const index = this.configListeners.indexOf(callback);
      if (index > -1) {
        this.configListeners.splice(index, 1);
      }
    };
  }

  /**
   * 获取CDN健康检查配置
   */
  getCdnHealthCheckConfig(): { timeout: number; retryCount: number } {
    return {
      timeout: 5000,
      retryCount: 3
    };
  }

  /**
   * 获取重试配置
   */
  getRetryConfig(): { maxAttempts: number; baseDelay: number; maxDelay: number } {
    return {
      maxAttempts: this.config.voice.retry.maxAttempts,
      baseDelay: this.config.voice.retry.baseDelay,
      maxDelay: this.config.voice.retry.maxDelay
    };
  }

  /**
   * 获取会话配置
   */
  getSessionConfig(): { timeout: number; resumeEnabled: boolean; maxHistory: number } {
    return {
      timeout: this.config.voice.session.timeout,
      resumeEnabled: this.config.voice.session.resumeEnabled,
      maxHistory: 100 // 默认值
    };
  }

  /**
   * 获取音频配置
   */
  getAudioConfig(): { inputSampleRate: number; outputSampleRate: number; bufferSize: number } {
    return {
      inputSampleRate: this.config.audio.inputSampleRate,
      outputSampleRate: this.config.audio.outputSampleRate,
      bufferSize: this.config.audio.bufferSize
    };
  }

  // ==================== 私有方法 ====================

  /**
   * 验证和标准化配置
   */
  private validateAndNormalizeConfig(config: AppConfig): AppConfig {
    const normalizedConfig: AppConfig = {
      ...config,
      voice: {
        ...config.voice,
        api: {
          ...config.voice.api,
          google: {
            ...config.voice.api.google,
            apiKeys: config.voice.api.google.apiKeys || [],
            models: {
              live: config.voice.api.google.models.live || 'gemini-2.5-flash-native-audio-preview-12-2025',
              text: config.voice.api.google.models.text || 'gemini-2.5-flash',
              fallback: config.voice.api.google.models.fallback || 'gemini-2.5-flash'
            },
            endpoints: {
              primary: config.voice.api.google.endpoints.primary || 'https://generativelanguage.googleapis.com',
              backup: config.voice.api.google.endpoints.backup || []
            }
          }
        },
        cdn: {
          google: config.voice.cdn.google || [
            'https://cdn.jsdelivr.net',
            'https://unpkg.com',
            'https://cdnjs.cloudflare.com'
          ],
          fallback: config.voice.cdn.fallback || [
            'https://cdn.bootcdn.net',
            'https://cdn.staticfile.org'
          ],
          local: config.voice.cdn.local || '/local-assets'
        },
        retry: {
          maxAttempts: config.voice.retry.maxAttempts || 3,
          baseDelay: config.voice.retry.baseDelay || 1000,
          maxDelay: config.voice.retry.maxDelay || 10000
        },
        session: {
          timeout: config.voice.session.timeout || 900000, // 15分钟
          resumeEnabled: config.voice.session.resumeEnabled !== false // 默认启用
        }
      },
      network: {
        timeout: config.network.timeout || 30000,
        retryConfig: {
          maxAttempts: config.network.retryConfig.maxAttempts || 3,
          baseDelay: config.network.retryConfig.baseDelay || 1000,
          maxDelay: config.network.retryConfig.maxDelay || 10000,
          backoffMultiplier: config.network.retryConfig.backoffMultiplier || 2
        },
        endpoints: {
          primary: config.network.endpoints.primary || 'https://generativelanguage.googleapis.com',
          backup: config.network.endpoints.backup || []
        }
      },
      session: {
        timeout: config.session.timeout || 900000,
        resumeEnabled: config.session.resumeEnabled !== false,
        maxHistory: config.session.maxHistory || 100
      },
      audio: {
        inputSampleRate: config.audio.inputSampleRate || 16000,
        outputSampleRate: config.audio.outputSampleRate || 24000,
        bufferSize: config.audio.bufferSize || 4096
      }
    };

    // 验证必需的配置
    this.validateConfig(normalizedConfig);

    return normalizedConfig;
  }

  /**
   * 验证配置
   */
  private validateConfig(config: AppConfig): void {
    const errors: string[] = [];

    // 验证API密钥
    if (!config.voice.api.google.apiKeys || config.voice.api.google.apiKeys.length === 0) {
      errors.push('Google API keys are required');
    }

    // 验证模型配置
    if (!config.voice.api.google.models.live) {
      errors.push('Live model configuration is required');
    }

    // 验证CDN配置
    if (!config.voice.cdn.google || config.voice.cdn.google.length === 0) {
      errors.push('CDN configuration is required');
    }

    // 验证重试配置
    if (config.voice.retry.maxAttempts < 1) {
      errors.push('Retry maxAttempts must be greater than 0');
    }

    if (config.voice.retry.baseDelay < 100) {
      errors.push('Retry baseDelay must be at least 100ms');
    }

    if (errors.length > 0) {
      throw new Error(`Configuration validation failed: ${errors.join(', ')}`);
    }
  }

  /**
   * 通知配置变更
   */
  private notifyConfigChange(): void {
    const configCopy = this.getConfig();
    this.configListeners.forEach(listener => {
      try {
        listener(configCopy);
      } catch (error) {
        console.error('Error in config change listener:', error);
      }
    });
  }
}

/**
 * 创建默认配置
 */
export function createDefaultConfig(): AppConfig {
  return {
    voice: {
      api: {
        google: {
          apiKeys: [], // 需要在运行时设置
          models: {
            live: 'gemini-2.5-flash-native-audio-preview-12-2025',
            text: 'gemini-2.5-flash',
            fallback: 'gemini-2.5-flash'
          },
          endpoints: {
            primary: 'https://generativelanguage.googleapis.com',
            backup: []
          }
        }
      },
      cdn: {
        google: [
          'https://cdn.jsdelivr.net',
          'https://unpkg.com',
          'https://cdnjs.cloudflare.com'
        ],
        fallback: [
          'https://cdn.bootcdn.net',
          'https://cdn.staticfile.org'
        ],
        local: '/local-assets'
      },
      retry: {
        maxAttempts: 3,
        baseDelay: 1000,
        maxDelay: 10000
      },
      session: {
        timeout: 900000, // 15分钟
        resumeEnabled: true
      }
    },
    network: {
      timeout: 30000,
      retryConfig: {
        maxAttempts: 3,
        baseDelay: 1000,
        maxDelay: 10000,
        backoffMultiplier: 2
      },
      endpoints: {
        primary: 'https://generativelanguage.googleapis.com',
        backup: []
      }
    },
    session: {
      timeout: 900000,
      resumeEnabled: true,
      maxHistory: 100
    },
    audio: {
      inputSampleRate: 16000,
      outputSampleRate: 24000,
      bufferSize: 4096
    }
  };
}