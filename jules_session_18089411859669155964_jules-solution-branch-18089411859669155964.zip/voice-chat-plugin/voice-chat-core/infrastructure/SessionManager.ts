import { SessionState, SessionConfig, ChatMessage, LogEntry, Metrics } from '../types';

/**
 * 会话管理器 - 负责语音会话的生命周期管理
 * 
 * 职责：
 * 1. 会话的创建和销毁
 * 2. 会话历史的管理
 * 3. 会话超时检测
 * 4. 会话状态持久化
 */
export class SessionManager {
  private sessions: Map<string, SessionState> = new Map();
  private config: SessionConfig;
  private timeoutTimer: any = null;
  
  private logCallback?: (entry: LogEntry) => void;
  private metricsCallback?: (metrics: Metrics) => void;

  constructor(config: SessionConfig) {
    this.config = config;
    this.startTimeoutCheck();
  }

  /**
   * 创建新会话
   */
  async createSession(metadata: Record<string, any> = {}): Promise<SessionState> {
    const sessionId = this.generateSessionId();
    
    const session: SessionState = {
      id: sessionId,
      isActive: true,
      startTime: Date.now(),
      lastActivity: Date.now(),
      history: [],
      metadata: {
        ...metadata,
        createdAt: new Date().toISOString()
      }
    };
    
    this.sessions.set(sessionId, session);
    
    this.logInfo('Session created', { sessionId, metadata });
    this.updateMetrics('session_created', 1);
    
    return session;
  }

  /**
   * 获取会话
   */
  getSession(sessionId: string): SessionState | null {
    const session = this.sessions.get(sessionId);
    if (!session) {
      return null;
    }
    
    // 检查会话是否过期
    if (this.isSessionExpired(session)) {
      this.endSession(sessionId);
      return null;
    }
    
    return session;
  }

  /**
   * 更新会话活动时间
   */
  updateActivity(sessionId: string): void {
    const session = this.sessions.get(sessionId);
    if (session) {
      session.lastActivity = Date.now();
    }
  }

  /**
   * 结束会话
   */
  async endSession(sessionId: string): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (!session) {
      return;
    }
    
    session.isActive = false;
    session.endTime = Date.now();
    
    // 如果启用持久化，保存会话历史
    if (this.config.resumeEnabled) {
      await this.persistSession(session);
    }
    
    this.sessions.delete(sessionId);
    
    this.logInfo('Session ended', { 
      sessionId, 
      duration: session.endTime - session.startTime 
    });
    this.updateMetrics('session_ended', 1);
  }

  /**
   * 添加消息到会话历史
   */
  async addMessage(sessionId: string, message: Omit<ChatMessage, 'id'>): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (!session) {
      throw new Error('Session not found');
    }
    
    const fullMessage: ChatMessage = {
      ...message,
      id: this.generateMessageId()
    };
    
    session.history.push(fullMessage);
    
    // 限制历史记录数量
    if (session.history.length > this.config.maxHistory) {
      session.history.splice(0, session.history.length - this.config.maxHistory);
    }
    
    // 更新活动时间
    session.lastActivity = Date.now();
    
    this.logInfo('Message added to session', { 
      sessionId, 
      messageId: fullMessage.id,
      role: message.role,
      type: message.type 
    });
    this.updateMetrics('message_added', 1);
  }

  /**
   * 获取会话历史
   */
  getHistory(sessionId: string): ChatMessage[] {
    const session = this.sessions.get(sessionId);
    if (!session) {
      return [];
    }
    
    return [...session.history];
  }

  /**
   * 清空会话历史
   */
  clearHistory(sessionId: string): void {
    const session = this.sessions.get(sessionId);
    if (session) {
      session.history = [];
      this.logInfo('Session history cleared', { sessionId });
      this.updateMetrics('history_cleared', 1);
    }
  }

  /**
   * 恢复会话
   */
  async resumeSession(sessionId: string): Promise<SessionState | null> {
    // 首先检查内存中的会话
    let session = this.sessions.get(sessionId);
    
    if (session && !this.isSessionExpired(session)) {
      session.isActive = true;
      session.lastActivity = Date.now();
      return session;
    }
    
    // 如果启用恢复且内存中没有，尝试从持久化存储中恢复
    if (this.config.resumeEnabled) {
      const persistedSession = await this.loadPersistedSession(sessionId);
      if (persistedSession && !this.isSessionExpired(persistedSession)) {
        this.sessions.set(sessionId, persistedSession);
        persistedSession.isActive = true;
        persistedSession.lastActivity = Date.now();
        return persistedSession;
      }
    }
    
    return null;
  }

  /**
   * 获取所有活跃会话
   */
  getActiveSessions(): SessionState[] {
    const sessions: SessionState[] = [];
    
    for (const session of this.sessions.values()) {
      if (session.isActive && !this.isSessionExpired(session)) {
        sessions.push(session);
      }
    }
    
    return sessions;
  }

  /**
   * 清理过期会话
   */
  cleanupExpiredSessions(): void {
    const now = Date.now();
    const expiredSessions: string[] = [];
    
    for (const [sessionId, session] of this.sessions.entries()) {
      if (this.isSessionExpired(session)) {
        expiredSessions.push(sessionId);
      }
    }
    
    expiredSessions.forEach(sessionId => {
      this.endSession(sessionId);
    });
    
    if (expiredSessions.length > 0) {
      this.logInfo('Expired sessions cleaned up', { count: expiredSessions.length });
      this.updateMetrics('expired_sessions_cleaned', expiredSessions.length);
    }
  }

  /**
   * 设置日志回调
   */
  setLogCallback(callback: (entry: LogEntry) => void): void {
    this.logCallback = callback;
  }

  /**
   * 设置指标回调
   */
  setMetricsCallback(callback: (metrics: Metrics) => void): void {
    this.metricsCallback = callback;
  }

  /**
   * 清理资源
   */
  cleanup(): void {
    if (this.timeoutTimer) {
      clearInterval(this.timeoutTimer);
      this.timeoutTimer = null;
    }
    
    // 结束所有会话
    for (const sessionId of this.sessions.keys()) {
      this.endSession(sessionId);
    }
  }

  // ==================== 私有方法 ====================

  /**
   * 启动超时检查
   */
  private startTimeoutCheck(): void {
    this.timeoutTimer = setInterval(() => {
      this.cleanupExpiredSessions();
    }, this.config.timeout / 10); // 每10秒检查一次
  }

  /**
   * 检查会话是否过期
   */
  private isSessionExpired(session: SessionState): boolean {
    const now = Date.now();
    const timeSinceLastActivity = now - session.lastActivity;
    
    return timeSinceLastActivity > this.config.timeout;
  }

  /**
   * 生成会话ID
   */
  private generateSessionId(): string {
    return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * 生成消息ID
   */
  private generateMessageId(): string {
    return `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * 持久化会话
   */
  private async persistSession(session: SessionState): Promise<void> {
    try {
      const key = `session_${session.id}`;
      const data = {
        ...session,
        history: session.history.slice(-50) // 只保存最近50条消息
      };
      
      localStorage.setItem(key, JSON.stringify(data));
      
      this.logInfo('Session persisted', { sessionId: session.id });
    } catch (error) {
      this.logError(error as Error, 'SessionManager.persistSession');
    }
  }

  /**
   * 加载持久化会话
   */
  private async loadPersistedSession(sessionId: string): Promise<SessionState | null> {
    try {
      const key = `session_${sessionId}`;
      const data = localStorage.getItem(key);
      
      if (!data) {
        return null;
      }
      
      const session = JSON.parse(data) as SessionState;
      
      this.logInfo('Session loaded from persistence', { sessionId });
      return session;
    } catch (error) {
      this.logError(error as Error, 'SessionManager.loadPersistedSession');
      return null;
    }
  }

  /**
   * 记录信息日志
   */
  private logInfo(message: string, metadata?: any): void {
    const logEntry: LogEntry = {
      level: 'info',
      message,
      timestamp: Date.now(),
      metadata
    };
    
    this.logCallback?.(logEntry);
  }

  /**
   * 记录错误日志
   */
  private logError(error: Error, context: string): void {
    const logEntry: LogEntry = {
      level: 'error',
      message: error.message,
      timestamp: Date.now(),
      metadata: {
        context,
        stack: error.stack
      }
    };
    
    this.logCallback?.(logEntry);
  }

  /**
   * 更新指标
   */
  private updateMetrics(name: string, value: number): void {
    const metrics: Metrics = {
      name: `session.${name}`,
      value,
      timestamp: Date.now()
    };
    
    this.metricsCallback?.(metrics);
  }
}