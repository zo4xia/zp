
import React, { useState, useEffect, useRef } from 'react';
import { LiveService } from './services/liveService';
import { AgentState, ChatMessage, ILiveService } from './types';
import { GoogleGenAI } from '@google/genai';
import { CONFIG, getNextApiKey } from './config';
import { Dashboard } from './components/app/Dashboard';
import { ProfilePage } from './components/app/ProfilePage';
import { MediaPage } from './components/app/MediaPage';
import { MapPage } from './components/app/MapPage';
import { DetailPage } from './components/app/DetailPage';
import { InteractionCapsule } from './components/app/InteractionCapsule';
import { ToastNotification } from './components/app/ToastNotification';
import { TextInputOverlay } from './components/app/TextInputOverlay';
import { HistoryOverlay } from './components/app/HistoryOverlay';

const App: React.FC = () => {
    const [isCallActive, setIsCallActive] = useState(false);
    const [isConnecting, setIsConnecting] = useState(false);
    const [isCheckingMic, setIsCheckingMic] = useState(false);
    const [agentState, setAgentState] = useState<AgentState>(AgentState.IDLE);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [toastMessage, setToastMessage] = useState<string | null>(null);

    // Route Switching State (Standard vs Latest)
    const [currentRoute, setCurrentRoute] = useState<'standard' | 'latest'>('standard');

    // Navigation States
    const [currentView, setCurrentView] = useState<'dashboard' | 'map' | 'detail' | 'media' | 'profile'>('dashboard');
    const [activeCategory, setActiveCategory] = useState<'red' | 'nature' | 'people'>('red');
    const [selectedSpot, setSelectedSpot] = useState<any | null>(null);
    const [detailSpot, setDetailSpot] = useState<any | null>(null);

    // UI States
    const [showHistory, setShowHistory] = useState(false);
    const [inputMode, setInputMode] = useState<'none' | 'text'>('none');
    const [inputText, setInputText] = useState('');

    // Draggable States
    const [avatarPos, setAvatarPos] = useState<{ x: number, y: number } | null>(null);
    const [controlsPos, setControlsPos] = useState<{ x: number, y: number } | null>(null);

    const activeDrag = useRef<'avatar' | 'controls' | null>(null);
    const dragOffset = useRef({ x: 0, y: 0 });

    // Refs for audio handling
    const liveService = useRef<ILiveService | null>(null);
    const audioContext = useRef<AudioContext | null>(null);
    const nextStartTime = useRef<number>(0);
    const chatEndRef = useRef<HTMLDivElement>(null);

    // Ref for Text Chat Fallback
    const textChatClient = useRef<any | null>(null);

    // Scroll chat to bottom
    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, showHistory]);

    // Toast Timer
    useEffect(() => {
        if (toastMessage) {
            const timer = setTimeout(() => setToastMessage(null), 3000);
            return () => clearTimeout(timer);
        }
    }, [toastMessage]);

    // Dragging Logic
    const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>, item: 'avatar' | 'controls') => {
        e.preventDefault();

        const element = e.currentTarget;
        const rect = element.getBoundingClientRect();

        activeDrag.current = item;
        dragOffset.current = {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
        };

        if (item === 'avatar' && !avatarPos) {
            setAvatarPos({ x: rect.left, y: rect.top });
        } else if (item === 'controls' && !controlsPos) {
            setControlsPos({ x: rect.left, y: rect.top });
        }
    };

    useEffect(() => {
        const handleGlobalPointerMove = (e: PointerEvent) => {
            if (!activeDrag.current) return;
            e.preventDefault();

            const newX = e.clientX - dragOffset.current.x;
            const newY = e.clientY - dragOffset.current.y;

            if (activeDrag.current === 'avatar') {
                setAvatarPos({ x: newX, y: newY });
            } else if (activeDrag.current === 'controls') {
                setControlsPos({ x: newX, y: newY });
            }
        };

        const handleGlobalPointerUp = () => {
            activeDrag.current = null;
        };

        window.addEventListener('pointermove', handleGlobalPointerMove);
        window.addEventListener('pointerup', handleGlobalPointerUp);

        return () => {
            window.removeEventListener('pointermove', handleGlobalPointerMove);
            window.removeEventListener('pointerup', handleGlobalPointerUp);
        };
    }, [avatarPos, controlsPos]);

    // --- Voice Logic ---

    const checkMicrophone = async (): Promise<boolean> => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            stream.getTracks().forEach(track => track.stop());
            return true;
        } catch (e) {
            return false;
        }
    };

    const handleVoiceButtonClick = async () => {
        if (isCallActive) {
            endCall();
            return;
        }

        if (isConnecting || isCheckingMic) return;

        setIsCheckingMic(true);
        await new Promise(resolve => setTimeout(resolve, 1500));

        const hasMic = await checkMicrophone();
        setIsCheckingMic(false);

        if (hasMic) {
            await startCall();
        } else {
            setToastMessage("麦克风不可用，已为您切换到文字模式 ⌨️");
            setInputMode('text');
            setAgentState(AgentState.IDLE);
        }
    };

    const startCall = async () => {
        setIsConnecting(true);

        try {
            // Always create a fresh instance with a (potentially rotated) key
            // Switch Logic: Instantiate the correct service based on currentRoute
            const modelId = currentRoute === 'standard' ? CONFIG.MODELS.LIVE : CONFIG.MODELS.LIVE_LATEST;
            liveService.current = new LiveService(modelId);

            // Create and resume a dummy context to unlock audio autoplay
            audioContext.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            await audioContext.current.resume();

            await liveService.current.connect({
                onOpen: () => {
                    setIsConnecting(false);
                    setIsCallActive(true);
                    setAgentState(AgentState.LISTENING);
                    addMessage('model', '哇！终于见到你啦！我是东里村的小萌，今天想去哪里玩呀？✨');
                    setToastMessage("小萌听得到哦，快说话吧！🎤");
                },
                onClose: () => {
                    setAgentState(AgentState.IDLE);
                    setIsCallActive(false);
                    setIsConnecting(false);
                },
                onError: (err) => {
                    console.error(err);
                    setIsCallActive(false);
                    setAgentState(AgentState.IDLE);
                    setIsConnecting(false);

                    if (err.message.includes("Microphone") || err.message.includes("denied")) {
                        setToastMessage("麦克风连接中断，切换文字模式");
                        setInputMode('text');
                    } else {
                        setToastMessage("连接中断，请检查网络或重试");
                    }
                },
                onTranscription: (role, text) => {
                    setMessages(prev => {
                        const lastMsg = prev[prev.length - 1];
                        if (lastMsg && lastMsg.role === role && Date.now() - lastMsg.timestamp < 3000) {
                            return [...prev.slice(0, -1), { ...lastMsg, text: lastMsg.text + " " + text }];
                        }
                        return [...prev, { id: Date.now().toString(), role, text, timestamp: Date.now() }];
                    });

                    if (role === 'user') {
                        setAgentState(AgentState.THINKING);
                    } else {
                        setAgentState(AgentState.SPEAKING);
                    }
                },
                onAudioData: (buffer) => {
                    if (!audioContext.current) return;

                    setAgentState(AgentState.SPEAKING);

                    const src = audioContext.current.createBufferSource();
                    src.buffer = buffer;
                    src.connect(audioContext.current.destination);

                    const currentTime = audioContext.current.currentTime;
                    if (nextStartTime.current < currentTime) {
                        nextStartTime.current = currentTime;
                    }
                    src.start(nextStartTime.current);
                    nextStartTime.current += buffer.duration;

                    src.onended = () => {
                        if (audioContext.current && audioContext.current.currentTime >= nextStartTime.current - 0.2) {
                            setAgentState(AgentState.LISTENING);
                        }
                    };
                }
            });
        } catch (e) {
            console.error("Connection failed", e);
            setIsConnecting(false);
            setToastMessage("连接失败，正在重试...");
        }
    };

    const endCall = () => {
        if (liveService.current) {
            liveService.current.disconnect();
        }
        setIsCallActive(false);
        setIsConnecting(false);
        setAgentState(AgentState.IDLE);
    };

    const addMessage = (role: 'user' | 'model', text: string) => {
        setMessages(prev => [...prev, { id: Date.now().toString(), role, text, timestamp: Date.now() }]);
    };

    // --- Text Chat Logic (Downgrade Fallback) ---
    const handleSendText = async (e: React.FormEvent) => {
        e.preventDefault();
        const text = inputText.trim();
        if (!text) return;

        setInputText('');
        setInputMode('none');
        setShowHistory(true);
        addMessage('user', text);
        setAgentState(AgentState.THINKING);

        if (isCallActive) {
            endCall();
        }

        try {
            const apiKey = getNextApiKey();
            if (!apiKey) throw new Error("No API Key");

            // Always create new client to ensure key rotation if needed
            const options: any = { apiKey: apiKey };
            if (CONFIG.API_BASE_URL) {
                options.baseUrl = CONFIG.API_BASE_URL;
            }

            const ai = new GoogleGenAI(options);
            textChatClient.current = ai.chats.create({
                model: CONFIG.MODELS.TEXT,
                config: {
                    systemInstruction: CONFIG.SYSTEM_INSTRUCTION,
                }
            });


            const result = await textChatClient.current.sendMessage({ message: text });
            const responseText = result.text;

            addMessage('model', responseText);
            setAgentState(AgentState.IDLE);

        } catch (error) {
            console.error("Text chat failed", error);
            addMessage('model', '呜呜，小萌网路有点卡，再说一次好不好？');
            setAgentState(AgentState.IDLE);
        }
    };

    const handleCategoryClick = (category: 'red' | 'nature' | 'people') => {
        setActiveCategory(category);
        setCurrentView('map');
        setSelectedSpot(null); // Reset selection
    };

    const navigateToDetail = (spot: any) => {
        setDetailSpot(spot);
        setCurrentView('detail');
    };

    const renderContent = () => {
        switch (currentView) {
            case 'dashboard':
                return <Dashboard
                    handleCategoryClick={handleCategoryClick}
                    setCurrentView={setCurrentView}
                    currentRoute={currentRoute}
                    setCurrentRoute={setCurrentRoute}
                    isCallActive={isCallActive}
                    setToastMessage={setToastMessage}
                />;
            case 'map':
                return <MapPage
                    setCurrentView={setCurrentView}
                    activeCategory={activeCategory}
                    setActiveCategory={setActiveCategory}
                    selectedSpot={selectedSpot}
                    setSelectedSpot={setSelectedSpot}
                    navigateToDetail={navigateToDetail}
                />;
            case 'media':
                return <MediaPage setCurrentView={setCurrentView} />;
            case 'profile':
                return <ProfilePage setCurrentView={setCurrentView} />;
            case 'detail':
                return <DetailPage
                    setCurrentView={setCurrentView}
                    activeCategory={activeCategory}
                    detailSpot={detailSpot}
                />;
            default:
                return null;
        }
    }

    return (
        <div className="h-screen w-full max-w-[980px] mx-auto bg-[#f4f6f8] text-gray-800 relative overflow-hidden flex flex-col font-sans select-none shadow-2xl">

            {/* Background Texture */}
            <div className="absolute inset-0 pointer-events-none opacity-[0.02] z-0 flex items-center justify-center">
                <span className="text-8xl font-black rotate-[-15deg]">非商用使用</span>
            </div>

            {/* Main Content View Switcher */}
            {renderContent()}

            <InteractionCapsule
                handlePointerDown={handlePointerDown}
                avatarPos={avatarPos}
                controlsPos={controlsPos}
                agentState={agentState}
                isCheckingMic={isCheckingMic}
                isCallActive={isCallActive}
                isConnecting={isConnecting}
                handleVoiceButtonClick={handleVoiceButtonClick}
                setInputMode={setInputMode}
            />

            <ToastNotification toastMessage={toastMessage} />

            {inputMode === 'text' && (
                <TextInputOverlay
                    inputText={inputText}
                    setInputText={setInputText}
                    handleSendText={handleSendText}
                    setInputMode={setInputMode}
                />
            )}

            {showHistory && (
                <HistoryOverlay
                    messages={messages}
                    setShowHistory={setShowHistory}
                    chatEndRef={chatEndRef}
                />
            )}

            <style>{`
                @keyframes slide-left {
                    from { transform: translateX(100%); }
                    to { transform: translateX(0); }
                }
                .animate-slide-left {
                    animation: slide-left 0.3s cubic-bezier(0.16, 1, 0.3, 1);
                }
                @keyframes bounce-short {
                    0%, 100% { transform: translate(-50%, -50%); }
                    50% { transform: translate(-50%, -65%); }
                }
                .animate-bounce-short {
                    animation: bounce-short 1s infinite;
                }
                @keyframes bounce-slow {
                    0%, 100% { transform: translate(-50%, 0); }
                    50% { transform: translate(-50%, -5px); }
                }
                .animate-bounce-slow {
                    animation: bounce-slow 2s infinite;
                }
                @keyframes progress {
                    from { width: 0%; }
                    to { width: 100%; }
                }
                .animate-progress {
                    animation: progress 1.5s ease-out forwards;
                }
                /* Hide scrollbar for Chrome, Safari and Opera */
                .scrollbar-hide::-webkit-scrollbar {
                    display: none;
                }
                /* Hide scrollbar for IE, Edge and Firefox */
                .scrollbar-hide {
                    -ms-overflow-style: none;  /* IE and Edge */
                    scrollbar-width: none;  /* Firefox */
                }
            `}</style>
        </div>
    );
};

export default App;
