
import React from 'react';

interface ToastNotificationProps {
    toastMessage: string | null;
}

export const ToastNotification: React.FC<ToastNotificationProps> = ({ toastMessage }) => {
    if (!toastMessage) return null;

    return (
        <div className="absolute top-20 left-1/2 transform -translate-x-1/2 z-[80] bg-black/70 backdrop-blur-md text-white px-6 py-3 rounded-full shadow-xl animate-slide-up flex items-center gap-2">
            <i className="fas fa-info-circle text-yellow-400"></i>
            <span className="font-bold text-sm tracking-wide">{toastMessage}</span>
        </div>
    );
};
