
import React from 'react';
import AgentAvatar from '../AgentAvatar';
import { AgentState } from '../../types';

interface InteractionCapsuleProps {
    handlePointerDown: (e: React.PointerEvent<HTMLDivElement>, item: 'avatar' | 'controls') => void;
    avatarPos: { x: number; y: number } | null;
    controlsPos: { x: number; y: number } | null;
    agentState: AgentState;
    isCheckingMic: boolean;
    isCallActive: boolean;
    isConnecting: boolean;
    handleVoiceButtonClick: () => void;
    setInputMode: (mode: 'none' | 'text') => void;
}

export const InteractionCapsule: React.FC<InteractionCapsuleProps> = ({
    handlePointerDown,
    avatarPos,
    controlsPos,
    agentState,
    isCheckingMic,
    isCallActive,
    isConnecting,
    handleVoiceButtonClick,
    setInputMode,
}) => {
    return (
        <>
            {/* --- Character (Draggable) --- */}
            <div
                onPointerDown={(e) => handlePointerDown(e, 'avatar')}
                className={`z-50 w-48 h-48 md:w-64 md:h-64 touch-none cursor-move transition-transform active:scale-105 ${!avatarPos ? 'absolute bottom-8 -left-4' : 'fixed'}`}
                style={avatarPos ? { left: avatarPos.x, top: avatarPos.y } : undefined}
            >
                <AgentAvatar state={agentState} volume={0.5} />
            </div>

            {/* --- Interaction Capsule (Draggable & "Backlit") --- */}
            <div
                onPointerDown={(e) => handlePointerDown(e, 'controls')}
                className={`z-50 touch-none cursor-move active:scale-105 transition-transform ${!controlsPos ? 'absolute bottom-10 left-1/2 -translate-x-1/2' : 'fixed'}`}
                style={controlsPos ? { left: controlsPos.x, top: controlsPos.y } : undefined}
            >
                {/* Mic Check Bar - New Feature */}
                {isCheckingMic && (
                    <div className="absolute bottom-24 left-1/2 -translate-x-1/2 w-48 bg-black/60 backdrop-blur-md rounded-full p-1 border border-white/20 animate-fade-in z-50">
                        <div className="flex items-center gap-2 px-2 mb-1">
                            <i className="fas fa-wave-square text-blue-400 text-xs"></i>
                            <span className="text-[10px] text-white font-bold">正在检测通话环境...</span>
                        </div>
                        <div className="h-1 bg-gray-600 rounded-full overflow-hidden mx-2 mb-1">
                            <div className="h-full bg-blue-400 animate-progress w-full origin-left"></div>
                        </div>
                    </div>
                )}

                {/* Call Status Hint Bubble - Enhanced */}
                {isCallActive && (
                    <div className="absolute bottom-24 left-1/2 -translate-x-1/2 bg-rose-500 text-white text-xs px-4 py-2 rounded-2xl shadow-lg border border-white/20 animate-bounce-slow z-50 flex items-center gap-2 whitespace-nowrap">
                        <div className="w-2 h-2 bg-white rounded-full animate-ping"></div>
                        <span className="font-bold">已接通！直接说话即可，点击挂断</span>
                        <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-px w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[6px] border-t-rose-500"></div>
                    </div>
                )}

                <div className="flex items-center bg-black/60 backdrop-blur-xl rounded-full p-1.5 pl-6 shadow-[0_0_20px_rgba(255,255,255,0.2)] gap-4 pointer-events-none ring-1 ring-white/30 border border-white/10">
                    <div className="flex flex-col leading-none pointer-events-auto cursor-pointer group" onClick={() => setInputMode('text')}>
                        <span className="text-white font-bold text-lg drop-shadow-md group-hover:text-blue-200 transition-colors">键盘</span>
                        <span className="text-[10px] text-gray-300 transform scale-90 origin-left">可以拖动</span>
                    </div>

                    <button
                        onClick={handleVoiceButtonClick}
                        className={`h-12 px-6 rounded-full font-bold flex items-center gap-2 transition-all pointer-events-auto shadow-lg shadow-white/10 ${isCallActive
                            ? 'bg-rose-500 text-white animate-pulse'
                            : (isConnecting || isCheckingMic)
                                ? 'bg-gray-100 text-gray-500 cursor-wait'
                                : 'bg-white text-cyan-600 hover:bg-gray-50'
                            }`}
                    >
                        {isCallActive ? (
                            <>
                                <i className="fas fa-phone-slash"></i>
                                <span className="text-lg">挂断</span>
                            </>
                        ) : (isConnecting || isCheckingMic) ? (
                            <>
                                <i className="fas fa-circle-notch fa-spin"></i>
                                <span className="text-sm">{isCheckingMic ? '环境检测' : '连接中...'}</span>
                            </>
                        ) : (
                            <>
                                <i className="fas fa-microphone"></i>
                                <span className="text-lg">语音畅聊</span>
                            </>
                        )}
                    </button>
                </div>
            </div>
        </>
    );
};
