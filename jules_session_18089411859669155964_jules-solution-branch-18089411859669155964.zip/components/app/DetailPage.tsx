
import React from 'react';
import { SPOT_DATA } from '../../constants';
import { WeatherWidget } from './WeatherWidget';

interface DetailPageProps {
    setCurrentView: (view: 'dashboard' | 'map' | 'detail' | 'media' | 'profile') => void;
    activeCategory: 'red' | 'nature' | 'people';
    detailSpot: any;
}

export const DetailPage: React.FC<DetailPageProps> = ({ setCurrentView, activeCategory, detailSpot }) => {
    if (!detailSpot) return null;

    const categoryInfo = SPOT_DATA[activeCategory];
    const isPeopleGallery = activeCategory === 'people' && detailSpot.directory;

    return (
        <div className="flex flex-col h-full bg-[#f4f6f8] relative z-20 animate-fade-in">
            {/* New Header Design */}
            <div className="flex items-center justify-between px-6 pt-6 pb-2 bg-[#f4f6f8] z-30">
                <div className="flex items-center gap-3">
                    <button
                        onClick={() => setCurrentView('map')}
                        className="w-12 h-12 rounded-full bg-yellow-400 shadow-sm flex items-center justify-center text-gray-800 active:scale-95 transition border-2 border-white/50"
                    >
                        <i className="fas fa-arrow-left text-lg"></i>
                    </button>
                    <div className="flex flex-col">
                        <span className="font-black text-2xl text-gray-800 tracking-wide">{categoryInfo.title}</span>
                        <span className="text-xs text-gray-500 font-bold tracking-widest">{categoryInfo.subtitle}</span>
                    </div>
                </div>
                <WeatherWidget />
            </div>

            {/* Scrollable Content */}
            <div className="flex-1 overflow-y-auto px-4 pb-32 scrollbar-hide">

                {/* Image Card Container */}
                <div className="bg-white rounded-[2rem] shadow-sm mt-4 overflow-hidden border-2 border-blue-500/20 relative">
                    {/* Image Area */}
                    <div className="relative aspect-[16/10] bg-gray-200">
                        <img src={detailSpot.detailImage} alt={detailSpot.name} className="w-full h-full object-cover" />

                        {/* Green Title Bar Overlay */}
                        <div className="absolute bottom-0 left-0 right-0 bg-[#86efac] py-2 px-4">
                            <span className="font-bold text-gray-800 text-lg">{detailSpot.name}</span>
                        </div>
                    </div>

                    {/* Description */}
                    <div className="p-5 pt-6">
                        <p className="text-gray-600 text-sm leading-relaxed tracking-wide text-justify line-clamp-3">
                            {detailSpot.desc}
                        </p>
                    </div>

                    {/* Action Buttons Row */}
                    <div className="flex items-center justify-between px-5 pb-5 gap-3">
                        <button className="flex-1 bg-sky-200/80 py-4 rounded-2xl flex flex-col items-center justify-center gap-1 active:scale-95 transition hover:bg-sky-200">
                            <span className="text-sm font-bold text-sky-700">听导览</span>
                        </button>
                        <button className="flex-1 bg-orange-200/80 py-4 rounded-2xl flex flex-col items-center justify-center gap-1 active:scale-95 transition hover:bg-orange-200">
                            <div className="text-xs font-bold text-orange-700 text-center leading-tight">拍照<br />AI明信片</div>
                        </button>
                        <button className="flex-1 bg-rose-200/80 py-4 rounded-2xl flex flex-col items-center justify-center gap-1 active:scale-95 transition hover:bg-rose-200">
                            <span className="text-sm font-bold text-rose-700">点亮打卡</span>
                        </button>
                    </div>

                    {/* Directory List or Text Content */}
                    {isPeopleGallery ? (
                        <div className="px-5 pb-6">
                            <div className="flex items-center gap-2 mb-4">
                                <i className="fas fa-images text-purple-400"></i>
                                <span className="text-purple-500 font-bold">名人风采墙</span>
                            </div>

                            {/* Photo Wall Grid */}
                            <div className="grid grid-cols-2 gap-4">
                                {detailSpot.directory.map((item: any, idx: number) => (
                                    <div
                                        key={idx}
                                        className={`bg-white p-2 pb-8 shadow-lg border border-gray-100 transform transition-transform hover:scale-105 hover:z-10 relative
                                            ${idx % 2 === 0 ? 'rotate-1' : '-rotate-1'}
                                        `}
                                        style={{ borderRadius: '4px' }}
                                    >
                                        {/* "Tape" Effect */}
                                        <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-8 h-8 bg-yellow-100/80 transform -rotate-45 opacity-80 backdrop-blur-sm shadow-sm border border-white/40"></div>

                                        {/* Photo Frame */}
                                        <div className="aspect-square bg-gray-100 overflow-hidden mb-3 border border-gray-200 grayscale-[20%] hover:grayscale-0 transition-all">
                                            <img
                                                src={`https://picsum.photos/seed/${item.imageSeed || idx}/300/300`}
                                                alt={item.name}
                                                className="w-full h-full object-cover"
                                            />
                                        </div>

                                        {/* Handwriting Info */}
                                        <div className="text-center px-1">
                                            <h4 className="font-black text-gray-800 text-base mb-1">{item.name}</h4>
                                            {item.tag && (
                                                <span className="inline-block bg-purple-50 text-purple-600 text-[10px] px-2 py-0.5 rounded-full mb-2 font-bold">
                                                    {item.tag}
                                                </span>
                                            )}
                                            <p className="text-[10px] text-gray-500 leading-tight line-clamp-3 text-left">
                                                {item.desc}
                                            </p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    ) : detailSpot.directory ? (
                        <div className="mx-5 mb-6 space-y-3">
                            <div className="flex items-center gap-2 mb-2">
                                <i className="fas fa-list-ul text-blue-400"></i>
                                <span className="text-blue-500 font-bold">详情名录</span>
                            </div>
                            {detailSpot.directory.map((item: any, idx: number) => (
                                <div key={idx} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex flex-col">
                                    <div className="flex justify-between items-center mb-1">
                                        <span className="font-bold text-gray-800 text-lg">{item.name}</span>
                                        {item.tag && <span className="text-xs bg-blue-50 text-blue-500 px-2 py-0.5 rounded font-medium">{item.tag}</span>}
                                    </div>
                                    <p className="text-sm text-gray-600 leading-relaxed">{item.desc}</p>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="mx-5 mb-6 bg-blue-100/50 rounded-[2rem] min-h-[140px] flex items-center justify-center p-6 border border-blue-100">
                            <span className="text-blue-400 font-bold text-lg">景点文字内容</span>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
