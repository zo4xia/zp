
import React from 'react';
import { SPOT_DATA } from '../../constants';

interface MapPageProps {
    setCurrentView: (view: 'dashboard' | 'map' | 'detail' | 'media' | 'profile') => void;
    activeCategory: 'red' | 'nature' | 'people';
    setActiveCategory: (category: 'red' | 'nature' | 'people') => void;
    selectedSpot: any;
    setSelectedSpot: (spot: any) => void;
    navigateToDetail: (spot: any) => void;
}

export const MapPage: React.FC<MapPageProps> = ({
    setCurrentView,
    activeCategory,
    setActiveCategory,
    selectedSpot,
    setSelectedSpot,
    navigateToDetail,
}) => {
    const activeData = SPOT_DATA[activeCategory];

    const handleSpotClick = (spot: any) => {
        if (selectedSpot && selectedSpot.id === spot.id) {
            setSelectedSpot(null); // Toggle off
        } else {
            setSelectedSpot(spot);
        }
    };

    const openNavigation = (spotName: string) => {
        // Simulate opening a navigation app or a map search
        const url = `https://www.google.com/maps/search/?api=1&query=东里村 ${spotName}`;
        window.open(url, '_blank');
    };

    return (
        <div className="flex flex-col h-full bg-[#f4f6f8] relative z-20 animate-fade-in">
            {/* Map Header - Sticky & Blurred */}
            <div className="flex items-center justify-between px-6 pt-6 pb-4 bg-white/80 backdrop-blur-md z-30 sticky top-0 shadow-sm border-b border-gray-100/50">
                <button
                    onClick={() => setCurrentView('dashboard')}
                    className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center text-gray-600 active:scale-95 transition hover:bg-gray-50 border border-gray-100"
                >
                    <i className="fas fa-chevron-left"></i>
                </button>
                <span className="font-bold text-xl text-gray-700 tracking-wide">村落导览</span>
                <div className="w-10"></div> {/* Spacer */}
            </div>

            {/* Map Area */}
            <div className="relative h-72 mx-6 mt-4 mb-6 bg-[#e8e4d9] rounded-[2rem] shadow-inner border border-stone-200 overflow-visible shrink-0 select-none">
                {/* Decorative Map Elements (Abstract) */}
                <div className="absolute inset-0 rounded-[2rem] overflow-hidden">
                    <svg className="absolute inset-0 w-full h-full opacity-30 pointer-events-none" preserveAspectRatio="none">
                        <path d="M0,50 Q100,20 200,60 T400,40" stroke="#a8c5e6" strokeWidth="20" fill="none" />
                        <path d="M50,0 Q60,100 40,200" stroke="#dcd7c9" strokeWidth="15" fill="none" />
                    </svg>
                    <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(#a39e93 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
                </div>

                {/* Pins & Bubbles */}
                {Object.entries(SPOT_DATA).map(([catKey, data]) => (
                    data.spots.map(spot => {
                        const isSelected = selectedSpot && selectedSpot.id === spot.id;
                        return (
                            <div
                                key={spot.id}
                                className="absolute flex flex-col items-center transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300"
                                style={{ left: `${spot.x}%`, top: `${spot.y}%`, zIndex: isSelected ? 50 : (catKey === activeCategory ? 10 : 1) }}
                            >
                                {/* Popover Bubble */}
                                {isSelected && (
                                    <div className="absolute bottom-full mb-3 bg-white rounded-2xl shadow-xl p-4 w-48 flex flex-col items-center gap-3 animate-slide-up origin-bottom z-50">
                                        <div className="text-xs font-bold text-rose-500 bg-rose-50 px-3 py-1.5 rounded-lg w-full text-center truncate tracking-wide">
                                            {spot.promo || '热门打卡点'}
                                        </div>
                                        <div className="flex gap-2 w-full">
                                            <button
                                                onClick={(e) => { e.stopPropagation(); navigateToDetail(spot); }}
                                                className="flex-1 bg-blue-500 text-white text-xs py-2 rounded-xl active:scale-95 transition shadow-sm font-medium"
                                            >
                                                详情
                                            </button>
                                            <button
                                                onClick={(e) => { e.stopPropagation(); openNavigation(spot.name); }}
                                                className="flex-1 bg-green-500 text-white text-xs py-2 rounded-xl active:scale-95 transition shadow-sm font-medium"
                                            >
                                                导航
                                            </button>
                                        </div>
                                        {/* Triangle Arrow */}
                                        <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-px w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[8px] border-t-white filter drop-shadow-sm"></div>
                                    </div>
                                )}

                                {/* Marker Icon */}
                                <div
                                    onClick={() => handleSpotClick(spot)}
                                    className={`
                                        ${catKey === 'red' ? 'text-red-500' : catKey === 'people' ? 'text-purple-500' : 'text-emerald-500'} 
                                        filter drop-shadow-md cursor-pointer hover:scale-125 transition-transform
                                        ${catKey === activeCategory ? 'text-4xl animate-bounce-short' : 'text-2xl opacity-60'}
                                    `}
                                >
                                    <i className={`fas ${catKey === 'people' ? 'fa-user' : 'fa-map-marker-alt'}`}></i>
                                </div>
                                {catKey === activeCategory && !isSelected && (
                                    <span className="text-[10px] font-bold bg-white/90 px-2 py-0.5 rounded-md shadow-sm whitespace-nowrap mt-1 pointer-events-none tracking-wide text-gray-600">
                                        {spot.name}
                                    </span>
                                )}
                            </div>
                        );
                    })
                ))}
            </div>

            {/* Category Tabs */}
            <div className="bg-gray-200/60 p-1.5 mx-6 rounded-2xl flex shrink-0 mb-6 shadow-inner">
                <button
                    onClick={() => { setActiveCategory('red'); setSelectedSpot(null); }}
                    className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all tracking-wide ${activeCategory === 'red' ? 'bg-white shadow text-red-600' : 'text-gray-500 hover:text-gray-700'}`}
                >
                    红色之旅
                </button>
                <button
                    onClick={() => { setActiveCategory('nature'); setSelectedSpot(null); }}
                    className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all tracking-wide ${activeCategory === 'nature' ? 'bg-white shadow text-emerald-600' : 'text-gray-500 hover:text-gray-700'}`}
                >
                    自然风景
                </button>
                <button
                    onClick={() => { setActiveCategory('people'); setSelectedSpot(null); }}
                    className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all tracking-wide ${activeCategory === 'people' ? 'bg-white shadow text-purple-600' : 'text-gray-500 hover:text-gray-700'}`}
                >
                    东里名人
                </button>
            </div>

            {/* List Content */}
            <div className="flex-1 overflow-y-auto px-6 pb-32 space-y-4 scrollbar-hide">
                {activeData.spots.map(spot => (
                    <div
                        key={spot.id}
                        onClick={() => navigateToDetail(spot)}
                        className="bg-white p-5 rounded-3xl shadow-sm flex items-center gap-5 animate-slide-up cursor-pointer active:bg-gray-50 transition border border-gray-50 hover:border-gray-100"
                    >
                        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 ${activeData.lightBg} ${activeData.text}`}>
                            <i className={`fas ${activeCategory === 'red' ? 'fa-star' : activeCategory === 'people' ? 'fa-user-graduate' : 'fa-tree'} text-2xl`}></i>
                        </div>
                        <div className="flex-1">
                            <h4 className="font-bold text-gray-800 text-lg tracking-tight">{spot.name}</h4>
                            <p className="text-xs text-gray-500 mt-1 line-clamp-1 leading-relaxed tracking-wide">{spot.desc}</p>
                        </div>
                        <button className={`w-10 h-10 rounded-full border flex items-center justify-center ${activeData.text} border-current opacity-40`}>
                            <i className="fas fa-chevron-right text-sm"></i>
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};
