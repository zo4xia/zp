
import React from 'react';

interface ProfilePageProps {
    setCurrentView: (view: 'dashboard' | 'map' | 'detail' | 'media' | 'profile') => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ setCurrentView }) => {
    // Mock User Data for Demonstration
    const user = {
        uid: 'DL888666',
        nickname: '远方的客人',
        phone: '139****8888',
        joinDate: '2025年12月12日',
        footprints: 3,
        checkins: 1,
    };

    return (
        <div className="flex flex-col h-full bg-[#f4f6f8] relative z-20 animate-fade-in">
            {/* Header */}
            <div className="flex items-center justify-between px-6 pt-6 pb-4 bg-white/80 backdrop-blur-md z-30 sticky top-0 shadow-sm border-b border-gray-100/50">
                <button
                    onClick={() => setCurrentView('dashboard')}
                    className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center text-gray-600 active:scale-95 transition hover:bg-gray-50 border border-gray-100"
                >
                    <i className="fas fa-chevron-left"></i>
                </button>
                <span className="font-bold text-xl text-gray-700 tracking-wide">个人中心</span>
                <div className="w-10"></div>
            </div>

            <div className="flex-1 overflow-y-auto px-4 py-4 scrollbar-hide">
                {/* ID Card */}
                <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-[2rem] p-6 text-white shadow-lg shadow-blue-200 mb-6 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-8 opacity-10 transform translate-x-4 -translate-y-4">
                        <i className="fas fa-id-card text-9xl"></i>
                    </div>

                    <div className="flex items-center gap-4 relative z-10 mb-6">
                        <div className="w-20 h-20 rounded-full border-4 border-white/30 bg-white/20 flex items-center justify-center text-4xl shadow-inner">
                            🤠
                        </div>
                        <div>
                            <h2 className="text-2xl font-black tracking-wide">{user.nickname}</h2>
                            <div className="flex items-center gap-2 mt-1 opacity-80">
                                <span className="text-xs font-mono bg-black/20 px-2 py-0.5 rounded">UID: {user.uid}</span>
                            </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 relative z-10 text-sm">
                        <div className="bg-white/10 rounded-xl p-3 backdrop-blur-sm">
                            <span className="block opacity-60 text-xs mb-1">绑定号码</span>
                            <div className="font-mono font-bold">{user.phone}</div>
                        </div>
                        <div className="bg-white/10 rounded-xl p-3 backdrop-blur-sm">
                            <span className="block opacity-60 text-xs mb-1">初次见面</span>
                            <div className="font-bold">{user.joinDate}</div>
                        </div>
                    </div>
                </div>

                {/* Stats Row */}
                <div className="flex gap-3 mb-6">
                    <div className="flex-1 bg-white p-4 rounded-2xl shadow-sm border border-gray-50 flex flex-col items-center justify-center gap-1 active:scale-95 transition cursor-pointer">
                        <div className="w-10 h-10 rounded-full bg-orange-100 text-orange-500 flex items-center justify-center mb-1">
                            <i className="fas fa-shoe-prints"></i>
                        </div>
                        <span className="text-xs text-gray-400">我的足迹</span>
                        <span className="font-black text-xl text-gray-800">{user.footprints}</span>
                    </div>
                    <div className="flex-1 bg-white p-4 rounded-2xl shadow-sm border border-gray-50 flex flex-col items-center justify-center gap-1 active:scale-95 transition cursor-pointer">
                        <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-500 flex items-center justify-center mb-1">
                            <i className="fas fa-map-marked-alt"></i>
                        </div>
                        <span className="text-xs text-gray-400">打卡记录</span>
                        <span className="font-black text-xl text-gray-800">{user.checkins}</span>
                    </div>
                </div>

                {/* Menu List */}
                <div className="bg-white rounded-3xl shadow-sm border border-gray-50 overflow-hidden">
                    <div className="p-4 hover:bg-gray-50 transition cursor-pointer flex items-center gap-4 border-b border-gray-50">
                        <div className="w-10 h-10 rounded-full bg-green-100 text-green-600 flex items-center justify-center">
                            <i className="fas fa-utensils"></i>
                        </div>
                        <div className="flex-1">
                            <h3 className="font-bold text-gray-800">乡集·农家预定</h3>
                            <p className="text-xs text-gray-400">地道农家菜、特色民宿预定</p>
                        </div>
                        <i className="fas fa-chevron-right text-gray-300 text-sm"></i>
                    </div>
                    <div className="p-4 hover:bg-gray-50 transition cursor-pointer flex items-center gap-4 border-b border-gray-50">
                        <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center">
                            <i className="fas fa-shopping-basket"></i>
                        </div>
                        <div className="flex-1">
                            <h3 className="font-bold text-gray-800">东里好物</h3>
                            <p className="text-xs text-gray-400">黑米、芦柑、特色伴手礼</p>
                        </div>
                        <i className="fas fa-chevron-right text-gray-300 text-sm"></i>
                    </div>
                    <div className="p-4 hover:bg-gray-50 transition cursor-pointer flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center">
                            <i className="fas fa-address-book"></i>
                        </div>
                        <div className="flex-1">
                            <h3 className="font-bold text-gray-800">联系村委</h3>
                            <p className="text-xs text-gray-400">建议反馈、便民服务</p>
                        </div>
                        <i className="fas fa-chevron-right text-gray-300 text-sm"></i>
                    </div>
                </div>

                <div className="mt-8 text-center pb-8">
                    <button className="text-xs text-gray-400 underline decoration-gray-300">
                        切换账号 / 退出登录
                    </button>
                </div>
            </div>
        </div>
    );
};
