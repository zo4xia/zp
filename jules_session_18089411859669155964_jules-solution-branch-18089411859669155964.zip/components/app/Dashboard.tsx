
import React from 'react';
import { WeatherWidget } from './WeatherWidget';

interface DashboardProps {
    handleCategoryClick: (category: 'red' | 'nature' | 'people') => void;
    setCurrentView: (view: 'dashboard' | 'map' | 'detail' | 'media' | 'profile') => void;
    currentRoute: 'standard' | 'latest';
    setCurrentRoute: (route: 'standard' | 'latest') => void;
    isCallActive: boolean;
    setToastMessage: (message: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
    handleCategoryClick,
    setCurrentView,
    currentRoute,
    setCurrentRoute,
    isCallActive,
    setToastMessage,
}) => {
    return (
        <>
            {/* Header */}
            <div className="relative z-20 pt-4 px-6 flex justify-between items-center animate-fade-in">
                <div className="flex flex-col">
                    <h1 className="text-3xl font-black text-gray-700 tracking-tight leading-none">东里村</h1>
                    <div className="flex items-center gap-2 mt-1">
                        <h2 className="text-xs text-gray-400 font-medium tracking-wider">村官智能体 伴您游</h2>
                        {/* Route Switcher Toggle */}
                        <div
                            onClick={() => {
                                if (isCallActive) {
                                    setToastMessage("请先挂断当前通话");
                                    return;
                                }
                                const newRoute = currentRoute === 'standard' ? 'latest' : 'standard';
                                setCurrentRoute(newRoute);
                                setToastMessage(newRoute === 'standard' ? "已切换至：标准线路 (稳定)" : "已切换至：备用线路 (最新)");
                            }}
                            className={`
                                cursor-pointer px-2 py-0.5 rounded-full text-[10px] font-bold border transition-all flex items-center gap-1
                                ${currentRoute === 'standard'
                                    ? 'bg-green-50 text-green-600 border-green-200'
                                    : 'bg-purple-50 text-purple-600 border-purple-200'}
                            `}
                        >
                            <div className={`w-1.5 h-1.5 rounded-full ${currentRoute === 'standard' ? 'bg-green-500' : 'bg-purple-500'}`}></div>
                            {currentRoute === 'standard' ? '标准线' : '备用线'}
                        </div>
                    </div>
                </div>
                <WeatherWidget />
            </div>

            {/* Main Grid */}
            <div className="relative z-10 flex-1 pl-6 pr-0 py-3 grid grid-cols-[1fr_auto] gap-2 animate-slide-up">
                {/* Left Section: Cards */}
                <div className="grid grid-cols-2 gap-3 auto-rows-min pr-4">

                    {/* Village Intro */}
                    <div className="col-span-2 h-32 bg-gray-200 rounded-3xl relative overflow-hidden group cursor-pointer hover:bg-gray-300 transition-colors shadow-sm">
                        <div className="absolute inset-0 flex items-center justify-center">
                            <div className="w-16 h-12 bg-yellow-400 rounded-xl border-2 border-black flex items-center justify-center shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] group-hover:translate-y-1 group-hover:shadow-none transition-all">
                                <i className="fas fa-play text-xl"></i>
                            </div>
                        </div>
                        <span className="absolute left-6 top-6 text-xl font-bold text-gray-600">村子简介</span>
                    </div>

                    {/* Red Tour */}
                    <div
                        onClick={() => handleCategoryClick('red')}
                        className="h-40 bg-gray-300 rounded-3xl relative p-6 flex items-end hover:scale-[1.02] transition-transform cursor-pointer shadow-sm group overflow-hidden"
                    >
                        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                            <i className="fas fa-star text-6xl text-gray-600"></i>
                        </div>
                        <span className="text-lg font-medium text-gray-600">红色之旅</span>
                    </div>

                    {/* Nature Scenery */}
                    <div
                        onClick={() => handleCategoryClick('nature')}
                        className="h-40 bg-gray-300 rounded-3xl relative p-6 flex items-end hover:scale-[1.02] transition-transform cursor-pointer shadow-sm group overflow-hidden"
                    >
                        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                            <i className="fas fa-tree text-6xl text-gray-600"></i>
                        </div>
                        <span className="text-lg font-medium text-gray-600">自然风景</span>
                    </div>

                    {/* Celebrities */}
                    <div
                        onClick={() => handleCategoryClick('people')}
                        className="h-40 bg-gray-300 rounded-3xl relative p-6 flex items-end hover:scale-[1.02] transition-transform cursor-pointer shadow-sm group overflow-hidden"
                    >
                        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                            <i className="fas fa-user-graduate text-6xl text-gray-600"></i>
                        </div>
                        <span className="text-lg font-medium text-gray-600">东里名人</span>
                    </div>

                    {/* Video Self-media */}
                    <div
                        onClick={() => setCurrentView('media')}
                        className="h-40 bg-gray-300 rounded-3xl relative p-6 flex items-end hover:scale-[1.02] transition-transform cursor-pointer shadow-sm group overflow-hidden"
                    >
                        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                            <i className="fas fa-photo-video text-6xl text-gray-600"></i>
                        </div>
                        <span className="text-lg font-medium text-gray-600">视频自媒体</span>
                    </div>
                </div>

                {/* Right Section: Sidebar Buttons (Docked) */}
                <div className="flex flex-col items-end pt-2">
                    <div className="flex flex-col gap-5 bg-white/40 backdrop-blur-xl rounded-l-2xl py-4 pl-3 pr-2 border-l border-white/60 shadow-sm mr-0">
                        <button
                            onClick={() => setCurrentView('profile')}
                            className="flex flex-col items-center gap-1 group"
                        >
                            <div className="w-12 h-12 bg-gradient-to-b from-blue-400 to-blue-500 rounded-2xl shadow-lg shadow-blue-200 flex items-center justify-center text-white text-xl group-hover:scale-110 transition-transform">
                                <i className="fas fa-user"></i>
                            </div>
                            <span className="text-[10px] font-bold text-gray-600">我的</span>
                        </button>
                        <button
                            onClick={() => setToastMessage("打卡功能开发中 🚧")}
                            className="flex flex-col items-center gap-1 group"
                        >
                            <div className="w-12 h-12 bg-gradient-to-b from-blue-400 to-blue-500 rounded-2xl shadow-lg shadow-blue-200 flex items-center justify-center text-white text-xl group-hover:scale-110 transition-transform">
                                <i className="fas fa-map-marker-alt"></i>
                            </div>
                            <span className="text-[10px] font-bold text-gray-600">打卡</span>
                        </button>
                        <button onClick={() => setShowHistory(true)} className="flex flex-col items-center gap-1 group">
                            <div className="w-12 h-12 bg-gradient-to-b from-blue-400 to-blue-500 rounded-2xl shadow-lg shadow-blue-200 flex items-center justify-center text-white text-xl group-hover:scale-110 transition-transform">
                                <i className="fas fa-history"></i>
                            </div>
                            <span className="text-[10px] font-bold text-gray-600">历史消息</span>
                        </button>
                    </div>
                </div>
            </div>
        </>
    );
};
