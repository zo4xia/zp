
import React from 'react';

export const WeatherWidget = () => {
  return (
    <div className="bg-[#facc15] px-3 py-1.5 rounded-full shadow-sm border border-yellow-500/20 transform rotate-1">
      <span className="text-xs font-black text-gray-800 tracking-wide">天气 2025/12/12</span>
    </div>
  );
};
