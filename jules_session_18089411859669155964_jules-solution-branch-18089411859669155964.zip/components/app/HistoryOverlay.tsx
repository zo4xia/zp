
import React from 'react';
import { ChatMessage } from '../../types';

interface HistoryOverlayProps {
    messages: ChatMessage[];
    setShowHistory: (show: boolean) => void;
    chatEndRef: React.RefObject<HTMLDivElement>;
}

export const HistoryOverlay: React.FC<HistoryOverlayProps> = ({ messages, setShowHistory, chatEndRef }) => {
    return (
        <div className="absolute inset-y-0 right-0 w-full md:w-96 bg-white/95 backdrop-blur shadow-2xl z-[70] flex flex-col animate-slide-left border-l border-gray-100">
            <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-white">
                <h3 className="font-bold text-lg text-gray-800 flex items-center gap-2">
                    <i className="fas fa-comments text-blue-500"></i>
                    聊天记录
                </h3>
                <button onClick={() => setShowHistory(false)} className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600">
                    <i className="fas fa-times"></i>
                </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50 scrollbar-hide">
                {messages.length === 0 ? (
                    <div className="text-center text-gray-400 mt-20 flex flex-col gap-2">
                        <i className="fas fa-wind text-4xl mb-2 text-gray-300"></i>
                        <p>还没有消息哦</p>
                        <p className="text-xs">快和小萌打个招呼吧！</p>
                    </div>
                ) : (
                    messages.map((msg) => (
                        <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[85%] px-4 py-3 rounded-2xl text-sm shadow-sm ${msg.role === 'user'
                                ? 'bg-blue-500 text-white rounded-tr-none'
                                : 'bg-white text-gray-800 rounded-tl-none border border-gray-100'
                                }`}>
                                {msg.text}
                            </div>
                        </div>
                    ))
                )}
                <div ref={chatEndRef} />
            </div>
        </div>
    );
};
