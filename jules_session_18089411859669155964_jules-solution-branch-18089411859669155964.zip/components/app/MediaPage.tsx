
import React from 'react';

interface MediaPageProps {
    setCurrentView: (view: 'dashboard' | 'map' | 'detail' | 'media' | 'profile') => void;
}

export const MediaPage: React.FC<MediaPageProps> = ({ setCurrentView }) => {
    return (
        <div className="flex flex-col h-full bg-[#f4f6f8] relative z-20 animate-fade-in">
            {/* Header */}
            <div className="flex items-center justify-between px-6 pt-6 pb-4 bg-white/80 backdrop-blur-md z-30 sticky top-0 shadow-sm border-b border-gray-100/50">
                <button
                    onClick={() => setCurrentView('dashboard')}
                    className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center text-gray-600 active:scale-95 transition hover:bg-gray-50 border border-gray-100"
                >
                    <i className="fas fa-chevron-left"></i>
                </button>
                <span className="font-bold text-xl text-gray-700 tracking-wide">视频自媒体</span>
                <div className="w-10"></div>
            </div>

            {/* Content List */}
            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4 scrollbar-hide">
                {/* Mock Data */}
                {[1, 2, 3].map((i) => (
                    <div key={i} className="bg-white rounded-3xl p-4 shadow-sm border border-gray-50 flex flex-col gap-3">
                        <div className="h-32 bg-gray-200 rounded-2xl relative overflow-hidden">
                            <img src={`https://picsum.photos/seed/media${i}/600/400`} className="w-full h-full object-cover" />
                            <div className="absolute inset-0 flex items-center justify-center bg-black/10">
                                <div className="w-10 h-10 bg-white/90 rounded-full flex items-center justify-center shadow-lg">
                                    <i className="fas fa-play text-rose-500 ml-1"></i>
                                </div>
                            </div>
                        </div>
                        <div>
                            <h3 className="font-bold text-gray-800 text-lg leading-tight">东里村的新变化，你发现了吗？第{i}期</h3>
                            <div className="flex items-center justify-between mt-2">
                                <div className="flex items-center gap-2">
                                    <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center text-xs">👱‍♂️</div>
                                    <span className="text-xs text-gray-500 font-medium">小萌村官</span>
                                </div>
                                <span className="text-xs text-gray-400">2025-12-12</span>
                            </div>
                        </div>
                    </div>
                ))}
                <div className="h-16 flex items-center justify-center text-gray-400 text-xs">
                    - 到底啦 -
                </div>
            </div>
        </div>
    )
};
