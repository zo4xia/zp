
import React from 'react';

interface TextInputOverlayProps {
    inputText: string;
    setInputText: (text: string) => void;
    handleSendText: (e: React.FormEvent) => void;
    setInputMode: (mode: 'none' | 'text') => void;
}

export const TextInputOverlay: React.FC<TextInputOverlayProps> = ({
    inputText,
    setInputText,
    handleSendText,
    setInputMode,
}) => {
    return (
        <div className="absolute inset-0 z-[60] bg-black/40 backdrop-blur-sm flex items-end justify-center pb-32 animate-fade-in">
            <div className="bg-white w-full max-w-lg mx-4 rounded-2xl p-4 shadow-2xl animate-slide-up">
                <div className="flex justify-between items-center mb-2">
                    <span className="font-bold text-gray-700">发送消息给小萌</span>
                    <button onClick={() => setInputMode('none')} className="text-gray-400 hover:text-gray-600"><i className="fas fa-times"></i></button>
                </div>
                <form onSubmit={handleSendText} className="flex gap-2">
                    <input
                        type="text"
                        value={inputText}
                        onChange={(e) => setInputText(e.target.value)}
                        placeholder="问问村里有什么好吃的..."
                        autoFocus
                        className="flex-1 bg-gray-100 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-400"
                    />
                    <button
                        type="submit"
                        disabled={!inputText.trim()}
                        className="w-12 h-12 bg-blue-500 rounded-xl text-white flex items-center justify-center disabled:opacity-50 disabled:bg-gray-300"
                    >
                        <i className="fas fa-paper-plane"></i>
                    </button>
                </form>
            </div>
        </div>
    );
};
