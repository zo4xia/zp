
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig(({ mode }) => {
  // 修复: 使用 process.cwd() 之前先进行类型断言，防止 TS 报错
  const currentWorkingDir = (process as any).cwd();
  const env = loadEnv(mode, currentWorkingDir, '');

  return {
    plugins: [react()],
    resolve: {
      alias: {
        '@': path.resolve(currentWorkingDir, './src'),
      },
    },
    // 注入环境变量，确保前端能读取到
    define: {
      'process.env': {
        GEMINI_API_KEY: JSON.stringify(env.GEMINI_API_KEY || ''),
        MINIMAX_API_KEY: JSON.stringify(env.MINIMAX_API_KEY || ''),
        VITE_API_BASE_URL: JSON.stringify(env.VITE_API_BASE_URL || '/api'),
      },
    },
    server: {
      host: '0.0.0.0',
      port: 3000,
      // 核心修复：配置反向代理解决跨域
      proxy: {
        '/api': {
          target: 'http://localhost:3001',
          changeOrigin: true,
          secure: false,
        },
      },
    },
    build: {
      outDir: 'dist',
      sourcemap: false,
      chunkSizeWarningLimit: 1000,
      rollupOptions: {
        output: {
          manualChunks: {
            'react-vendor': ['react', 'react-dom', 'react-router-dom'],
            'ui-vendor': ['antd', 'antd-mobile', '@ant-design/icons', 'framer-motion'],
            'map-vendor': ['leaflet'],
            'agent-core': [
              './src/services/agentSystem.ts',
              './src/services/agentA.ts',
              './src/services/agentB_Enhanced.ts',
              './src/services/agentC_RealDataProducer.ts',
              './src/services/agentD.ts'
            ],
          },
        },
      },
    },
  };
});
