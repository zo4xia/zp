import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { Spot } from '../../types';
import { openMapNavigation } from '../utils/mapUtils';

// 修复 Leaflet 默认图标在构建工具中的路径问题
// 使用国内CDN资源，确保图标加载成功
const DefaultIcon = L.icon({
  iconUrl: 'https://cdn.bootcdn.net/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  iconRetinaUrl: 'https://cdn.bootcdn.net/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  shadowUrl: 'https://cdn.bootcdn.net/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

interface MapViewProps {
  spots: Spot[];
  center?: [number, number];
  zoom?: number;
  heightRatio?: number;
  onSelectSpot?: (spot: Spot) => void;
  onNavigate?: (spot: Spot) => void;
}

const MapView: React.FC<MapViewProps> = ({
  spots,
  center = [25.235, 118.205], // 默认东里村坐标
  zoom = 16,
  heightRatio = 0.35, // 黄金比例
  onSelectSpot,
  onNavigate
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.Marker[]>([]);

  // 动态调整高度
  useEffect(() => {
    if (mapContainerRef.current) {
      const viewportHeight = window.innerHeight;
      mapContainerRef.current.style.height = `${viewportHeight * heightRatio}px`;
      mapInstanceRef.current?.invalidateSize();
    }
  }, [heightRatio]);

  // 初始化地图
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return;

    // 强制类型转换，解决TS元组问题
    const mapCenter = center as L.LatLngExpression;

    const map = L.map(mapContainerRef.current, {
      center: mapCenter,
      zoom: zoom,
      zoomControl: false, // 隐藏控件保持极简，符合移动端习惯
      attributionControl: false // 隐藏版权信息
    });

    // 🎯 核心替换：使用高德地图(AutoNavi)瓦片
    // 优势：国内访问速度极快，数据详细，中文显示完美
    L.tileLayer(
      'https://webrd0{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}',
      {
        subdomains: ['1', '2', '3', '4'],
        minZoom: 3,
        maxZoom: 18,
      }
    ).addTo(map);

    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // 更新标记点
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // 清除旧标记
    markersRef.current.forEach(marker => marker.remove());
    markersRef.current = [];

    spots.forEach(spot => {
      if (!spot.coord) return;
      const [lng, lat] = spot.coord.split(',').map(Number);
      
      if (isNaN(lat) || isNaN(lng)) return;

      // 🎨 自定义 HTML 标记 - 骚包黏土风小圆点
      const categoryColor = spot.category === 'red' ? '#ef4444' : '#10b981';
      const customIcon = L.divIcon({
        className: 'custom-div-icon',
        html: `
          <div style="position: relative; display: flex; flex-direction: column; align-items: center;">
            <div style="
              background-color: ${categoryColor};
              width: 24px;
              height: 24px;
              border-radius: 50%;
              border: 3px solid white;
              box-shadow: 0 4px 8px rgba(0,0,0,0.2);
              display: flex;
              align-items: center;
              justify-content: center;
              color: white;
              font-weight: bold;
              font-size: 12px;
              transition: transform 0.2s;
            ">
              ${spot.name.charAt(0)}
            </div>
            <div style="
              margin-top: 4px;
              background: rgba(255,255,255,0.95);
              padding: 2px 6px;
              border-radius: 6px;
              font-size: 10px;
              white-space: nowrap;
              box-shadow: 0 2px 4px rgba(0,0,0,0.1);
              font-weight: 600;
              color: #374151;
              border: 1px solid ${categoryColor}33;
            ">${spot.name}</div>
          </div>
        `,
        iconSize: [60, 60],
        iconAnchor: [30, 12]
      });

      const marker = L.marker([lat, lng], { icon: customIcon }).addTo(map);

      // 🗨️ 构建精美气泡内容
      const popupContent = document.createElement('div');
      popupContent.innerHTML = `
        <div style="text-align: center; padding: 6px; min-width: 160px;">
          <h4 style="margin: 0 0 6px 0; color: #1f2937; font-size: 15px; font-weight: bold;">${spot.name}</h4>
          <p style="margin: 0 0 10px 0; color: #6b7280; font-size: 12px; line-height: 1.4;">${spot.intro_short || '暂无简介'}</p>
          <div style="display: flex; gap: 8px;">
            <button id="nav-btn-${spot.id}" style="
              flex: 1; padding: 6px 0; background: linear-gradient(135deg, #3b82f6, #2563eb); color: white; 
              border: none; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 600;
              box-shadow: 0 2px 4px rgba(37, 99, 235, 0.2);">
              🚀 导航
            </button>
            <button id="detail-btn-${spot.id}" style="
              flex: 1; padding: 6px 0; background: #f3f4f6; color: #4b5563; 
              border: 1px solid #e5e7eb; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 600;">
              详情
            </button>
          </div>
        </div>
      `;

      marker.bindPopup(popupContent, {
        offset: [0, -20],
        closeButton: false,
        className: 'clay-popup' // 配合全局CSS
      });

      // 绑定气泡内按钮事件
      marker.on('popupopen', () => {
        // 导航按钮 -> 白嫖外部 App (高德/支付宝)
        document.getElementById(`nav-btn-${spot.id}`)?.addEventListener('click', (e) => {
          e.stopPropagation();
          if (onNavigate) {
            onNavigate(spot);
          } else {
            openMapNavigation(lat, lng, spot.name);
          }
        });

        // 详情按钮 -> 内部跳转
        document.getElementById(`detail-btn-${spot.id}`)?.addEventListener('click', (e) => {
          e.stopPropagation();
          onSelectSpot?.(spot);
        });
      });

      markersRef.current.push(marker);
    });
  }, [spots, onSelectSpot, onNavigate]);

  return (
    <div className="relative w-full overflow-hidden bg-slate-50 border-b border-white/50 shadow-sm z-0">
      <div 
        ref={mapContainerRef} 
        style={{ width: '100%', transition: 'height 0.3s ease', zIndex: 0 }}
      />
      {/* 底部渐变遮罩，丝滑过渡到列表 */}
      <div className="absolute bottom-0 left-0 right-0 h-6 bg-gradient-to-t from-[#f5f5f5] to-transparent pointer-events-none z-[400]" />
    </div>
  );
};

export default MapView;