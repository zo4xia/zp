// 增强版Chat页面 - 独立组件
import React, { useState, useEffect } from 'react';
import { Button, Toast, NavBar, Avatar, Input } from 'antd-mobile';
import { SafeAgentWrapper } from '../services/safeAgentWrapper';
import { AgentA } from '../services/agentSystem';

const ChatPageEnhanced = () => {
  const [messages, setMessages] = useState<{ id: string; type: 'user' | 'ai'; text: string; timestamp: number }[]>([]);
  const [input, setInput] = useState('');
  const [hasInteraction, setHasInteraction] = useState(false);
  const [countdown, setCountdown] = useState(10);
  const [isRecording, setIsRecording] = useState(false);
  
  const safeAgent = new SafeAgentWrapper();

  // 10秒自动跳转
  useEffect(() => {
    const timer = setInterval(() => {
      if (!hasInteraction) {
        setCountdown(prev => {
          if (prev <= 1) {
            // 🎯 安全记录自动跳转
            safeAgent.safeRecordRedirect({
              fromPage: 'chat',
              toPage: 'home',
              reason: 'no_interaction_10s',
              timestamp: new Date().toISOString(),
              sessionDuration: 10000
            });
            
            Toast.show({ content: '10秒无操作，返回首页', position: 'top' });
            setTimeout(() => {
              window.location.href = '/home';
            }, 1000);
            return 0;
          }
          return prev - 1;
        });
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [hasInteraction]);

  // 用户交互处理
  const handleUserInteraction = async (type: 'text' | 'voice', content: string) => {
    setHasInteraction(true);
    
    const uid = 'demo_user_001';
    const sessionId = 'demo_session_001';
    
    const interactionData = {
      uid,
      sessionId,
      interactionType: type,
      content,
      timestamp: new Date().toISOString(),
      page: 'chat_enhanced'
    };
    
    // 🎯 安全记录用户交互
    await safeAgent.safeRecordInteraction(interactionData);
    
    // 添加用户消息
    setMessages(prev => [...prev, {
      id: Date.now().toString(),
      type: 'user',
      text: content,
      timestamp: Date.now()
    }]);

    try {
      // 🎯 对接真实Agent ABCD四人组系统
      const startTime = Date.now();
      const contextSpot = '东里村'; // 当前景点上下文
      
      console.log(`🚀 调用Agent系统: uid=${uid}, input="${content}"`);
      
      const response = await AgentA.processUserRequest(
        uid,
        content,
        contextSpot,
        type
      );
      
      const responseTime = Date.now() - startTime;
      
      // 处理Agent响应
      let responseText = '';
      if (typeof response === 'string') {
        responseText = response;
      } else if (response && response.text) {
        responseText = response.text;
      } else if (response && response.content) {
        responseText = response.content;
      } else {
        responseText = JSON.stringify(response).substring(0, 500);
      }
      
      // 添加AI回复
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        text: responseText,
        timestamp: Date.now()
      }]);
      
      // 🎯 安全记录Agent响应
      await safeAgent.safeRecordAgentResponse({
        uid,
        sessionId,
        timestamp: new Date().toISOString(),
        inputType: type,
        inputContent: content,
        agentASuccess: true,
        apiCallSuccess: true,
        signalToBSuccess: true
      });
      
      console.log(`✅ Agent响应成功: ${responseTime}ms`);
      
    } catch (error) {
      console.error('❌ Agent系统调用失败:', error);
      
      // 优雅降级 - 友好的错误提示
      const errorResponse = `抱歉，我暂时无法回复您的问题。请稍后再试，或者您可以尝试换个方式提问 🤔`;
      
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        text: errorResponse,
        timestamp: Date.now()
      }]);
      
      // 记录错误到黑板
      await safeAgent.safeRecordAgentResponse({
        uid,
        sessionId,
        timestamp: new Date().toISOString(),
        inputType: type,
        inputContent: content,
        agentASuccess: false,
        apiCallSuccess: false,
        signalToBSuccess: false
      });
    }
  };

  // 检测浏览器语音支持
  const checkVoiceSupport = () => {
    return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
  };

  // 语音输入处理（带降级策略）
  const handleVoiceInput = async () => {
    // 检查浏览器支持
    if (!checkVoiceSupport()) {
      Toast.show({ 
        content: '您的浏览器不支持语音功能，请使用文字输入', 
        position: 'top',
        duration: 3000
      });
      return;
    }

    try {
      setIsRecording(true);
      Toast.show({ content: '开始录音...', position: 'top' });
      
      // 模拟语音识别（实际项目中这里会调用真实的语音识别API）
      setTimeout(() => {
        setIsRecording(false);
        const mockVoiceText = "我想了解一下东里村的红色文化景点";
        handleUserInteraction('voice', mockVoiceText);
        Toast.show({ content: '录音完成', position: 'top' });
      }, 2000);
      
    } catch (error) {
      console.error('语音输入失败:', error);
      setIsRecording(false);
      Toast.show({ 
        content: '语音输入失败，请使用文字输入', 
        position: 'top',
        duration: 3000
      });
    }
  };

  // 文字转语音播放（可选功能）
  const playTextToSpeech = (text: string) => {
    try {
      // 检查浏览器是否支持语音合成
      if (!('speechSynthesis' in window)) {
        console.warn('浏览器不支持语音合成');
        return;
      }

      // 停止当前播放
      window.speechSynthesis.cancel();
      
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'zh-CN';
      utterance.rate = 0.8;
      utterance.pitch = 1;
      
      window.speechSynthesis.speak(utterance);
    } catch (error) {
      console.error('语音播放失败:', error);
    }
  };

  return (
    <div className="chat-page">
      <div style={{ position: 'fixed', top: '20px', right: '20px', zIndex: 1000 }}>
        <div style={{
          backgroundColor: '#ffeb3b',
          padding: '8px 12px',
          borderRadius: '20px',
          fontSize: '12px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.2)'
        }}>
          倒计时: {countdown}s
        </div>
      </div>
      
      <NavBar
        backArrow={false}
        right={
          <Button size="small" onClick={() => {
            const stats = safeAgent.getBlackboardStats();
            console.log('📊 黑板统计:', stats);
            alert(JSON.stringify(stats, null, 2));
          }}>
            查看黑板
          </Button>
        }
      >
        AI对话 - 增强版
      </NavBar>
      
      <div style={{ padding: '16px' }}>
        <div style={{ marginBottom: '16px', padding: '12px', backgroundColor: '#e8f5e9', borderRadius: '8px' }}>
          <div style={{ fontSize: '12px', color: '#2e7d32' }}>
            💡 路演演示说明：
          </div>
          <ul style={{ fontSize: '12px', color: '#2e7d32', marginTop: '4px', paddingLeft: '20px' }}>
            <li>点击"文字输入"或"语音输入"按钮进行交互</li>
            <li>10秒无操作自动返回首页</li>
            <li>点击右上角"查看黑板"可查看记录统计</li>
            <li>所有交互都会安全记录到黑板系统</li>
          </ul>
        </div>
        
        <div className="chat-messages" style={{ marginBottom: '20px' }}>
          {messages.map(msg => (
            <div
              key={msg.id}
              style={{
                display: 'flex',
                justifyContent: msg.type === 'ai' ? 'flex-start' : 'flex-end',
                marginBottom: '12px',
                padding: '0 16px'
              }}
            >
              <div
                style={{
                  maxWidth: '70%',
                  padding: '12px 16px',
                  borderRadius: '18px',
                  backgroundColor: msg.type === 'ai' ? '#f0f0f0' : '#1677ff',
                  color: msg.type === 'ai' ? '#000' : '#fff',
                  fontSize: '14px',
                  lineHeight: '1.4',
                  wordBreak: 'break-word',
                  position: 'relative'
                }}
              >
                {msg.text}
                {/* AI回复添加语音播放按钮 */}
                {msg.type === 'ai' && (
                  <button
                    onClick={() => playTextToSpeech(msg.text)}
                    style={{
                      position: 'absolute',
                      top: '8px',
                      right: '8px',
                      background: 'none',
                      border: 'none',
                      fontSize: '16px',
                      cursor: 'pointer',
                      opacity: 0.7,
                      padding: '4px'
                    }}
                    title="点击播放语音"
                  >
                    🔊
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
        
        <div style={{ position: 'fixed', bottom: '20px', left: '50%', transform: 'translateX(-50%)', width: '100%', maxWidth: '400px' }}>
          <div style={{ display: 'flex', gap: '8px', marginBottom: '8px' }}>
            <Input
              value={input}
              onChange={setInput}
              placeholder="请输入文字..."
              style={{ flex: 1 }}
            />
            <Button onClick={() => {
              if (input.trim()) {
                handleUserInteraction('text', input);
                setInput('');
              }
            }}>
              发送
            </Button>
          </div>
          
          <div style={{ display: 'flex', gap: '8px' }}>
            {/* 语音输入按钮 - 带降级检测 */}
            <Button 
              block 
              onClick={handleVoiceInput}
              loading={isRecording}
              disabled={!checkVoiceSupport()}
              style={{ 
                backgroundColor: isRecording ? '#9e9e9e' : (checkVoiceSupport() ? '#4caf50' : '#ccc'), 
                color: 'white',
                opacity: checkVoiceSupport() ? 1 : 0.6
              }}
            >
              {isRecording ? '录音中...' : (checkVoiceSupport() ? '🎤 语音输入' : '🎤 不支持')}
            </Button>
            <Button 
              block 
              onClick={() => handleUserInteraction('text', '推荐一个红色文化景点')}
            >
              📝 快速体验
            </Button>
          </div>
          
          {/* 降级提示 */}
          {!checkVoiceSupport() && (
            <div style={{ 
              fontSize: '12px', 
              color: '#666', 
              textAlign: 'center', 
              marginTop: '8px',
              padding: '8px',
              backgroundColor: '#fff3cd',
              borderRadius: '4px',
              border: '1px solid #ffeaa7'
            }}>
              💡 您的浏览器不支持语音功能，请使用文字输入。AI回复支持点击🔊播放语音。
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatPageEnhanced;