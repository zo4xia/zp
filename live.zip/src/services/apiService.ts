
/**
 * 前台API服务
 * 处理移动端页面与后端API的对接
 */

// API基础配置
// 关键修改: 使用相对路径 '/api'，让 Vite (开发环境) 或 Nginx (生产环境) 处理代理转发
// 避免硬编码 http://localhost:3001 导致真机调试和跨域失败
const API_BASE_URL = '/api';

// 通用请求函数
async function request<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<{ success: boolean; data?: T; error?: string; message?: string }> {
  // 确保 endpoint 以 / 开头
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  const url = `${API_BASE_URL}${cleanEndpoint}`;
  
  const config: RequestInit = {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  };

  try {
    const response = await fetch(url, config);
    
    // 处理 HTTP 错误
    if (!response.ok) {
      // 尝试解析错误响应
      let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
      try {
        const errorData = await response.json();
        if (errorData.message) errorMessage = errorData.message;
      } catch (e) {
        // 忽略解析错误
      }
      throw new Error(errorMessage);
    }
    
    const result = await response.json();
    return result;
  } catch (error) {
    console.error(`API请求失败: ${url}`, error);
    // 返回统一的错误结构，避免前端崩溃
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown Network Error'
    };
  }
}

// 景点API
export const spotsApi = {
  // 获取景点列表
  getSpots: async (params?: {
    category?: string;
    type?: string;
    page?: number;
    limit?: number;
  }) => {
    const queryParams = new URLSearchParams();
    if (params?.category) queryParams.append('category', params.category);
    if (params?.type) queryParams.append('type', params.type);
    if (params?.page) queryParams.append('page', params.page.toString());
    if (params?.limit) queryParams.append('limit', params.limit.toString());
    
    const queryString = queryParams.toString() ? `?${queryParams.toString()}` : '';
    return request<any[]>(`/spots${queryString}`);
  },

  // 获取景点详情
  getSpotById: async (id: string) => {
    return request<any>(`/spots/${id}`);
  }
};

// 人物API
export const figuresApi = {
  // 获取人物列表
  getFigures: async (params?: {
    category?: string;
    type?: string;
    year?: number;
    page?: number;
    limit?: number;
  }) => {
    const queryParams = new URLSearchParams();
    if (params?.category) queryParams.append('category', params.category);
    if (params?.type) queryParams.append('type', params.type);
    if (params?.year) queryParams.append('year', params.year.toString());
    if (params?.page) queryParams.append('page', params.page.toString());
    if (params?.limit) queryParams.append('limit', params.limit.toString());
    
    const queryString = queryParams.toString() ? `?${queryParams.toString()}` : '';
    return request<any[]>(`/figures${queryString}`);
  },

  // 获取人物详情
  getFigureById: async (id: string) => {
    return request<any>(`/figures/${id}`);
  }
};

// 公告API
export const announcementsApi = {
  // 获取公告列表
  getAnnouncements: async (params?: {
    type?: string;
    page?: number;
    limit?: number;
  }) => {
    const queryParams = new URLSearchParams();
    if (params?.type) queryParams.append('type', params.type);
    if (params?.page) queryParams.append('page', params.page.toString());
    if (params?.limit) queryParams.append('limit', params.limit.toString());
    
    const queryString = queryParams.toString() ? `?${queryParams.toString()}` : '';
    return request<any[]>(`/announcements${queryString}`);
  }
};

// 认证API
export const authApi = {
  // 发送验证码
  sendCode: async (phone: string) => {
    return request<{ message: string }>(`/auth/send-code`, {
      method: 'POST',
      body: JSON.stringify({ phone }),
    });
  },

  // 用户登录
  login: async (phone: string, code: string) => {
    return request<{ user: any; token: string; message: string }>(`/auth/login`, {
      method: 'POST',
      body: JSON.stringify({ phone, code }),
    });
  }
};

// 用户API
export const userApi = {
  // 获取用户资料
  getProfile: async (token: string) => {
    return request<any>(`/user/profile`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
  }
};

// 打卡API
export const checkinApi = {
  // 提交打卡
  submitCheckin: async (token: string, spotId: string, spotName?: string) => {
    return request<any>(`/checkin`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ spotId, spotName }),
    });
  },

  // 获取打卡记录
  getCheckinRecords: async (token: string) => {
    return request<any[]>(`/checkin/records`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
  }
};

// 导出所有API服务
export const apiService = {
  spots: spotsApi,
  figures: figuresApi,
  announcements: announcementsApi,
  auth: authApi,
  user: userApi,
  checkin: checkinApi,
};
