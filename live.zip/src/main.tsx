import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './pages/App';
import MobileApp from './pages/MobileApp';
import './index.css'; // 引入核心样式宪法

// 1. 根元素检查 - 军工级严谨
const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error('Could not find root element to mount to');
}

// 2. 智能路由分发策略 - 区分移动端C端与管理端B端
// 剃刀原则：简单直接，不搞复杂的路由守卫
const isMobileRoute = () => {
  const path = window.location.pathname;
  // 白名单机制，匹配移动端路径
  return (
    path.startsWith('/mobile') ||
    path === '/login' ||
    path === '/' || 
    path === '/home' ||
    path === '/category' ||
    path === '/chat' ||
    path === '/profile' ||
    path.startsWith('/spotlist') ||
    path.startsWith('/spotdetail') ||
    path.startsWith('/checkin') ||
    path.startsWith('/red-culture') ||
    path.startsWith('/nature-spots') ||
    path.startsWith('/figures') ||
    path.startsWith('/announcements')
  );
};

// 3. 组件选择
const AppComponent = isMobileRoute() ? MobileApp : App;

// 4. 渲染挂载
const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <AppComponent />
  </React.StrictMode>
);