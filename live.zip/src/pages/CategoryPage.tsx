
import { NavBar } from 'antd-mobile';
import { UserOutline } from 'antd-mobile-icons';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

const CategoryPage = () => {
  const navigate = useNavigate();

  const categories = [
    { id: 'red', icon: '🏛️', title: '红色之旅', desc: '革命历史 · 薪火相传', color: '#fef2f2', path: '/spotlist/red-culture' },
    { id: 'nature', icon: '🌿', title: '伴你游东里', desc: '山水田园 · 诗意栖居', color: '#f0fdf4', path: '/spotlist/nature-spots' },
    { id: 'people', icon: '🎓', title: '走进东里', desc: '人杰地灵 · 乡贤辈出', color: '#eff6ff', path: '/figures' },
    { id: 'news', icon: '📢', title: '村子动态', desc: '最新资讯 · 活动预告', color: '#fffbeb', path: '/announcements' },
  ];

  return (
    <div className="min-h-screen bg-[#fafafa]">
      {/* 导航栏 - 磨砂玻璃效果 */}
      <div className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-100">
        <NavBar
          back={null}
          right={<UserOutline onClick={() => navigate('/profile')} style={{ fontSize: '24px', color: '#333' }} />}
        >
          <span className="font-bold text-slate-800">探索东里</span>
        </NavBar>
      </div>

      <div className="p-4 space-y-4">
        {/* 分类卡片列表 */}
        {categories.map((cat, i) => (
          <motion.div
            key={cat.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => navigate(cat.path)}
            className="clay-card p-5 flex items-center gap-4 cursor-pointer"
            style={{ backgroundColor: cat.color, border: 'none' }}
          >
            <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-3xl shadow-sm">
              {cat.icon}
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-bold text-slate-800 mb-1">{cat.title}</h3>
              <p className="text-xs text-slate-500">{cat.desc}</p>
            </div>
            <div className="text-slate-300">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
              </svg>
            </div>
          </motion.div>
        ))}
      </div>

      {/* 底部悬浮 Agent 入口 - 军工级响应 */}
      <motion.div 
        className="fixed bottom-6 right-6 z-50"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", stiffness: 260, damping: 20, delay: 0.5 }}
      >
        <button
          onClick={() => navigate('/chat')}
          className="w-16 h-16 rounded-full bg-gradient-to-tr from-green-500 to-emerald-400 text-white shadow-lg shadow-green-500/40 flex items-center justify-center text-3xl border-4 border-white clay-btn active:scale-90 transition-transform"
        >
          🧑‍💼
        </button>
      </motion.div>
    </div>
  );
};

export default CategoryPage;
