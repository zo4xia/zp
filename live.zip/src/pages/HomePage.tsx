
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from 'antd-mobile';
import { CompassOutline, SoundOutline, UserOutline, RightOutline } from 'antd-mobile-icons';

// 🚀 首页：用户的"第一眼"战场
// 采用 Framer Motion 实现交错入场，营造"时间变美好"的高级感
const HomePage: React.FC = () => {
  const navigate = useNavigate();

  // 动效配置：容器编排（让子元素一个接一个出来，像弹钢琴一样）
  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15, // 节奏感：每个卡片间隔0.15秒
        delayChildren: 0.1
      }
    }
  };

  // 动效配置：单个元素弹入 (Q弹的效果)
  const itemVariants = {
    hidden: { y: 40, opacity: 0, scale: 0.9 },
    show: { 
      y: 0, 
      opacity: 1, 
      scale: 1,
      transition: { type: "spring", stiffness: 200, damping: 15 } 
    }
  };

  const features = [
    { title: '红色之旅', desc: '追寻革命足迹', icon: '🚩', path: '/spotlist/red-culture', bg: '#fee2e2', text: '#ef4444' },
    { title: '伴你游', desc: '自然风光路线', icon: '🌿', path: '/spotlist/nature-spots', bg: '#dcfce7', text: '#10b981' },
    { title: '走进东里', desc: '村史与人物', icon: '📜', path: '/figures', bg: '#dbeafe', text: '#3b82f6' },
    { title: '村子动态', desc: '最新活动公告', icon: '📢', path: '/announcements', bg: '#fef9c3', text: '#d97706' },
  ];

  return (
    <div className="min-h-screen bg-[#f0fdf4] relative overflow-hidden font-sans pb-24 selection:bg-green-200">
      {/* 🔮 背景光斑 - 营造温柔的氛围 */}
      <div className="absolute top-[-10%] right-[-10%] w-[300px] h-[300px] bg-green-200/30 rounded-full blur-[80px] pointer-events-none" />
      <div className="absolute top-[20%] left-[-10%] w-[200px] h-[200px] bg-blue-200/30 rounded-full blur-[60px] pointer-events-none" />

      <motion.div 
        className="relative z-10 px-6 pt-12"
        variants={containerVariants}
        initial="hidden"
        animate="show"
      >
        {/* 1. 头部 Hero 区域 - 像家一样温暖 */}
        <motion.div variants={itemVariants} className="text-center mb-10">
          <motion.div 
            className="relative w-32 h-32 mx-auto mb-6"
            whileHover={{ scale: 1.05, rotate: 5 }}
            whileTap={{ scale: 0.95 }}
          >
            <div className="absolute inset-0 bg-white rounded-full shadow-[0_8px_30px_rgb(0,0,0,0.12)] flex items-center justify-center text-7xl border-[6px] border-white z-10">
              🏡
            </div>
            {/* 呼吸灯效果 - 代表系统在线 */}
            <div className="absolute bottom-1 right-1 w-8 h-8 bg-[#52c41a] rounded-full border-4 border-white z-20 flex items-center justify-center shadow-md">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span>
            </div>
          </motion.div>
          <h1 className="text-3xl font-bold text-slate-800 mb-2 tracking-tight">东里村智能导游</h1>
          <p className="text-slate-500 text-sm font-medium">AI 伴您探索 · 传承乡土文化</p>
        </motion.div>

        {/* 2. 核心行动按钮 - 巨大的入口 */}
        <motion.div variants={itemVariants} className="space-y-4 mb-10">
          <div onClick={() => navigate('/chat')} className="cursor-pointer">
            <div className="bg-gradient-to-r from-[#10b981] to-[#059669] p-1 rounded-3xl shadow-xl shadow-green-200/50 active:scale-95 transition-transform duration-200">
              <div className="bg-white/10 backdrop-blur-sm rounded-[20px] p-5 flex items-center justify-between">
                <div className="flex items-center gap-4 text-white">
                  <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center text-2xl backdrop-blur-md">
                    🎤
                  </div>
                  <div>
                    <div className="text-lg font-bold">AI 语音导游</div>
                    <div className="text-xs opacity-90">想问什么？直接告诉我</div>
                  </div>
                </div>
                <div className="w-8 h-8 bg-white text-green-600 rounded-full flex items-center justify-center shadow-lg">
                  <RightOutline />
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* 3. 功能网格 - 黏土风格卡片 */}
        <motion.div variants={itemVariants} className="grid grid-cols-2 gap-4 mb-8">
          {features.map((feature) => (
            <motion.div
              key={feature.title}
              whileHover={{ y: -5 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => navigate(feature.path)}
              className="clay-card p-4 flex flex-col justify-between h-36 cursor-pointer border-0 relative overflow-hidden group"
              style={{ backgroundColor: 'white' }} // 统一白底，用图标色区分
            >
              {/* 装饰性背景 */}
              <div className="absolute -right-4 -bottom-4 w-20 h-20 rounded-full opacity-10 transition-transform group-hover:scale-150" style={{ backgroundColor: feature.text }} />
              
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-sm mb-3 transition-colors" style={{ backgroundColor: feature.bg }}>
                {feature.icon}
              </div>
              
              <div>
                <div className="font-bold text-base text-slate-800">{feature.title}</div>
                <div className="text-xs text-slate-400 mt-1">{feature.desc}</div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* 4. 底部快捷栏 - 悬浮的药丸 */}
        <motion.div variants={itemVariants} className="fixed bottom-8 left-0 right-0 flex justify-center z-50 pointer-events-none">
           <div className="bg-white/90 backdrop-blur-xl px-2 py-2 rounded-full shadow-[0_8px_30px_rgba(0,0,0,0.12)] border border-white/50 flex items-center gap-2 pointer-events-auto">
             <div 
               className="px-6 py-3 rounded-full hover:bg-slate-50 text-slate-600 text-sm font-bold cursor-pointer transition-colors flex items-center gap-2"
               onClick={() => navigate('/profile')}
             >
               <UserOutline /> 个人中心
             </div>
             <div className="w-[1px] h-6 bg-slate-200"></div>
             <div 
               className="px-6 py-3 rounded-full hover:bg-slate-50 text-slate-600 text-sm font-bold cursor-pointer transition-colors flex items-center gap-2"
               onClick={() => navigate('/announcements')}
             >
               公告 <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
             </div>
           </div>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default HomePage;
