
import React, { useState, useEffect, useRef } from 'react';
import { NavBar, Input, Button, Toast } from 'antd-mobile';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { AudioOutline, TextOutline, SendOutline, LeftOutline } from 'antd-mobile-icons';
import { AgentA } from '../services/agentA';
import { SafeAgentWrapper } from '../services/safeAgentWrapper';

// 🤖 消息类型定义
interface Message {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: number;
}

const ChatPage: React.FC = () => {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<'text' | 'voice'>('text'); // 🐔 核心：鸡贼胶囊状态
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const safeAgent = new SafeAgentWrapper();

  // 1. 初始化欢迎语 - 温柔的开场
  useEffect(() => {
    // 延迟一点点显示，增加真实感
    setTimeout(() => {
      setMessages([{
        id: 'welcome',
        type: 'ai',
        content: '你好呀！我是东里村的 AI 导游。👋\n\n想了解红色故事、找景点、还是找美食？点击下方胶囊告诉我吧！',
        timestamp: Date.now()
      }]);
    }, 500);
  }, []);

  // 2. 消息自动滚动 - 始终关注最新
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  // 3. 核心交互逻辑
  const handleSend = async () => {
    if (!inputValue.trim()) return;

    const userText = inputValue;
    const uid = localStorage.getItem('uid') || 'guest_' + Date.now();
    setInputValue(''); // 立即清空输入框
    
    // 立即上屏用户消息 (乐观UI)
    setMessages(prev => [...prev, {
      id: Date.now().toString(),
      type: 'user',
      content: userText,
      timestamp: Date.now()
    }]);
    setLoading(true);

    try {
      // 🛡️ 战略核心：调用 Agent A (眼睛)
      console.log(`🤖 Agent A 启动: 模式=${mode}, 内容=${userText}`);
      
      const response = await AgentA.processUserRequest(uid, userText, '东里村', mode);
      
      // 解析 Agent 系统的返回
      let aiContent = '';
      if (typeof response === 'string') {
        aiContent = response;
      } else if (response && (response as any).content) {
        aiContent = (response as any).content;
      } else if (response && (response as any).text) {
        aiContent = (response as any).text;
      } else {
        // 处理特殊指令返回的友好提示
        if ((response as any).tool === 'get_map') aiContent = '已为您开启导航模式，地图加载中... 🗺️';
        else if ((response as any).tool === 'get_shopping_info') aiContent = '正在为您查找附近的特产商店... 🛍️';
        else aiContent = '收到！小助理正在为您查询资料。📚';
      }

      // 模拟一点点思考时间，让交互更自然
      setTimeout(() => {
        setMessages(prev => [...prev, {
          id: (Date.now() + 1).toString(),
          type: 'ai',
          content: aiContent,
          timestamp: Date.now()
        }]);
        setLoading(false);
      }, 800);

      // 安全记录到黑板 (Agent D)
      safeAgent.safeRecordInteraction({
        uid,
        content: userText,
        type: mode,
        response: aiContent,
        success: true,
        timestamp: new Date().toISOString()
      });

    } catch (error) {
      console.error('Agent Error:', error);
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: '抱歉，网络有点小波动，请再说一次。😓',
        timestamp: Date.now()
      }]);
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-[#f0fdf4]">
      {/* 1. 顶部导航 - 磨砂玻璃 */}
      <div className="sticky top-0 z-50 bg-[#f0fdf4]/80 backdrop-blur-md border-b border-green-100/50">
        <NavBar onBack={() => navigate(-1)} backArrow={<LeftOutline fontSize={24} color="#1f2937"/>}>
          <span className="font-bold text-slate-800">AI 导游</span>
        </NavBar>
      </div>

      {/* 2. 聊天区域 */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 pb-36 scrollbar-hide">
        <AnimatePresence initial={false}>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ type: "spring", stiffness: 300, damping: 25 }}
              className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex max-w-[85%] ${msg.type === 'user' ? 'flex-row-reverse' : 'flex-row'} gap-3 items-end`}>
                {/* 头像 */}
                <div className="flex-shrink-0">
                  {msg.type === 'ai' ? (
                    <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-xl shadow-sm border border-green-100">🧑‍💼</div>
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center text-white text-sm font-bold shadow-md shadow-green-200">我</div>
                  )}
                </div>
                
                {/* 气泡 - 黏土风格 */}
                <div className={`px-4 py-3 rounded-2xl text-[15px] leading-relaxed shadow-sm whitespace-pre-wrap ${
                  msg.type === 'user' 
                    ? 'bg-gradient-to-br from-green-500 to-emerald-600 text-white rounded-br-none shadow-green-200' 
                    : 'bg-white text-slate-700 border border-green-50 rounded-bl-none shadow-[0_4px_12px_rgba(0,0,0,0.03)]'
                }`}>
                  {msg.content}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        
        {/* 思考中动画 */}
        {loading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start ml-14">
            <div className="bg-white px-4 py-3 rounded-2xl rounded-bl-none text-slate-400 flex items-center gap-1 shadow-sm border border-green-50">
              <span className="w-2 h-2 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></span>
              <span className="w-2 h-2 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></span>
              <span className="w-2 h-2 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></span>
            </div>
          </motion.div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* 3. 底部操作区 - 鸡贼胶囊载体 */}
      <div className="bg-white/80 backdrop-blur-xl border-t border-slate-100 fixed bottom-0 w-full z-50 rounded-t-[32px] shadow-[0_-8px_30px_rgba(0,0,0,0.04)] pb-8 pt-4 px-4">
        
        {/* 🐔 鸡贼胶囊：用户主动选择 = 零成本意图识别 */}
        <div className="flex justify-center -mt-10 mb-4">
          <div className="bg-white p-1.5 rounded-full flex relative shadow-[0_8px_20px_rgba(0,0,0,0.08)] border border-slate-50">
            <motion.div 
              className="absolute top-1.5 bottom-1.5 rounded-full bg-green-50 border border-green-100"
              initial={false}
              animate={{ 
                x: mode === 'text' ? 0 : '100%',
                width: '50%'
              }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            />
            <button 
              onClick={() => setMode('text')}
              className={`w-24 relative z-10 py-2 text-xs font-bold rounded-full transition-colors flex items-center justify-center gap-1.5 ${mode === 'text' ? 'text-green-600' : 'text-slate-400'}`}
            >
              <TextOutline /> 文字
            </button>
            <button 
              onClick={() => setMode('voice')}
              className={`w-24 relative z-10 py-2 text-xs font-bold rounded-full transition-colors flex items-center justify-center gap-1.5 ${mode === 'voice' ? 'text-green-600' : 'text-slate-400'}`}
            >
              <AudioOutline /> 语音
            </button>
          </div>
        </div>

        <div className="flex gap-3 items-end">
          {mode === 'text' ? (
            <div className="flex-1 bg-slate-100 rounded-3xl border-2 border-transparent focus-within:border-green-400 focus-within:bg-white transition-all px-4 py-2">
              <Input
                className="text-base bg-transparent"
                placeholder="问问村里的历史..."
                value={inputValue}
                onChange={val => setInputValue(val)}
                onEnterPress={handleSend}
                clearable
              />
            </div>
          ) : (
            <motion.button 
              whileTap={{ scale: 0.98 }}
              className="flex-1 h-12 rounded-3xl bg-green-50 text-green-600 border-2 border-green-200 font-bold text-base flex items-center justify-center gap-2 shadow-sm"
              onClick={() => { Toast.show({ content: '按住说话功能开发中，请先使用文字' }); }}
            >
              <AudioOutline /> 按住 说话
            </motion.button>
          )}
          
          <motion.button 
            whileTap={{ scale: 0.9 }}
            className={`w-12 h-12 flex items-center justify-center rounded-full shadow-lg shadow-green-500/30 transition-all ${
              !inputValue.trim() && mode === 'text' ? 'bg-slate-200 text-slate-400' : 'bg-gradient-to-r from-[#10b981] to-[#059669] text-white'
            }`}
            onClick={handleSend}
            disabled={!inputValue.trim() && mode === 'text'}
          >
            <SendOutline fontSize={24} />
          </motion.button>
        </div>
      </div>
    </div>
  );
};

export default ChatPage;
