
import React from 'react';
import { NavBar, List, Badge, Empty } from 'antd-mobile';
import { RightOutline } from 'antd-mobile-icons';
import { useNavigate, useParams } from 'react-router-dom';
import MapView from '../components/MapView';
import { SPOTS_DATA } from '../services/staticData';

const SpotListPage = () => {
  const navigate = useNavigate();
  const { type } = useParams<{ type: string }>();
  
  // 1. 数据过滤逻辑：确保 "插座" 接对 "电"
  // 如果 type 是 undefined，展示所有；否则根据 category 过滤
  const filteredSpots = SPOTS_DATA.filter(s => {
    if (!type) return true;
    if (type === 'red-culture') return s.category === 'red';
    if (type === 'nature-spots') return s.category === 'nature';
    return true;
  });

  const getTitle = () => {
    if (type === 'red-culture') return '红色文旅地图';
    if (type === 'nature-spots') return '自然风光地图';
    return '景点导览';
  };

  return (
    <div className="flex flex-col h-screen bg-[#f5f5f5]">
      <NavBar onBack={() => navigate(-1)} className="bg-white border-b border-slate-100 flex-shrink-0">
        {getTitle()}
      </NavBar>

      {/* 地图区域：占 35% 高度 */}
      <div className="flex-shrink-0 relative z-0">
        <MapView 
          spots={filteredSpots} 
          heightRatio={0.35}
          onSelectSpot={(spot) => navigate(`/spotdetail/${spot.id}`)}
        />
      </div>

      {/* 列表区域：占剩余高度 */}
      <div className="flex-1 overflow-y-auto -mt-4 relative z-10 bg-[#f5f5f5] rounded-t-3xl shadow-[0_-4px_20px_rgba(0,0,0,0.05)] pt-6 px-4 pb-10">
        <div className="flex items-center gap-2 mb-4 px-2">
          <div className="w-1 h-4 bg-green-500 rounded-full"></div>
          <h3 className="font-bold text-slate-700">景点列表 ({filteredSpots.length})</h3>
        </div>

        {filteredSpots.length > 0 ? (
          <div className="space-y-3">
            {filteredSpots.map(spot => (
              <div
                key={spot.id}
                onClick={() => navigate(`/spotdetail/${spot.id}`)}
                className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 active:scale-[0.98] transition-transform cursor-pointer flex items-center justify-between"
              >
                <div className="flex items-start gap-3">
                  <div className={`w-2 h-2 mt-2 rounded-full ${spot.category === 'red' ? 'bg-red-500' : 'bg-green-500'}`} />
                  <div>
                    <div className="font-bold text-slate-800 text-base mb-1">{spot.name}</div>
                    <div className="text-xs text-slate-500 line-clamp-1">{spot.intro_short}</div>
                    <div className="mt-2 flex gap-1">
                      {spot.tags?.slice(0, 2).map(tag => (
                        <span key={tag} className="px-2 py-0.5 bg-slate-100 text-slate-500 text-[10px] rounded-md">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                <RightOutline className="text-slate-300" />
              </div>
            ))}
          </div>
        ) : (
          <Empty description="暂无相关景点数据" style={{ marginTop: '40px' }} />
        )}
      </div>
    </div>
  );
};

export default SpotListPage;
