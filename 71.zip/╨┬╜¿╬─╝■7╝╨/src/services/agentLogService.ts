/**
 * ⚠️ 兼容层 - 已迁移到 agentD.ts
 * 保留此文件是为了兼容旧的导入路径
 * 新代码请直接 import from './agentD'
 */

export {
  agentLogService,
  AgentD_Instance,
  type AgentBOutput,
  type BtoDPush,
  type ChatMessage,
  type UserStats,
} from './agentD';
